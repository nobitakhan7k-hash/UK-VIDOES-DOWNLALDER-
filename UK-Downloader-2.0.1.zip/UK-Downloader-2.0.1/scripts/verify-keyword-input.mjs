/**
 * Regression checks for the "[object Object]" keyword-search bug.
 * Run from the project root: node scripts/verify-keyword-input.mjs
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {
  coerceInputText,
  explicitFetchArg,
  isUrlLike,
  normaliseUrlInput,
  resolveFetchDetailsInput,
  safeKeywordQuery,
} from '../src/lib/searchInput.mjs';

const read = (rel) => fs.readFileSync(path.resolve(rel), 'utf8');
let checks = 0;
const ok = (label, fn) => {
  fn();
  checks += 1;
  console.log(`ok ${checks} - ${label}`);
};

const clickEvent = { type: 'click', target: {}, currentTarget: {} };
const keyEvent = { key: 'Enter', type: 'keydown' };

try {
  ok('event objects are never coerced into text', () => {
    assert.equal(coerceInputText(clickEvent), '');
    assert.equal(coerceInputText(keyEvent), '');
    assert.equal(explicitFetchArg(clickEvent), null);
  });

  ok('button-style call uses the typed field text, not the event object', () => {
    assert.equal(resolveFetchDetailsInput(clickEvent, 'Mr Beast new song'), 'Mr Beast new song');
    assert.equal(resolveFetchDetailsInput(keyEvent, 'another keyword'), 'another keyword');
  });

  ok('explicit string still wins over the current field', () => {
    assert.equal(resolveFetchDetailsInput('https://youtube.com/watch?v=abc', 'old keyword'), 'https://youtube.com/watch?v=abc');
  });

  ok('empty field + event object produces no search', () => {
    assert.equal(resolveFetchDetailsInput(clickEvent, ''), '');
    assert.equal(resolveFetchDetailsInput(clickEvent, null), '');
  });

  ok('already-stringified objects are rejected as keywords', () => {
    assert.equal(safeKeywordQuery('[object Object]'), '');
    assert.equal(safeKeywordQuery('[object KeyboardEvent]'), '');
    assert.equal(safeKeywordQuery(clickEvent), '');
    assert.equal(safeKeywordQuery(''), '');
  });

  ok('real keywords are trimmed, collapsed and capped at 200 chars', () => {
    assert.equal(safeKeywordQuery('  Mr   Beast   song  '), 'Mr Beast song');
    assert.equal(safeKeywordQuery('x'.repeat(250)).length, 200);
  });

  ok('plain text stays a keyword, real links stay links', () => {
    assert.equal(isUrlLike('Mr Beast'), false);
    assert.equal(isUrlLike('Mr Beast new song'), false);
    assert.equal(isUrlLike('[object Object]'), false);
    assert.equal(isUrlLike('https://youtube.com/watch?v=abc'), true);
    assert.equal(isUrlLike('youtube.com/watch?v=abc'), true);
  });

  ok('URL normalisation is string-only', () => {
    assert.equal(normaliseUrlInput('youtube.com/watch?v=abc'), 'https://youtube.com/watch?v=abc');
    assert.equal(normaliseUrlInput('Mr Beast song'), 'Mr Beast song');
    assert.equal(normaliseUrlInput(clickEvent), '');
  });

  ok('Header button no longer passes the click event directly', () => {
    const header = read('src/components/Header.jsx');
    assert.ok(header.includes('onClick={() => handleFetchDetails()}'));
    assert.ok(!header.includes('onClick={handleFetchDetails}'));
    assert.ok(header.includes('if (e.key === "Enter") handleFetchDetails();'));
  });

  ok('renderer + IPC layers guard non-string keywords', () => {
    const ctx = read('src/contexts/AppContext.jsx');
    const preload = read('src/preload.js');
    const main = read('src/main.js');
    assert.ok(ctx.includes('resolveFetchDetailsInput'));
    assert.ok(ctx.includes('safeKeywordQuery'));
    assert.ok(ctx.includes('setUrlInput'));
    assert.ok(preload.includes("typeof query === 'string' ? query : ''"));
    assert.ok(main.includes("typeof options.query !== 'string'"));
    assert.ok(main.includes("/^\\[object .+\\]$/i.test(query)"));
  });

  console.log(`\n${checks}/${checks} keyword-search input checks passed.`);
} catch (error) {
  console.error(`FAILED: ${error.stack || error.message}`);
  process.exitCode = 1;
}
