/**
 * Static + unit checks for the per-subscription folder / FOLDER.JPG feature.
 * Run from the project root: node scripts/verify-subscription-folder-thumb.mjs
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const {
  FOLDER_THUMBNAIL_NAME,
  safeFolderName,
  uniqueFolderPath,
  isJpegBuffer,
  replaceFolderThumbnail,
} = require('../src/lib/subscriptionFolder.cjs');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'ukd-folder-thumb-'));
let checks = 0;
const ok = async (label, fn) => {
  await fn();
  checks += 1;
  console.log(`ok ${checks} - ${label}`);
};

const JPEG = Buffer.from([0xff, 0xd8, 0xff, 0xd9, 0x00, 0x01]);
const JPEG2 = Buffer.from([0xff, 0xd8, 0xff, 0xd9, 0x00, 0x02]);
const fakeWrite = async (buf, filePath) => fs.writeFileSync(filePath, buf);
const fakeFetch = (buf) => async () => Buffer.from(buf);

try {
  await ok('FOLDER.JPG name is exact uppercase', async () => {
    assert.equal(FOLDER_THUMBNAIL_NAME, 'FOLDER.JPG');
  });

  await ok('safeFolderName strips Windows-invalid characters', async () => {
    const n = safeFolderName('Mr:Beast / Channel? *');
    assert.equal(n, 'Mr Beast Channel');
    assert.ok(!/[\\/:*?"<>|]/.test(n));
  });

  await ok('safeFolderName avoids reserved device names', async () => {
    for (const raw of ['CON', 'NUL', 'COM1', '', '...']) {
      const n = safeFolderName(raw);
      assert.ok(n && !/^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$/i.test(n));
      assert.ok(!/[. ]$/.test(n));
    }
  });

  await ok('safeFolderName keeps Unicode whole within byte budget', async () => {
    const n = safeFolderName('🎵'.repeat(200));
    assert.ok(Buffer.byteLength(n, 'utf8') <= 120);
    assert.ok(!n.includes('\ufffd'));
  });

  await ok('duplicate titles get separate folders', async () => {
    const parent = path.join(root, 'Videos');
    const a = uniqueFolderPath(parent, 'MrBeast', []);
    const b = uniqueFolderPath(parent, 'MrBeast', [a]);
    const c = uniqueFolderPath(parent, 'MrBeast', [a, b]);
    assert.equal(path.basename(a), 'MrBeast');
    assert.equal(path.basename(b), 'MrBeast (2)');
    assert.equal(path.basename(c), 'MrBeast (3)');
  });

  await ok('isJpegBuffer accepts JPEG magic only', async () => {
    assert.equal(isJpegBuffer(JPEG), true);
    assert.equal(isJpegBuffer(Buffer.from('not an image')), false);
  });

  await ok('newest thumbnail replaces old FOLDER.JPG and deletes stale variants', async () => {
    const folder = path.join(root, 'MrBeast');
    fs.mkdirSync(folder, { recursive: true });
    fs.writeFileSync(path.join(folder, 'FOLDER.JPG'), JPEG);
    fs.writeFileSync(path.join(folder, 'FOLDER.jpg'), JPEG);
    fs.writeFileSync(path.join(folder, 'FOLDER.webp'), JPEG);
    fs.writeFileSync(path.join(folder, '.FOLDER.JPG.crashed.tmp'), JPEG);
    fs.writeFileSync(path.join(folder, 'video.mp4'), 'keep me');

    const res = await replaceFolderThumbnail({
      folderPath: folder,
      candidates: ['https://example.test/a.jpg', 'https://example.test/b.jpg'],
      fetchImage: async (url) => {
        if (url.endsWith('a.jpg')) throw new Error('404');
        return Buffer.from(JPEG2);
      },
      writeJpeg: fakeWrite,
    });
    assert.equal(res.success, true);
    assert.equal(path.basename(res.path), 'FOLDER.JPG');
    assert.deepEqual(fs.readFileSync(path.join(folder, 'FOLDER.JPG')), JPEG2);
    assert.deepEqual(
      fs.readdirSync(folder).sort(),
      ['FOLDER.JPG', 'video.mp4'].sort()
    );
  });

  await ok('all candidates failing leaves the old picture untouched', async () => {
    const folder = path.join(root, 'Channel');
    fs.mkdirSync(folder, { recursive: true });
    fs.writeFileSync(path.join(folder, 'FOLDER.JPG'), JPEG);
    await assert.rejects(
      () => replaceFolderThumbnail({
        folderPath: folder,
        candidates: ['https://example.test/missing.jpg'],
        fetchImage: async () => { throw new Error('offline'); },
        writeJpeg: fakeWrite,
      }),
      /offline|No thumbnail/
    );
    assert.deepEqual(fs.readFileSync(path.join(folder, 'FOLDER.JPG')), JPEG);
    assert.deepEqual(fs.readdirSync(folder), ['FOLDER.JPG']);
  });

  await ok('non-JPEG staged bytes are rejected, not renamed', async () => {
    const folder = path.join(root, 'BadImage');
    fs.mkdirSync(folder, { recursive: true });
    fs.writeFileSync(path.join(folder, 'FOLDER.JPG'), JPEG);
    await assert.rejects(
      () => replaceFolderThumbnail({
        folderPath: folder,
        candidates: ['https://example.test/bad.jpg'],
        fetchImage: fakeFetch(JPEG),
        writeJpeg: async (_buf, filePath) => fs.writeFileSync(filePath, 'PNG-ish'),
      }),
      /not written as JPEG/
    );
    assert.deepEqual(fs.readFileSync(path.join(folder, 'FOLDER.JPG')), JPEG);
    assert.deepEqual(fs.readdirSync(folder), ['FOLDER.JPG']);
  });

  console.log(`\n${checks}/${checks} subscription folder thumbnail checks passed.`);
} catch (error) {
  console.error(`FAILED: ${error.stack || error.message}`);
  process.exitCode = 1;
} finally {
  try { fs.rmSync(root, { recursive: true, force: true }); } catch (e) { }
}
