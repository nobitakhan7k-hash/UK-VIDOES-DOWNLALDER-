/**
 * Static checks for the whole-GUI text cleanup.
 * Goal: only short names, buttons, field labels, errors and live status remain;
 * no example placeholders, hint strips, feature explanations or long tooltips.
 */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';

const read = (p) => fs.readFileSync(path.resolve(p), 'utf8');
let checks = 0;
const ok = (name, fn) => {
  fn();
  checks += 1;
  console.log(`  ok  ${name}`);
};

const GUI_FILES = [
  'src/components/App.jsx',
  'src/components/ContactDialog.jsx',
  'src/components/DetailsView.jsx',
  'src/components/Header.jsx',
  'src/components/HistoryView.jsx',
  'src/components/KeywordView.jsx',
  'src/components/LicenseDialog.jsx',
  'src/components/LoadingComponent.jsx',
  'src/components/PlaylistView.jsx',
  'src/components/PlaylistsView.jsx',
  'src/components/SettingsDialog.jsx',
  'src/components/SubscriptionsView.jsx',
  'src/contexts/AppContext.jsx',
  'src/lib/fetchErrors.js',
  'src/browse-preload.js',
  'src/main.js',
];
const gui = GUI_FILES.map((f) => ({ f, s: read(f) }));
const all = gui.map((x) => x.s).join('\n');
const findAll = (needle) => gui.filter((x) => x.s.includes(needle)).map((x) => x.f);

console.log('\nGUI text cleanup checks\n');

ok('example placeholders are gone (e.g. PAK OST / key format / long paste hints)', () => {
  for (const s of [
    'e.g. PAK OST',
    'UKD-6M-XXXXXXXX-XXXXXXXX or UKD-LIFE-XXXXXXXX-XXXXXXXX',
    'placeholder="UKD-6M-XXXXXXXX-XXXXXXXX"',
    'Paste a YouTube / playlist link…',
    'Paste a YouTube playlist link, or a channel URL (@handle)…',
    'Paste a link or type a song name...',
  ]) {
    assert.deepEqual(findAll(s), [], `leftover: ${s}`);
  }
});

ok('keyword page has no scan explanation, hint strip or telemetry note', () => {
  const view = read('src/components/KeywordView.jsx');
  for (const s of [
    'Scan YouTube search pages',
    '1 page = 20 YouTube results',
    'Time filter = upload date',
    'no search history / no telemetry',
    'most views first',
    'how many TOP videos',
    'Downloads use Settings → Video output',
    'Keyword Search',
  ]) {
    assert.ok(!view.includes(s), `leftover in KeywordView: ${s}`);
  }
});

ok('keyword page keeps a short page name and all functional controls', () => {
  const view = read('src/components/KeywordView.jsx');
  assert.ok(/\n\s+Search\n/.test(view), 'missing short page name: Search');
  for (const s of [
    'Keyword', 'Pages', 'Upload time', 'SCAN',
    'Top videos', 'Top count', 'DOWNLOAD TOP', 'Results (',
    'keywordScan', 'queueVideoBatch',
  ]) {
    assert.ok(view.includes(s), `missing in KeywordView: ${s}`);
  }
});

ok('header tooltips are short names, not feature explanations', () => {
  const header = read('src/components/Header.jsx');
  for (const s of [
    'Browse YouTube — right-click a video to download it',
    'Playlists — open a playlist or download every video',
    'Keyword Search — scan pages, filter by upload time, download top by views',
    'Follow playlists and channels',
    'Pro active · view license',
    'Pro key · active',
  ]) {
    assert.ok(!header.includes(s), `leftover in Header: ${s}`);
  }
  assert.ok(header.includes('DOWNLOAD'));
  assert.ok(header.includes('By Usman'));
  assert.ok(header.includes('PRO'));
  assert.ok(header.includes('aria-label="Search"'));
});

ok('Settings has no preset spec, privacy reassurance or long help lines', () => {
  const ui = read('src/components/SettingsDialog.jsx');
  for (const s of [
    'What the preset does',
    'Your data stays on this device',
    'Nothing is tracked or logged.',
    'Select your preferred appearance',
    'used by every single-video download',
    'Type a song name in the top bar instead of a link',
    'Off by default. Private/deleted entries',
    'Skip the Save dialog and drop straight into the folder below.',
    'Checks on launch, then every 6 hours',
    'Default 1 · custom 1–50. Set 20',
    'UK Downloader · local only',
  ]) {
    assert.ok(!ui.includes(s), `leftover in Settings: ${s}`);
  }
});

ok('Settings still exposes every working control and short label', () => {
  const ui = read('src/components/SettingsDialog.jsx');
  for (const s of [
    '720p HD', '480p HD', 'MP3 audio', 'Ask me every time',
    'Connections', 'PARALLEL_PRESETS.map', 'Custom ', 'Apply',
    'Results to download', 'Number playlist downloads',
    'Download in one click', 'Theme', 'General', 'Video', 'Account',
    'Check for updates', 'Sign in with Google',
  ]) {
    assert.ok(ui.includes(s), `missing in Settings: ${s}`);
  }
});

ok('no page subtitles, hint strips or footer notes remain', () => {
  for (const s of [
    'Open a full playlist or download every video in one click',
    'Free 10/day · Pro bypass',
    'A subfolder named after this playlist is created here',
    'Checks run in the background while UK Downloader is open',
    'Follow a YouTube playlist or channel once',
    'Instant preparing row',
    'Saved for this playlist',
    'This playlist keeps its own folder',
    'Re-encodes VP9/AV1 videos to H.264 on-device',
    'If checked, existing files with the same name will be replaced.',
    'Requires heavy CPU and extra processing time',
    'Compatibility Warning',
    'VP9 / AV1 may not be supported by some editors',
    'WhatsApp contact card · point your phone camera at the QR',
    'The “By Usman” button is now the PRO button.',
    'No download history is kept.',
    'Finished downloads clear from this list automatically',
  ]) {
    assert.deepEqual(findAll(s), [], `leftover: ${s}`);
  }
});

ok('dialog descriptions and tooltips contain no long explanations', () => {
  const longOnes = [
    'Stop every queued / running download at once',
    'The video has already been downloaded. You can stop the conversion',
    'This will permanently remove all download history entries',
    'You won\'t be able to download age-restricted videos until you sign in again.',
    'Auto-download new videos added to this playlist',
    'Unsubscribe immediately — no confirmation',
    'Rebuild full playlist ID list (no downloads)',
    'Every video id in this playlist is stored locally',
    'Completed videos leave the list below',
    'Settings → Video → "Playlist file numbering"',
    'While a playlist page is open, dragging a playlist link',
    'Go back one page',
    'Rebuild full playlist ID list',
  ];
  for (const s of longOnes) {
    assert.deepEqual(findAll(s), [], `leftover tooltip/dialog: ${s}`);
  }
});

ok('short page names remain on every main screen', () => {
  assert.ok(read('src/components/HistoryView.jsx').includes('Downloads'));
  assert.ok(read('src/components/HistoryView.jsx').includes('History'));
  assert.ok(read('src/components/PlaylistsView.jsx').includes('Playlists'));
  assert.ok(read('src/components/SubscriptionsView.jsx').includes('Subscriptions'));
  assert.ok(/\n\s+Search\n/.test(read('src/components/KeywordView.jsx')));
});

ok('required buttons and status labels are intact', () => {
  for (const s of [
    'DOWNLOAD', 'SCAN', 'DOWNLOAD TOP', 'Cancel All', 'Check all',
    'Export', 'Import', 'Auto-download', 'Choose folder…',
    'No playlists yet.', 'No subscriptions yet', 'No videos found.',
    'No downloads.', 'By Usman', 'PRO', 'Enter Pro key', 'Activate Pro',
  ]) {
    assert.ok(all.includes(s), `missing functional label: ${s}`);
  }
});

ok('previous UI cleanup is still intact (no In Progress, no / Kbd badge)', () => {
  assert.deepEqual(findAll('In Progress'), []);
  assert.deepEqual(findAll('<Kbd>/</Kbd>'), []);
  assert.deepEqual(findAll('Version 2.0.1 · powered by yt-dlp'), []);
});

ok('no AI/iteration traces in source comments', () => {
  const srcFiles = fs.readdirSync(path.resolve('src/components'))
    .filter((n) => n.endsWith('.jsx')).map((n) => `src/components/${n}`)
    .concat([
      'src/main.js', 'src/preload.js', 'src/browse-preload.js',
      'src/contexts/AppContext.jsx', 'src/lib/keywordScan.cjs',
      'src/lib/searchInput.mjs', 'src/lib/fetchErrors.js',
    ]);
  const joined = srcFiles.map((f) => read(f)).join('\n');
  for (const s of [
    'Decisions confirmed with the user',
    'The user asked for',
    'Flavour the user asked for',
    'user asked for this one',
    'v10: ', 'v9: ', 'v8: ', 'v11: ',
  ]) {
    assert.ok(!joined.includes(s), `leftover dev comment: ${s}`);
  }
});

ok('GUI error/status copy is short', () => {
  const main = read('src/main.js');
  for (const s of [
    'Wrong key format. Expected UKD-6M-XXXXXXXX-XXXXXXXX',
    'yt-dlp is updating in the background, please try again in a moment.',
    'Is the playlist empty or private?',
  ]) {
    assert.ok(!main.includes(s), `leftover long error: ${s}`);
  }
  const errs = read('src/lib/fetchErrors.js');
  assert.ok(!errs.includes('The URL may be invalid, or the video might be unavailable.'));
  assert.ok(errs.includes('Please check the link and try again.'));
});

ok('behaviour behind the removed text is untouched', () => {
  const main = read('src/main.js');
  for (const s of [
    'FOLDER_THUMBNAIL_NAME', 'ensureFolder', 'replaceFolderThumbnail',
    "ipcMain.handle('keyword-page:scan'", 'getConcurrentFragments',
    '--concurrent-fragments', 'clampParallel', 'resumeQueueV1',
    'cancel-all-jobs', 'ukdownloader',
  ]) {
    assert.ok(main.includes(s), `missing behaviour: ${s}`);
  }
  assert.ok(!main.includes('createServer'));
  assert.ok(!main.includes('.listen('));
});

console.log(`\n${checks}/${checks} GUI text cleanup checks passed.`);
