/**
 * Unit + wiring checks for Browse-window keyword folders / folder.jpg.
 * Run from the project root: node scripts/verify-keyword-folder.mjs
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const k = require('../src/lib/keywordFolder.cjs');
const s = require('../src/lib/subscriptionFolder.cjs');
const read = (rel) => fs.readFileSync(path.resolve(rel), 'utf8');

let checks = 0;
const ok = (label, fn) => {
  fn();
  checks += 1;
  console.log(`ok ${checks} - ${label}`);
};
const okAsync = async (label, fn) => {
  await fn();
  checks += 1;
  console.log(`ok ${checks} - ${label}`);
};

const JPEG = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46]);
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'uk-keyword-folder-'));
const writeJpeg = async (buf, filePath) => { fs.writeFileSync(filePath, buf); };
const goodFetch = async () => JPEG;
const badFetch = async () => { throw new Error('CDN offline'); };

console.log('\nBrowse keyword folder checks\n');

try {
  ok('thumbnail name is exactly lowercase folder.jpg', () => {
    assert.equal(k.KEYWORD_THUMBNAIL_NAME, 'folder.jpg');
    assert.equal(s.FOLDER_THUMBNAIL_NAME, 'FOLDER.JPG'); // subscriptions unchanged
  });

  ok('safeKeyword is string-only, collapses spaces and caps length', () => {
    assert.equal(k.safeKeyword('  Indian   Song  '), 'Indian Song');
    assert.equal(k.safeKeyword('x'.repeat(300)).length, k.KEYWORD_MAX_CHARS);
    assert.equal(k.safeKeyword(''), '');
    assert.equal(k.safeKeyword('   '), '');
    for (const v of [null, undefined, 42, {}, [], { type: 'click' }]) {
      assert.equal(k.safeKeyword(v), '');
    }
  });

  ok('safeKeyword rejects URLs and stringified objects', () => {
    assert.equal(k.safeKeyword('https://www.youtube.com/watch?v=abc'), '');
    assert.equal(k.safeKeyword('[object Object]'), '');
    assert.equal(k.safeKeyword('[object KeyboardEvent]'), '');
  });

  ok('keywordFolderPath is Windows-safe and stable', () => {
    const parent = path.join(root, 'Downloads');
    const a = k.keywordFolderPath(parent, 'Indian Song');
    const b = k.keywordFolderPath(parent, '  Indian   Song  ');
    assert.equal(a, b);
    assert.equal(path.basename(a), 'Indian Song');
    assert.equal(path.dirname(a), parent);
    const unsafe = k.keywordFolderPath(parent, 'A/B:C*D?E"F<G>H|I');
    assert.ok(!/[\\/:*?"<>|]/.test(path.basename(unsafe)));
    assert.equal(path.basename(k.keywordFolderPath(parent, 'CON')).startsWith('Search_'), true);
    assert.notEqual(k.keywordFolderPath(parent, 'Indian Song'), k.keywordFolderPath(parent, 'Pak Song'));
    assert.equal(k.keywordFolderPath(parent, ''), parent);
    assert.throws(() => k.keywordFolderPath('', 'Indian Song'));
  });

  ok('ensureKeywordFolder creates the folder on disk', () => {
    const parent = path.join(root, 'Out');
    const folder = k.ensureKeywordFolder(parent, 'Indian Song');
    assert.equal(folder, path.join(parent, 'Indian Song'));
    assert.equal(fs.statSync(folder).isDirectory(), true);
    assert.equal(k.ensureKeywordFolder(parent, 'Indian Song'), folder); // idempotent
  });

  ok('thumbnail candidates prefer clean i.ytimg.com JPEGs', () => {
    const list = k.keywordThumbnailCandidates(
      'https://i.ytimg.com/vi/abcdefghijk/hqdefault.jpg', 'abcdefghijk');
    assert.equal(list[0], 'https://i.ytimg.com/vi/abcdefghijk/hqdefault.jpg');
    assert.ok(list.includes('https://i.ytimg.com/vi/abcdefghijk/maxresdefault.jpg'));
    assert.ok(list.includes('https://i.ytimg.com/vi/abcdefghijk/hq720.jpg'));
    assert.equal(new Set(list).size, list.length);
    assert.ok(list.every(u => u.endsWith('.jpg')));
  });

  ok('thumbnail candidates fall back to the video id and fix URLs', () => {
    const byId = k.keywordThumbnailCandidates('', 'abcdefghijk');
    assert.equal(byId.length, 4);
    assert.equal(byId[0], 'https://i.ytimg.com/vi/abcdefghijk/maxresdefault.jpg');
    const rel = k.keywordThumbnailCandidates('//cdn.example.com/pic.webp', '');
    assert.equal(rel[0], 'https://cdn.example.com/pic.webp');
    assert.deepEqual(k.keywordThumbnailCandidates('', ''), []);
  });

  await okAsync('replaceFolderThumbnail writes folder.jpg and clears stale pictures', async () => {
    const folder = path.join(root, 'Thumb');
    fs.mkdirSync(folder, { recursive: true });
    fs.writeFileSync(path.join(folder, 'FOLDER.JPG'), JPEG);
    fs.writeFileSync(path.join(folder, 'folder.png'), JPEG);
    fs.writeFileSync(path.join(folder, '.folder.jpg.crashed.tmp'), JPEG);
    const res = await s.replaceFolderThumbnail({
      folderPath: folder,
      candidates: ['https://i.ytimg.com/vi/abcdefghijk/hqdefault.jpg'],
      fetchImage: goodFetch,
      writeJpeg,
      fileName: k.KEYWORD_THUMBNAIL_NAME,
    });
    assert.equal(res.success, true);
    assert.equal(path.basename(res.path), 'folder.jpg');
    assert.deepEqual(fs.readdirSync(folder).sort(), ['folder.jpg']);
    assert.deepEqual(fs.readFileSync(path.join(folder, 'folder.jpg')), JPEG);
  });

  await okAsync('a failed fetch keeps the existing folder.jpg', async () => {
    const folder = path.join(root, 'Thumb2');
    fs.mkdirSync(folder, { recursive: true });
    fs.writeFileSync(path.join(folder, 'folder.jpg'), JPEG);
    await assert.rejects(() => s.replaceFolderThumbnail({
      folderPath: folder,
      candidates: ['https://bad.example/x.jpg'],
      fetchImage: badFetch,
      writeJpeg,
      fileName: k.KEYWORD_THUMBNAIL_NAME,
    }));
    assert.deepEqual(fs.readdirSync(folder), ['folder.jpg']);
    assert.deepEqual(fs.readFileSync(path.join(folder, 'folder.jpg')), JPEG);
  });

  ok('main imports helpers and captures Browse search terms', () => {
    const main = read('src/main.js');
    assert.ok(main.includes("require('./lib/keywordFolder.cjs')"));
    assert.ok(main.includes('KEYWORD_THUMBNAIL_NAME'));
    assert.ok(main.includes('function searchQueryFromUrl'));
    assert.ok(main.includes('function captureBrowseKeyword'));
    assert.ok(main.includes('function currentBrowseKeyword'));
    assert.ok(main.includes("ipcMain.on('browse:search-query'"));
    assert.ok(main.includes('captureBrowseKeyword(wc.getURL())'));
    assert.ok(main.includes("browseWindow.on('closed', () => { browseWindow = null; browseKeyword = ''; })"));
  });

  ok('right-click download carries the keyword into the batch queue', () => {
    const main = read('src/main.js');
    const ctx = read('src/contexts/AppContext.jsx');
    assert.ok(main.includes("safeSend('browse-download-url', {"));
    assert.ok(main.includes('keyword: currentBrowseKeyword()'));
    assert.ok(ctx.includes('const fn = directDownloadRef.current;'));
    assert.ok(ctx.includes('fn([url], { keyword })'));
    assert.ok(ctx.includes('api.queueVideoBatch({ items, targetDir, keyword })'));
  });

  ok('batch queue builds the keyword folder and refreshes one thumbnail', () => {
    const main = read('src/main.js');
    assert.ok(main.includes('const keyword = safeKeyword(options.keyword);'));
    assert.ok(main.includes('jobTargetDir = ensureKeywordFolder(targetDir, keyword);'));
    assert.ok(main.includes('resolveOutputPath(jobTargetDir, numberedTitle, ext, true)'));
    assert.ok(main.includes('queueKeywordThumbnailUpdate(jobTargetDir,'));
    assert.ok(main.includes('keywordThumbnailCandidates(items[0].thumbnailUrl, items[0].videoId)'));
    assert.ok(main.includes('fileName: KEYWORD_THUMBNAIL_NAME'));
    assert.ok(main.includes("writeJpeg,"));
    // Thumbnail / folder problems must never cancel the videos.
    assert.ok(main.includes("console.log('Keyword folder unavailable (non-critical):'"));
  });

  ok('Browse preload reports search terms without window.ukBrowse', () => {
    const pre = read('src/browse-preload.js');
    assert.ok(pre.includes('function currentSearchQuery'));
    assert.ok(pre.includes('function reportSearchQuery'));
    assert.ok(pre.includes("ipcRenderer.send('browse:search-query'"));
    assert.ok(pre.includes('search_query'));
    assert.ok(!pre.includes('window.ukBrowse.'));
    assert.ok(pre.includes("u.pathname !== '/results' && u.pathname !== '/search'"));
  });

  ok('other download paths are unchanged and no server / v11 features appear', () => {
    const playlists = read('src/components/PlaylistsView.jsx');
    const keyword = read('src/components/KeywordView.jsx');
    const main = read('src/main.js');
    assert.ok(playlists.includes('{ items, targetDir }'));
    assert.ok(keyword.includes('{ items, targetDir }'));
    assert.ok(!main.includes('createServer'));
    assert.ok(!main.includes('.listen('));
    assert.ok(!main.includes('autoStart'));
    assert.ok(!main.includes('convertLegacy'));
    assert.ok(main.includes('--concurrent-fragments'));
    assert.ok(main.includes('resumeQueueV1'));
    assert.ok(main.includes('cancel-all-jobs'));
  });

  console.log(`\n${checks}/${checks} Browse keyword folder checks passed.`);
} catch (error) {
  console.error(`FAILED: ${error.stack || error.message}`);
  process.exitCode = 1;
} finally {
  try { fs.rmSync(root, { recursive: true, force: true }); } catch (e) { }
}
