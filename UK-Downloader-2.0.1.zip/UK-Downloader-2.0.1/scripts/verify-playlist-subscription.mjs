/**
 * Smart playlist subscriptions — logic, storage and wiring.
 * Run from the project root: node scripts/verify-playlist-subscription.mjs
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const lib = require('../src/lib/playlistSubscription.cjs');
const read = (p) => fs.readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

const main = read('src/main.js');
const preload = read('src/preload.js');
const ctx = read('src/contexts/AppContext.jsx');
const view = read('src/components/SubscriptionsView.jsx');

let pass = 0;
const ok = (name, fn) => {
  try { fn(); pass += 1; console.log(`ok ${pass} - ${name}`); }
  catch (e) { console.error(`not ok ${pass + 1} - ${name}\n    ${e.message}`); process.exitCode = 1; }
};

const entry = (id, title = `Video ${id}`) => ({ id, title, url: `https://www.youtube.com/watch?v=${id}`, playlistIndex: 1 });

// ── Delta logic ────────────────────────────────────────────────────────────
ok('a playlist with no saved id only records the newest video', () => {
  const plan = lib.findNewVideos([entry('c'), entry('b'), entry('a')], '', {});
  assert.equal(plan.baseline, true);
  assert.equal(plan.latestId, 'c');
  assert.deepEqual(plan.newVideos, []);
});

ok('matching newest id means nothing to do', () => {
  const plan = lib.findNewVideos([entry('c'), entry('b'), entry('a')], 'c', {});
  assert.equal(plan.unchanged, true);
  assert.deepEqual(plan.newVideos, []);
  assert.equal(plan.anchorMissing, false);
});

ok('new videos are returned oldest first, one per position above the anchor', () => {
  // newest → oldest: e d c b a ; anchor = b  → new = c, d, e → oldest first c,d,e
  const plan = lib.findNewVideos([entry('e'), entry('d'), entry('c'), entry('b'), entry('a')], 'b', {});
  assert.deepEqual(plan.newVideos.map(v => v.id), ['c', 'd', 'e']);
});

ok('several new episodes between two scans are all returned', () => {
  const list = ['j', 'i', 'h', 'g', 'f', 'e', 'd', 'c', 'b', 'a'].map(id => entry(id));
  const plan = lib.findNewVideos(list, 'b', {});
  assert.deepEqual(plan.newVideos.map(v => v.id), ['c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']);
});

ok('private / deleted entries are skipped but never break the chain', () => {
  const list = [
    entry('e'), { id: 'd', title: '[Private video]' }, entry('c'),
    { id: 'b', title: '[Deleted video]' }, entry('a'),
  ];
  // anchor is the deleted row: it must still be FOUND (no mass re-download)
  const plan = lib.findNewVideos(list, 'b', {});
  assert.equal(plan.anchorMissing, false);
  assert.deepEqual(plan.newVideos.map(v => v.id), ['c', 'e']);
  assert.equal(plan.skipped, 1);
});

ok('a vanished anchor falls back to a bounded batch instead of the whole playlist', () => {
  const list = Array.from({ length: 40 }, (_, i) => entry(`v${40 - i}`));
  const plan = lib.findNewVideos(list, 'gone', { anchorMissingMax: 10 });
  assert.equal(plan.anchorMissing, true);
  assert.equal(plan.newVideos.length, 10);
  // the ten NEWEST of the window, still queued oldest first
  assert.equal(plan.newVideos[0].id, 'v31');
  assert.equal(plan.newVideos[9].id, 'v40');
});

ok('empty playlist is a no-op, not a crash', () => {
  const plan = lib.findNewVideos([], 'abc', {});
  assert.equal(plan.unchanged, true);
  assert.deepEqual(plan.newVideos, []);
});

// ── Anchor rules ───────────────────────────────────────────────────────────
ok('the saved id only moves after a successful download', () => {
  assert.equal(lib.advanceAnchor('old', { id: 'new' }, { outcome: 'downloaded' }), 'new');
  assert.equal(lib.advanceAnchor('old', { id: 'new' }, { outcome: 'failed' }), 'old');
  assert.equal(lib.advanceAnchor('old', { id: 'new' }, { outcome: 'cancelled' }), 'old');
});

ok('a manually queued (existing) video can never drag the saved id back', () => {
  assert.equal(lib.advanceAnchor('newest', { id: 'older' }, { auto: false }), 'newest');
  assert.equal(lib.advanceAnchor('', { id: 'anything' }, { auto: false }), '');
});

ok('scan cadence follows the per-playlist interval', () => {
  const now = Date.now();
  const sub = (minutes, last) => ({ enabled: true, intervalMinutes: minutes, lastCheckedAt: last });
  assert.equal(lib.isScanDue(sub(15, now - 16 * 60 * 1000), now, 15), true);
  assert.equal(lib.isScanDue(sub(15, now - 5 * 60 * 1000), now, 15), false);
  assert.equal(lib.isScanDue(sub(60, now - 30 * 60 * 1000), now, 15), false);
  assert.equal(lib.isScanDue({ ...sub(5, 0), enabled: false }, now, 15), false);
});

ok('detected rows merge without duplicates and keep chronological order', () => {
  const merged = lib.mergeDetected(
    [{ id: 'a', status: 'found' }, { id: 'b', status: 'found' }],
    [{ id: 'b', status: 'found' }, { id: 'c', status: 'found' }],
    30,
  );
  assert.deepEqual(merged.map(v => v.id), ['b', 'c', 'a']);
});

// ── JSON document ──────────────────────────────────────────────────────────
ok('the stored document uses the documented keys', () => {
  const doc = lib.toStorageDocument([{
    id: 'sub-1', url: 'https://www.youtube.com/playlist?list=X',
    title: 'Nashtar', lastVideoId: 'abc123', enabled: true,
    quality: 'hd720', knownIds: ['a', 'b'], knownIdsComplete: true, knownCount: 2,
  }]);
  assert.deepEqual(Object.keys(doc), ['subscriptions']);
  const rec = doc.subscriptions[0];
  assert.equal(rec.name, 'Nashtar');
  assert.equal(rec.url, 'https://www.youtube.com/playlist?list=X');
  assert.equal(rec.last_video_id, 'abc123');
  assert.equal(rec.enabled, true);
  assert.equal('knownIds' in rec, false, 'id arrays must never be written');
  assert.equal('knownCount' in rec, false);
  assert.equal(rec.quality, 'hd720', 'other settings must survive');
});

ok('each playlist keeps its own id', () => {
  const doc = lib.toStorageDocument([
    { url: 'u1', title: 'One', lastVideoId: 'id-one' },
    { url: 'u2', title: 'Two', lastVideoId: 'id-two' },
  ]);
  assert.deepEqual(doc.subscriptions.map(s => s.last_video_id), ['id-one', 'id-two']);
});

ok('reading tolerates every older spelling of the key', () => {
  const list = lib.fromStorageDocument({
    subscriptions: [
      { name: 'A', url: 'u1', last_video_id: 'x1', enabled: true },
      { name: 'B', url: 'u2', lastVideoId: 'x2' },
      { title: 'C', url: 'u3', last_video: 'x3' },
    ],
  });
  assert.deepEqual(list.map(s => s.lastVideoId), ['x1', 'x2', 'x3']);
  assert.equal(list[0].title, 'A');
});

// ── Atomic storage ─────────────────────────────────────────────────────────
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ukd-subs-'));
const file = path.join(tmp, 'subscriptions.json');

ok('saving replaces the file atomically and leaves no temp behind', () => {
  lib.saveSubscriptionsFile(file, [{ url: 'u1', title: 'One', lastVideoId: 'a' }]);
  const first = JSON.parse(fs.readFileSync(file, 'utf8'));
  assert.equal(first.subscriptions[0].last_video_id, 'a');

  lib.saveSubscriptionsFile(file, [{ url: 'u1', title: 'One', lastVideoId: 'b' }]);
  const second = JSON.parse(fs.readFileSync(file, 'utf8'));
  assert.equal(second.subscriptions[0].last_video_id, 'b');

  const leftovers = fs.readdirSync(tmp).filter(n => n.endsWith('.tmp'));
  assert.deepEqual(leftovers, [], 'a temp file was left behind');

  const backup = JSON.parse(fs.readFileSync(`${file}.bak`, 'utf8'));
  assert.equal(backup.subscriptions[0].last_video_id, 'a', 'previous version kept as .bak');
});

ok('a corrupt file falls back to the backup instead of losing everything', () => {
  fs.writeFileSync(file, '{ this is not json');
  const list = lib.readSubscriptionsFile(file);
  assert.equal(list.length, 1);
  assert.equal(list[0].lastVideoId, 'a');
});

ok('writing into a missing directory creates it', () => {
  const nested = path.join(tmp, 'deep', 'dir', 'subscriptions.json');
  lib.saveSubscriptionsFile(nested, [{ url: 'u', title: 'T', lastVideoId: 'z' }]);
  assert.ok(fs.existsSync(nested));
});

// ── main-process wiring ────────────────────────────────────────────────────
ok('subscriptions live in their own JSON file, written atomically', () => {
  assert.ok(main.includes("const SUBS_FILE = 'subscriptions.json'"));
  assert.ok(main.includes('readSubscriptionsFile(subscriptionsFile())'));
  assert.ok(main.includes('saveSubscriptionsFile(subscriptionsFile(), subsCache)'));
  assert.ok(!main.includes('store.set(SUBS_KEY'), 'the old store key must be gone');
});

ok('scanning is flat-playlist metadata only', () => {
  const scan = main.slice(main.indexOf('async function fetchFeedWindow'), main.indexOf('// ---------------------------------------------------------------------------\n// Queueing'));
  assert.ok(scan.includes("'--flat-playlist'"));
  assert.ok(scan.includes("'--playlist-end'"));
  assert.ok(!scan.includes('--extract-audio'));
  assert.ok(!main.slice(main.indexOf('async function fetchFeedWindow')).slice(0, 3000).includes('downloadQueue.push'));
});

ok('only one download per playlist is ever in flight', () => {
  assert.ok(main.includes('function subscriptionHasActiveJob(subId)'));
  assert.ok(main.includes("j.status === 'queued' || j.status === 'downloading'"));
  assert.ok(main.includes('if (subscriptionHasActiveJob(subId)) return;'));
  assert.ok(main.includes("if (!subId || subPumpBusy.has(subId)) return;"));
});

ok('the saved id advances only in the verified-success branch', () => {
  const fn = main.slice(main.indexOf('async function handleSubscriptionJobResult'), main.indexOf('/**\n * One-time tidy'));
  assert.ok(fn.includes('const check = await verifyMediaFile('));
  assert.ok(fn.includes('sub.lastVideoId = advanceAnchor(sub.lastVideoId, { id: videoId })'));
  const failureBranch = fn.slice(fn.indexOf('} else {'));
  assert.ok(!failureBranch.includes('sub.lastVideoId ='), 'failure branch must not touch the anchor');
  assert.ok(fn.includes('Anchor deliberately untouched'));
});

ok('ffprobe verifies every subscription download', () => {
  assert.ok(main.includes('function verifyMediaFile('));
  assert.ok(main.includes('ffprobePath'));
  assert.ok(main.includes("'-show_entries', 'format=duration:stream=codec_type'"));
  assert.ok(main.includes('did not pass the ffprobe check'));
});

ok('a failed scan keeps the previous saved id', () => {
  const fn = main.slice(main.indexOf('async function checkSubscription'), main.indexOf('function notifySafe'));
  const catchBranch = fn.slice(fn.indexOf('} catch (error) {'), fn.indexOf('} finally {'));
  assert.ok(catchBranch.includes("sub.lastStatus = 'error'"));
  assert.ok(!catchBranch.includes('lastVideoId ='), 'scan failure must not move the id');
  assert.ok(catchBranch.includes('sub.lastCheckedAt = Date.now()'));
});

ok('unavailable videos are flagged at scan time and never queued', () => {
  assert.ok(main.includes('unavailable: unavailable || !url'));
  assert.ok(main.includes('const plan = findNewVideos(feed.entries'));
  assert.ok(main.includes('skippedUnavailable'));
});

ok('start / stop / interval are real IPC endpoints', () => {
  for (const ch of ['subscriptions:scan-start', 'subscriptions:scan-stop',
    'subscriptions:scan-interval', 'subscriptions:scan-state']) {
    assert.ok(main.includes(`ipcMain.handle('${ch}'`), `missing ${ch}`);
  }
  assert.ok(main.includes('function startScanEngine('));
  assert.ok(main.includes('function stopScanEngine('));
  assert.ok(main.includes("safeSend('subscription-scan-state'"));
  assert.ok(preload.includes('startSubscriptionScan:'));
  assert.ok(preload.includes('stopSubscriptionScan:'));
  assert.ok(preload.includes('setSubscriptionScanInterval:'));
});

ok('a stopped engine performs no scheduled scans', () => {
  assert.ok(main.includes('if (!state.running) return;'));
  assert.ok(main.includes('if (!onlyId && !engine.running) continue;'));
});

ok('resume + restart re-queues whatever was detected but unfinished', () => {
  assert.ok(main.includes('function resumeSubscriptionPumps()'));
  assert.ok(main.includes('try { resumeSubscriptionPumps(); }'));
  assert.ok(main.includes('setTimeout(() => pumpSubscriptionDownloads(sub.id), 1500)'));
});

ok('migration drops the old id arrays for good', () => {
  assert.ok(main.includes('function migrateSubscriptions()'));
  assert.ok(main.includes("for (const key of ['knownIds', 'knownIdsComplete', 'knownCount', 'pendingCount'])"));
  assert.ok(main.includes('store.delete(SUBS_KEY_LEGACY)'));
  assert.ok(!main.includes('knownIds = uniqueIds'));
});

ok('export / import use the same documented JSON shape', () => {
  assert.ok(main.includes('...toStorageDocument(list),'));
  assert.ok(main.includes('writeJsonAtomic(res.filePath, payload)'));
  assert.ok(main.includes('.map(normalizeRecord)'));
});

// ── GUI ────────────────────────────────────────────────────────────────────
ok('the page has Start Scan, Stop Scan and Scan Interval', () => {
  assert.ok(view.includes('Start Scan'));
  assert.ok(view.includes('Stop Scan'));
  assert.ok(view.includes('setSubscriptionScanInterval'));
  assert.ok(view.includes('INTERVAL_OPTIONS'));
  assert.ok(view.includes('<ScanBadge running={scanning} />'));
});

ok('the card shows the saved id and download status', () => {
  assert.ok(view.includes('{savedId}'));
  assert.ok(view.includes('Last video ID'));
  assert.ok(view.includes('<StatusChip status={status} percent={live?.percent} />'));
  assert.ok(view.includes('saved ID kept'));
  assert.ok(!view.includes('IDs tracked'), 'the id-count badge must be gone');
});

ok('the renderer talks only to the preload bridge', () => {
  assert.ok(ctx.includes('startSubscriptionScan'));
  assert.ok(ctx.includes('stopSubscriptionScan'));
  assert.ok(ctx.includes('window.electronAPI.onSubscriptionScanState'));
  assert.ok(!ctx.includes('require('), 'no direct main-process access');
});

ok('no server, telemetry or id history crept in', () => {
  for (const file of [main, preload, view, ctx]) {
    assert.ok(!file.includes('createServer'));
    assert.ok(!file.includes('http://127.0.0.1'));
  }
  const libSrc = read('src/lib/playlistSubscription.cjs');
  assert.ok(!libSrc.includes('downloaded_ids'));
  // any mention of the old key list is the skip-list that deletes it
  assert.ok(!/knownIds\s*:\s*\[/.test(libSrc), 'no id array may be written');
});

// ── Whole-flow simulation through the real functions ───────────────────────
ok('end to end: detect, download in order, advance only on success, retry on failure', () => {
  const playlist = [entry('e'), entry('d'), entry('c'), entry('b'), entry('a')]; // newest first
  let saved = 'b';
  let detected = [];

  const scan = () => {
    const plan = lib.findNewVideos(playlist, saved, {});
    detected = lib.mergeDetected(
      detected.map(v => ({ ...v, status: 'found' })),
      plan.newVideos.map(v => ({ ...v, status: 'found', auto: true, attempts: 0 })),
      30,
    );
    return plan;
  };
  const downloadOldest = (result) => {
    const video = detected.find(v => v.status === 'found');
    if (!video) return null;
    if (result === 'ok') {
      detected = detected.filter(v => v.id !== video.id);
      saved = lib.advanceAnchor(saved, video, { auto: video.auto });
    } else {
      detected = detected.map(v => (v.id === video.id ? { ...v, status: 'failed' } : v));
    }
    return video.id;
  };

  scan();
  assert.deepEqual(detected.map(v => v.id), ['c', 'd', 'e'], 'oldest new video first');

  assert.equal(downloadOldest('ok'), 'c');
  assert.equal(saved, 'c');

  // d fails: the saved id must stay on c, and d must come back on the next scan
  assert.equal(downloadOldest('fail'), 'd');
  assert.equal(saved, 'c', 'a failed download must not move the saved id');
  scan();
  assert.deepEqual(detected.map(v => v.id), ['d', 'e'], 'failed video is retried, no duplicates');

  downloadOldest('ok'); // d
  downloadOldest('ok'); // e
  assert.equal(saved, 'e');
  assert.equal(detected.length, 0);

  assert.equal(scan().unchanged, true, 'nothing new once everything is saved');
  assert.equal(saved, 'e');
});

ok('end to end: a scan failure leaves the saved id and the queue untouched', () => {
  let saved = 'b';
  let detected = [{ id: 'c', status: 'failed', auto: true }];
  try {
    throw new Error('network down');
  } catch (e) {
    // main.js: only lastStatus/lastError/lastCheckedAt change in this branch
  }
  assert.equal(saved, 'b');
  assert.deepEqual(detected.map(v => v.id), ['c']);
});

ok('end to end: restart mid-batch resumes with the same saved id', () => {
  // Snapshot written before the app closed: anchor c, d and e still pending.
  const file = path.join(tmp, 'restart.json');
  lib.saveSubscriptionsFile(file, [{
    id: 'sub-1', url: 'u', title: 'Nashtar', lastVideoId: 'c',
    newVideos: [{ id: 'd', status: 'found', auto: true }, { id: 'e', status: 'found', auto: true }],
  }]);
  const [restored] = lib.readSubscriptionsFile(file);
  assert.equal(restored.lastVideoId, 'c');
  assert.deepEqual(restored.newVideos.map(v => v.id), ['d', 'e']);
  const plan = lib.findNewVideos([entry('e'), entry('d'), entry('c')], restored.lastVideoId, {});
  assert.deepEqual(plan.newVideos.map(v => v.id), ['d', 'e'], 'same two videos, no duplicates');
});

console.log(`\n${pass}/36 smart playlist subscription checks passed.`);
