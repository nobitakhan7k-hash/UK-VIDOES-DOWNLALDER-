/**
 * Vite's CJS main build leaves local require() calls verbatim. Copy every small
 * CommonJS helper used by src/main.js into dist-electron/lib so those requires
 * resolve in the packaged app.
 */
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const srcDir = path.join(root, 'src', 'lib');
const outDir = path.join(root, 'dist-electron', 'lib');

fs.mkdirSync(outDir, { recursive: true });
const files = fs.readdirSync(srcDir).filter((name) => name.endsWith('.cjs'));
for (const name of files) {
  const from = path.join(srcDir, name);
  const to = path.join(outDir, name);
  fs.copyFileSync(from, to);
  console.log(`Copied src/lib/${name} -> dist-electron/lib/${name}`);
}
if (!files.length) throw new Error('No CommonJS main helpers found in src/lib.');
