/**
 * Theme + lite-surface checks.
 * Run from the project root: node scripts/verify-theme.mjs
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = (p) => fs.readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');
const css = read('src/globals.css');
const ctx = read('src/contexts/ThemeContext.jsx');
const main = read('src/main.js');
const settings = read('src/components/SettingsDialog.jsx');
const card = read('src/components/ui/card.jsx');
const input = read('src/components/ui/input.jsx');
const button = read('src/components/ui/button.jsx');
const dialog = read('src/components/ui/dialog.jsx');
const select = read('src/components/ui/select.jsx');
const app = read('src/components/App.jsx');

const allSrc = (dir) => fs.readdirSync(new URL(`../${dir}`, import.meta.url), { withFileTypes: true })
  .flatMap((e) => {
    const rel = `${dir}/${e.name}`;
    return e.isDirectory() ? allSrc(rel) : [read(rel)];
  });
const renderer = allSrc('src/components').concat([css, app]);

let pass = 0;
const ok = (name, fn) => {
  try { fn(); pass += 1; console.log(`ok ${pass} - ${name}`); }
  catch (e) { console.error(`not ok ${pass + 1} - ${name}\n    ${e.message}`); process.exitCode = 1; }
};

// ── Palette ────────────────────────────────────────────────────────────────
ok('the forest palette still exists as a third token block', () => {
  assert.match(css, /\.forest\s*\{/);
  assert.match(css, /color-scheme:\s*dark;/);
});

ok('all five reference swatches are used as forest tokens', () => {
  for (const s of [
    '0.764 0.010 140',  // #AFB4AE grey leaf
    '0.620 0.034 115',  // #858972 dry moss
    '0.402 0.033 119',  // #464B37 forest
    '0.368 0.000 90',   // #3F3F3F slate
    '0.278 0.038 119',  // #262B15 deep pine
  ]) assert.ok(css.includes(s), `missing swatch ${s}`);
});

ok('forest defines every token the Tailwind theme reads', () => {
  const block = css.slice(css.indexOf('.forest {'));
  const forestBlock = block.slice(0, block.indexOf('\n}'));
  for (const token of [
    '--background', '--foreground', '--card', '--popover', '--primary',
    '--secondary', '--muted', '--muted-foreground', '--muted-soft', '--accent',
    '--border', '--input', '--ring', '--kofi', '--scrollbar-thumb',
  ]) assert.ok(forestBlock.includes(`${token}:`), `forest missing ${token}`);
});

// ── Lite: nothing heavy may come back ──────────────────────────────────────
ok('no backdrop blur anywhere in the stylesheet', () => {
  const blur = css.match(/backdrop-filter:\s*(blur|saturate)/g) || [];
  assert.equal(blur.length, 0, `${blur.length} blur declarations remain`);
  assert.ok(css.includes('backdrop-filter: none !important'));
});

ok('no glass helper classes or glass tokens remain', () => {
  assert.ok(!css.includes('--glass-'), 'glass tokens still declared');
  assert.ok(!/\.glass-(surface|shell|inset|popover|overlay|btn)/.test(css), 'glass classes remain');
  assert.ok(!css.includes('.btn-fill'));
  assert.ok(!css.includes('ambientDrift'));
  assert.ok(!css.includes('body::before'), 'ambient light field remains');
});

ok('components carry no glass classes', () => {
  for (const file of renderer) {
    assert.ok(!/glass-(surface|shell|inset|popover|overlay|btn)|btn-fill/.test(file),
      'a component still asks for glass');
  }
});

ok('every shadow token collapses to a hairline', () => {
  const block = css.slice(css.indexOf('/* ─── Lite:'), css.indexOf('--shadow-2xl:'));
  for (const token of ['--shadow-2xs', '--shadow-xs', '--shadow-sm', '--shadow-md',
    '--shadow-lg', '--shadow-xl']) {
    assert.ok(block.includes(token), `missing ${token}`);
  }
  assert.ok(css.includes('--shadow-2xl: 0 1px 0'));
  // No large blur radii left in the shadow ramp.
  assert.ok(!/--shadow-\w+: *0 \d{2,}px/.test(css), 'a big shadow blur is still defined');
});

ok('no continuous animation is left running in the background', () => {
  assert.ok(!css.includes('animation: ambientDrift'));
  // Remaining animations are all user-visible progress/feedback only.
  const animations = css.match(/animation:\s*[a-zA-Z]+/g) || [];
  for (const a of animations) {
    assert.ok(/progress|accordion|enter|fade|zoom|slide|shimmer/.test(a) ||
      /progressIndeterminate|progressPausedPulse/.test(a) ||
      a.includes('none'), `unexpected animation ${a}`);
  }
});

ok('the Browse window toolbar is blur-free too', () => {
  assert.ok(!main.includes('backdrop-filter: blur('));
});

// ── Wiring ─────────────────────────────────────────────────────────────────
ok('the preference list accepts forest in renderer and main', () => {
  assert.ok(ctx.includes("['system', 'light', 'dark', 'forest']"));
  assert.ok(main.includes("['system', 'light', 'dark', 'forest']"));
  assert.ok(ctx.includes("el.classList.toggle('forest', resolved === 'forest')"));
  assert.ok(main.includes("forest: '#12160c'"));
  assert.ok(main.includes("preference === 'forest' ? 'dark' : preference"));
});

ok('startup paints the stored theme before React mounts', () => {
  assert.ok(read('src/index.jsx').includes('applyStoredTheme()'));
  assert.ok(ctx.includes('initialAppearance'));
});

ok('Settings exposes Light / Forest / Dark', () => {
  assert.ok(settings.includes("{ key: 'light', label: 'Light' }"));
  assert.ok(settings.includes("{ key: 'forest', label: 'Forest' }"));
  assert.ok(settings.includes("{ key: 'dark', label: 'Dark' }"));
  assert.ok(settings.includes('const { preference, theme, resolved, setPreference } = useTheme();'));
});

ok('surfaces stay solid and bordered', () => {
  assert.ok(card.includes('bg-card text-card-foreground'));
  assert.ok(!card.includes('shadow'));
  assert.ok(input.includes('border border-input'));
  assert.ok(button.includes('bg-primary text-primary-foreground hover:bg-primary/90'));
  assert.ok(dialog.includes('bg-black/40'));
  assert.ok(select.includes('bg-popover'));
});

ok('no new explanatory copy in the theme UI', () => {
  const appearance = settings.slice(settings.indexOf('Appearance'), settings.indexOf('Appearance') + 1600);
  assert.ok(!/liquid|frosted|glass|palette|Description|Looks like/i.test(appearance));
});

ok('still no server, telemetry or history writes from the theme layer', () => {
  for (const file of [css, ctx]) {
    assert.ok(!file.includes('createServer'));
    assert.ok(!file.includes('fetch('));
    assert.ok(!file.includes('http://'));
    assert.ok(!file.includes('https://'));
  }
});

console.log(`\n${pass}/15 theme + lite checks passed.`);
