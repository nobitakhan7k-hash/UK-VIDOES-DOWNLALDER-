/**
 * Regression checks for the top-bar space key: typing "PAK OST" must keep
 * the space. The old bug trimmed on every onChange, so a trailing space was
 * deleted before the next character could follow it.
 * Run from the project root: node scripts/verify-space-input.mjs
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {
  coerceInputText,
  rawInputText,
  resolveFetchDetailsInput,
  safeKeywordQuery,
} from '../src/lib/searchInput.mjs';

const read = (rel) => fs.readFileSync(path.resolve(rel), 'utf8');
let checks = 0;
const ok = (label, fn) => {
  fn();
  checks += 1;
  console.log(`ok ${checks} - ${label}`);
};

const clickEvent = { type: 'click', target: {}, currentTarget: {} };

console.log('\nTop-bar space input checks\n');

ok('typing keeps leading, trailing and repeated spaces', () => {
  assert.equal(rawInputText('PAK '), 'PAK ');
  assert.equal(rawInputText(' PAK'), ' PAK');
  assert.equal(rawInputText('  PAK   OST  '), '  PAK   OST  ');
  assert.equal(rawInputText(' '), ' ');
  assert.equal(rawInputText(''), '');
});

ok('non-strings are still rejected (no [object Object] comeback)', () => {
  assert.equal(rawInputText(clickEvent), '');
  assert.equal(rawInputText(null), '');
  assert.equal(rawInputText(undefined), '');
  assert.equal(rawInputText(42), '');
  assert.equal(rawInputText(['a']), '');
});

ok('full song-name typing sequence survives', () => {
  // One onChange per keystroke, exactly like the real Input.
  let value = '';
  for (const ch of 'PAK OST') {
    value = rawInputText(value + ch);
    assert.equal(value, 'PAK OST'.slice(0, value.length));
  }
  assert.equal(value, 'PAK OST');
});

ok('two words with more than one space also survive typing', () => {
  let value = '';
  for (const ch of 'Mr  Beast  song') value = rawInputText(value + ch);
  assert.equal(value, 'Mr  Beast  song');
});

ok('submit still trims', () => {
  assert.equal(coerceInputText('  PAK OST  '), 'PAK OST');
  assert.equal(coerceInputText('PAK '), 'PAK');
});

ok('fetch resolution trims the raw field at submit time', () => {
  assert.equal(resolveFetchDetailsInput(undefined, '  PAK OST  '), 'PAK OST');
  assert.equal(resolveFetchDetailsInput(clickEvent, '  Mr Beast  '), 'Mr Beast');
  assert.equal(resolveFetchDetailsInput(clickEvent, '   '), '');
});

ok('final keyword guard still collapses whitespace', () => {
  assert.equal(safeKeywordQuery('  PAK   OST  '), 'PAK OST');
  assert.equal(safeKeywordQuery('Mr  Beast  song'), 'Mr Beast song');
  assert.equal(safeKeywordQuery(clickEvent), '');
});

ok('AppContext uses rawInputText on both live writers', () => {
  const ctx = read('src/contexts/AppContext.jsx');
  assert.ok(ctx.includes("import {\n  coerceInputText,"));
  assert.ok(ctx.includes('  rawInputText,'));
  assert.ok(ctx.includes('const text = rawInputText(value);'));
  assert.ok(ctx.includes('const next = rawInputText(newUrl);'));
  assert.ok(!ctx.includes('coerceInputText(newUrl)'));
  assert.ok(!ctx.includes('const text = coerceInputText(value);'));
  assert.ok(ctx.includes('if (!next.trim()) {'));
});

ok('trim still happens on the submit / normalise paths', () => {
  const lib = read('src/lib/searchInput.mjs');
  const ctx = read('src/contexts/AppContext.jsx');
  assert.ok(lib.includes('return value.trim();'));
  assert.ok(lib.includes('value.trim().replace(/\\s+/g, \' \')'));
  assert.ok(ctx.includes('resolveFetchDetailsInput(explicitUrl, urlRef.current)'));
  assert.ok(ctx.includes('normaliseUrlInput(coerceInputText(raw))'));
});

ok('Header sends the raw value and the event-object guard is intact', () => {
  const header = read('src/components/Header.jsx');
  assert.ok(header.includes('onChange={(e) => handleUrlChange(e.target.value)}'));
  assert.ok(header.includes('onClick={() => handleFetchDetails()}'));
  assert.ok(!header.includes('onClick={handleFetchDetails}'));
  const preload = read('src/preload.js');
  const main = read('src/main.js');
  assert.ok(preload.includes("typeof query === 'string' ? query : ''"));
  assert.ok(main.includes("typeof options.query !== 'string'"));
  assert.ok(main.includes("/^\\[object .+\\]$/i.test(query)"));
});

ok('other inputs still accept spaces (no trim on change)', () => {
  const files = [
    'src/components/KeywordView.jsx',
    'src/components/PlaylistsView.jsx',
    'src/components/SubscriptionsView.jsx',
    'src/components/LicenseDialog.jsx',
    'src/components/SettingsDialog.jsx',
  ];
  for (const f of files) {
    const s = read(f);
    assert.ok(!/onChange=\{\(e\) => [A-Za-z]+\((e\.target\.value)\.trim\(\)\)\}/.test(s), `trim-on-change in ${f}`);
  }
  assert.ok(read('src/components/KeywordView.jsx').includes('setQuery(e.target.value)'));
});

console.log(`\n${checks}/${checks} top-bar space input checks passed.`);
