/**
 * Unit + wiring checks for the dedicated Keyword Search page.
 * Run from the project root: node scripts/verify-keyword-page.mjs
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const h = require('../src/lib/keywordScan.cjs');
const read = (rel) => fs.readFileSync(path.resolve(rel), 'utf8');

let checks = 0;
const ok = (label, fn) => {
  fn();
  checks += 1;
  console.log(`ok ${checks} - ${label}`);
};

const NOW = Date.UTC(2026, 10, 7, 12, 0, 0); // 2026-11-07 12:00 UTC
const video = (id, views, date, extra = {}) => ({
  id,
  url: `https://www.youtube.com/watch?v=${id}`,
  title: `Video ${id}`,
  channel: 'Test channel',
  view_count: views,
  upload_date: date,
  duration: 200,
  ...extra,
});

try {
  ok('page choices are exactly 1/2/5/10/20/50', () => {
    assert.deepEqual(h.KEYWORD_PAGE_CHOICES, [1, 2, 5, 10, 20, 50]);
  });

  ok('1 page = 20 results; 50 pages = 1000 results', () => {
    const one = h.normalizeKeywordScanOptions({ query: 'PAK OST', pages: 1 }, NOW);
    const fifty = h.normalizeKeywordScanOptions({ query: 'PAK OST', pages: 50 }, NOW);
    assert.equal(h.KEYWORD_RESULTS_PER_PAGE, 20);
    assert.equal(one.limit, 20);
    assert.equal(fifty.limit, 1000);
  });

  ok('invalid page / time values fall back safely', () => {
    const o = h.normalizeKeywordScanOptions({ query: 'song', pages: 999, timeFilter: 'nope' }, NOW);
    assert.equal(o.pages, 1);
    assert.equal(o.timeFilter, 'any');
  });

  ok('upload-date filter builds a YouTube sp URL + dateafter', () => {
    const any = h.normalizeKeywordScanOptions({ query: 'PAK OST', pages: 1, timeFilter: 'any' }, NOW);
    const week = h.normalizeKeywordScanOptions({ query: 'PAK OST', pages: 2, timeFilter: 'week' }, NOW);
    assert.ok(!any.searchUrl.includes('sp='));
    assert.equal(any.dateAfter, '');
    assert.ok(week.searchUrl.includes('search_query=PAK+OST'));
    assert.ok(week.searchUrl.includes('sp=EgIIAw%3D%3D'));
    assert.equal(week.dateAfter, 'today-1week');
    assert.equal(week.timeLabel, 'This week');
  });

  ok('fake/object/link keywords are rejected', () => {
    assert.equal(h.safeKeywordQuery({ type: 'click' }), '');
    assert.equal(h.safeKeywordQuery('[object Object]'), '');
    assert.equal(h.safeKeywordQuery('https://example.com'), '');
    assert.equal(h.safeKeywordQuery('  PAK   OST  '), 'PAK OST');
    assert.throws(() => h.normalizeKeywordScanOptions({ query: '[object Object]' }, NOW));
  });

  ok('shorts links are skipped, watch links cleaned', () => {
    const o = h.normalizeKeywordScanOptions({ query: 'song', pages: 1 }, NOW);
    const info = { entries: [
      video('aaaaaaaaaaa', 10, '20261106', {
        url: 'https://www.youtube.com/watch?v=aaaaaaaaaaa&list=RDx&start_radio=1&pp=abc',
      }),
      video('bbbbbbbbbbb', 20, '20261106', {
        url: 'https://www.youtube.com/shorts/bbbbbbbbbbb',
      }),
      video('ccccccccccc', 30, '20261106', {
        url: '/watch?v=ccccccccccc',
      }),
    ] };
    const s = h.summarizeKeywordEntries(info, o, NOW);
    assert.equal(s.skippedShorts, 1);
    assert.equal(s.kept, 2);
    assert.ok(!s.items[0].url.includes('list='));
    assert.ok(!s.items[0].url.includes('start_radio'));
    assert.ok(s.items.some((it) => it.url.startsWith('https://www.youtube.com/watch?v=ccccccccccc')));
  });

  ok('strict upload-date cutoff drops old / unknown dates', () => {
    const o = h.normalizeKeywordScanOptions({ query: 'song', pages: 1, timeFilter: 'week' }, NOW);
    const info = { entries: [
      video('aaaaaaaaaaa', 10, '20261106'),
      video('bbbbbbbbbbb', 20, '20250101'),
      video('ccccccccccc', 30, '20261101', { upload_date: '' }),
    ] };
    const s = h.summarizeKeywordEntries(info, o, NOW);
    assert.equal(s.kept, 1);
    assert.equal(s.items[0].id, 'aaaaaaaaaaa');
    assert.equal(s.skippedDate, 2);
  });

  ok('most views sort first; missing views sort last', () => {
    const o = h.normalizeKeywordScanOptions({ query: 'song', pages: 1 }, NOW);
    const info = { entries: [
      video('aaaaaaaaaaa', 100, '20261106'),
      video('bbbbbbbbbbb', undefined, '20261106', { view_count: undefined }),
      video('ccccccccccc', 5000, '20261106'),
      video('ddddddddddd', 999, '20261106'),
    ] };
    const s = h.summarizeKeywordEntries(info, o, NOW);
    assert.deepEqual(s.items.map((i) => i.id), ['ccccccccccc', 'ddddddddddd', 'aaaaaaaaaaa', 'bbbbbbbbbbb']);
    assert.deepEqual(s.items.map((i) => i.rank), [1, 2, 3, 4]);
    assert.equal(s.items[0].viewsLabel, '5.0K');
  });

  ok('rounded view text, duration and date formatting', () => {
    assert.equal(h.formatViews(1234567), '1.2M');
    assert.equal(h.formatViews(0), '—');
    assert.equal(h.formatDuration(3725), '1:02:05');
    assert.equal(h.formatUploadDate({ upload_date: '20261107' }), '2026-11-07');
    assert.equal(h.parseViewCount({ view_count_text: '2.3M views' }), 2300000);
  });

  ok('duplicate + non-video results are dropped', () => {
    const o = h.normalizeKeywordScanOptions({ query: 'song', pages: 1 }, NOW);
    const info = { entries: [
      video('aaaaaaaaaaa', 10, '20261106'),
      video('aaaaaaaaaaa', 50, '20261106'),
      { id: 'UChannelId', url: 'https://www.youtube.com/channel/UChannelId', title: 'Channel' },
    ] };
    const s = h.summarizeKeywordEntries(info, o, NOW);
    assert.equal(s.kept, 1);
    assert.equal(s.skippedDuplicate, 1);
    assert.equal(s.skippedNonVideo, 1);
  });

  ok('post-scan top count clamps to 1..kept', () => {
    assert.equal(h.clampTopCount('0', 10), 1);
    assert.equal(h.clampTopCount('3', 10), 3);
    assert.equal(h.clampTopCount('999', 10), 10);
    assert.equal(h.clampTopCount('abc', 0), 1);
  });

  ok('dedicated page + header + routing are wired', () => {
    const app = read('src/components/App.jsx');
    const header = read('src/components/Header.jsx');
    const ctx = read('src/contexts/AppContext.jsx');
    const view = read('src/components/KeywordView.jsx');
    assert.ok(app.includes('KeywordView'));
    assert.ok(app.includes("activePage === 'keyword'"));
    assert.ok(header.includes('openKeyword'));
    assert.ok(ctx.includes('openKeyword'));
    assert.ok(ctx.includes('closeKeyword'));
    assert.ok(view.includes('DOWNLOAD TOP'));
    assert.ok(view.includes('Top videos'));
    assert.ok(view.includes('Top count'));
    assert.ok(!view.includes('how many TOP videos'));
    assert.ok(view.includes('keywordScan'));
    assert.ok(view.includes('queueVideoBatch'));
  });

  ok('main IPC + copy script + global shortcut guard exist', () => {
    const main = read('src/main.js');
    const preload = read('src/preload.js');
    const copy = read('scripts/copy-main-helpers.mjs');
    const shortcuts = read('src/hooks/useGlobalShortcuts.js');
    assert.ok(main.includes("ipcMain.handle('keyword-page:scan'"));
    assert.ok(main.includes('youtubetab:approximate_date'));
    assert.ok(main.includes('--playlist-end'));
    assert.ok(preload.includes('keywordScan'));
    assert.ok(copy.includes("name.endsWith('.cjs')"));
    assert.ok(shortcuts.includes('closeKeyword'));
  });

  console.log(`\n${checks}/${checks} keyword-page checks passed.`);
} catch (error) {
  console.error(`FAILED: ${error.stack || error.message}`);
  process.exitCode = 1;
}
