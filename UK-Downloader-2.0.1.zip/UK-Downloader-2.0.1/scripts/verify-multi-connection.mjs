/**
 * Checks for the global 2/4/8/16/32 + custom 1–64 multi-connection setting.
 * Run from the project root: node scripts/verify-multi-connection.mjs
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const p = require('../src/lib/parallel.cjs');
const read = (rel) => fs.readFileSync(path.resolve(rel), 'utf8');

let checks = 0;
const ok = (label, fn) => {
  fn();
  checks += 1;
  console.log(`ok ${checks} - ${label}`);
};

try {
  ok('presets are 2/4/8/16/32, custom range is 1–64', () => {
    assert.deepEqual(p.PARALLEL_PRESETS, [2, 4, 8, 16, 32]);
    assert.equal(p.PARALLEL_MIN, 1);
    assert.equal(p.PARALLEL_MAX, 64);
    assert.equal(p.PARALLEL_DEFAULT, 8);
  });

  ok('default is 8', () => {
    assert.equal(p.clampParallel(undefined), 8);
    assert.equal(p.clampParallel(''), 8);
  });

  ok('custom values 1–64 are accepted', () => {
    assert.equal(p.clampParallel(1), 1);
    assert.equal(p.clampParallel(6), 6); // legacy config still works
    assert.equal(p.clampParallel(8), 8);
    assert.equal(p.clampParallel(32), 32);
    assert.equal(p.clampParallel(64), 64);
  });

  ok('out-of-range / invalid values clamp safely', () => {
    assert.equal(p.clampParallel(0), 1);
    assert.equal(p.clampParallel(-5), 1);
    assert.equal(p.clampParallel(999), 64);
    assert.equal(p.clampParallel('abc'), 8);
    assert.equal(p.clampParallel('12'), 12);
    assert.equal(p.clampParallel(7.9), 7);
  });

  ok('preset helper recognises only the five preset values', () => {
    for (const n of p.PARALLEL_PRESETS) assert.equal(p.isParallelPreset(n), true);
    for (const n of [1, 6, 7, 12, 64]) assert.equal(p.isParallelPreset(n), false);
  });

  ok('main defaults + queue use clampParallel', () => {
    const main = read('src/main.js');
    assert.ok(main.includes("require('./lib/parallel.cjs')"));
    assert.ok(main.includes('parallel: PARALLEL_DEFAULT'));
    assert.ok(main.includes('return clampParallel(settings.parallel, PARALLEL_DEFAULT);'));
    assert.ok(!main.includes('PARALLEL_CHOICES'));
    assert.ok(!main.includes("'--concurrent-fragments', '4'"));
  });

  ok('per-video fragment connections are dynamic', () => {
    const main = read('src/main.js');
    assert.ok(main.includes('function downloadSpeedArgs()'));
    assert.ok(main.includes("'--concurrent-fragments', String(getConcurrentFragments())"));
    assert.ok(main.includes('...downloadSpeedArgs()'));
    assert.ok(!main.includes('...DOWNLOAD_SPEED_ARGS'));
    assert.ok(main.includes('function getConcurrentFragments()'));
  });

  ok('set-video-settings accepts custom 1–64', () => {
    const main = read('src/main.js');
    assert.ok(main.includes('next.parallel = clampParallel(patch.parallel, current.parallel);'));
    assert.ok(!main.includes('next.parallel = PARALLEL_CHOICES.includes(n)'));
  });

  ok('Settings UI has presets + custom input (no explanatory copy)', () => {
    const ui = read('src/components/SettingsDialog.jsx');
    assert.ok(ui.includes("from '../lib/parallel.mjs'"));
    assert.ok(ui.includes('PARALLEL_PRESETS.map'));
    assert.ok(ui.includes('customParallel'));
    assert.ok(ui.includes('PARALLEL_MIN'));
    assert.ok(ui.includes('PARALLEL_MAX'));
    assert.ok(ui.includes('Custom '));
    assert.ok(ui.includes('PARALLEL_MIN'));
    assert.ok(ui.includes('PARALLEL_MAX'));
    assert.ok(!ui.includes('videos download at the same time'));
    assert.ok(!ui.includes('Presets 2 / 4 / 8 / 16 / 32 or custom'));
    assert.ok(!ui.includes('[2, 4, 6]'));
  });

  ok('renderer fallback defaults and docs no longer say 2/4/6', () => {
    const ctx = read('src/contexts/AppContext.jsx');
    const keyword = read('src/components/KeywordView.jsx');
    const playlists = read('src/components/PlaylistsView.jsx');
    const app = read('src/components/App.jsx');
    assert.ok(ctx.includes("from '../lib/parallel.mjs'"));
    assert.ok(ctx.includes('parallel: PARALLEL_DEFAULT'));
    assert.ok(!ctx.includes('parallel: 2,'));
    for (const s of [keyword, playlists, app]) {
      assert.ok(!s.includes('2/4/6'));
      assert.ok(!s.includes('2 / 4 / 6'));
    }
  });

  console.log(`\n${checks}/${checks} multi-connection checks passed.`);
} catch (error) {
  console.error(`FAILED: ${error.stack || error.message}`);
  process.exitCode = 1;
}
