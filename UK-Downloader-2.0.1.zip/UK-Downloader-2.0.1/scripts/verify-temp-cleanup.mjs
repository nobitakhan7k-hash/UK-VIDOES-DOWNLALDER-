/**
 * Unit + wiring checks for leftover hidden work-folder cleanup.
 * Run from the project root: node scripts/verify-temp-cleanup.mjs
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const t = require('../src/lib/tempCleanup.cjs');
const read = (rel) => fs.readFileSync(path.resolve(rel), 'utf8');

let checks = 0;
const ok = (label, fn) => {
  fn();
  checks += 1;
  console.log(`ok ${checks} - ${label}`);
};

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'uk-cleanup-test-'));
const put = (p, data = Buffer.from('partial-bytes')) => {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, data);
};
const exists = (p) => fs.existsSync(p);

console.log('\nTemp cleanup checks\n');

try {
  ok('recognises real work-dir names, rejects everything else', () => {
    assert.equal(t.isWorkDirName('.uk-downloader-job-58-1794664089105-single-1794664089152', false), true);
    assert.equal(t.isWorkDirName('.uk-downloader-file-1794664089999', false), true);
    assert.equal(t.isWorkDirName('My Videos', false), false);
    assert.equal(t.isWorkDirName('.other-hidden', false), false);
    assert.equal(t.isWorkDirName('uk-downloader-a1b2c3', false), false);
    assert.equal(t.isWorkDirName('uk-downloader-a1b2c3', true), true);
    assert.equal(t.isWorkDirName('.uk-downloader-job-1-single-2', true), false);
    assert.equal(t.isWorkDirName(null, false), false);
  });

  ok('deletes orphan work folders with their partial files, keeps normal folders', () => {
    const base = path.join(root, 'case1');
    const w1 = path.join(base, '.uk-downloader-job-58-1794664089105-single-1794664089152');
    const w2 = path.join(base, '.uk-downloader-file-1794664089999');
    const nested = path.join(base, 'My Videos', 'Indian Song', '.uk-downloader-job-9-1-single-2');
    const protectedDir = path.join(base, '.uk-downloader-job-77-1-single-2');
    put(path.join(w1, 'song.mp4.part'), Buffer.from('12345'));
    put(path.join(w1, 'frag', 'chunk.frag'), Buffer.from('abc'));
    put(path.join(w2, 'file.zip.part'), Buffer.from('1234567'));
    put(path.join(nested, 'video.mp4.ytdl'), Buffer.from('xy'));
    put(path.join(protectedDir, 'keep.part'), Buffer.from('KEEP'));
    put(path.join(base, '.other-hidden', 'notes.txt'), Buffer.from('notes'));
    put(path.join(base, 'uk-downloader-notes.txt'), Buffer.from('text'));

    const res = t.cleanupLeftovers({
      roots: [{ dir: base, maxDepth: 3 }],
      protectedPaths: [protectedDir],
    });

    assert.equal(res.success, true);
    assert.equal(res.removed, 3);
    assert.equal(res.found, 3);
    assert.equal(res.files, 4); // w1 = 2, w2 = 1, nested = 1
    assert.equal(res.protectedSkipped, 1);
    assert.equal(!exists(w1), true);
    assert.equal(!exists(w2), true);
    assert.equal(!exists(nested), true);
    assert.equal(exists(protectedDir), true);
    assert.equal(exists(path.join(protectedDir, 'keep.part')), true);
    assert.equal(exists(path.join(base, 'My Videos')), true);
    assert.equal(exists(path.join(base, '.other-hidden', 'notes.txt')), true);
    assert.equal(exists(path.join(base, 'uk-downloader-notes.txt')), true);
    assert.equal(res.errors.length, 0);
  });

  ok('dryRun reports without deleting', () => {
    const base = path.join(root, 'case2');
    const w = path.join(base, '.uk-downloader-job-1-single-2');
    put(path.join(w, 'x.part'), Buffer.from('1234'));
    const res = t.cleanupLeftovers({
      roots: [{ dir: base, maxDepth: 3 }],
      protectedPaths: [],
      dryRun: true,
    });
    assert.equal(res.dryRun, true);
    assert.equal(res.removed, 1);
    assert.equal(res.files, 1);
    assert.equal(res.bytes, 4);
    assert.equal(exists(w), true);
  });

  ok('protected parent is never descended into', () => {
    const base = path.join(root, 'case3');
    const parent = path.join(base, 'My Videos');
    const inner = path.join(parent, '.uk-downloader-job-3-single-4');
    put(path.join(inner, 'x.part'));
    const res = t.cleanupLeftovers({
      roots: [{ dir: base, maxDepth: 3 }],
      protectedPaths: [parent],
    });
    assert.equal(res.removed, 0);
    assert.equal(exists(inner), true);
  });

  ok('system-temp fallback dirs are matched only in temp roots', () => {
    const base = path.join(root, 'case4');
    const tmpLike = path.join(base, 'uk-downloader-a1b2c3');
    put(path.join(tmpLike, 'x.part'));
    const asDest = t.cleanupLeftovers({ roots: [{ dir: base, maxDepth: 3 }] });
    assert.equal(asDest.removed, 0);
    const asTemp = t.cleanupLeftovers({ roots: [{ dir: base, inTemp: true, maxDepth: 1 }] });
    assert.equal(asTemp.removed, 1);
    assert.equal(!exists(tmpLike), true);
  });

  ok('missing / duplicate roots are safe', () => {
    const res = t.cleanupLeftovers({
      roots: [path.join(root, 'does-not-exist'), '', null, root, root],
      protectedPaths: [],
    });
    assert.equal(res.success, true);
    assert.equal(res.scannedRoots, 1);
    assert.equal(Array.isArray(res.errors), true);
  });

  ok('main wires roots, protected paths, startup sweep and IPC', () => {
    const main = read('src/main.js');
    assert.ok(main.includes("require('./lib/tempCleanup.cjs')"));
    assert.ok(main.includes('function cleanupScanRoots'));
    assert.ok(main.includes('function protectedWorkDirs'));
    assert.ok(main.includes('function sweepOrphanWorkDirs'));
    assert.ok(main.includes("ipcMain.handle('cleanup-temp-files'"));
    assert.ok(main.includes('sweepOrphanWorkDirs();\n  startNetworkMonitoring();'));
    assert.ok(main.includes('addRoot(settings.directSaveDir)'));
    assert.ok(main.includes('addRoot(app.getPath(\'downloads\'))'));
    assert.ok(main.includes('Object.values(playlistDirs)'));
    assert.ok(main.includes('getSubscriptions()'));
    assert.ok(main.includes('addRoot(os.tmpdir(), { inTemp: true, maxDepth: 1 })'));
  });

  ok('live and resumable work dirs are protected', () => {
    const main = read('src/main.js');
    assert.ok(main.includes('for (const job of downloadQueue)'));
    assert.ok(main.includes('push(job.workDir)'));
    assert.ok(main.includes('store.get(RESUME_QUEUE_KEY, [])'));
    assert.ok(main.includes('push(it && it.workDir)'));
    assert.ok(main.includes('protectedPaths: protectedWorkDirs()'));
    // Crash-safe resume itself must remain untouched.
    assert.ok(main.includes('--continue'));
    assert.ok(main.includes('preserveForResume'));
    assert.ok(main.includes('resumeQueueV1'));
  });

  ok('GUI exposes one Clean Temp button with short status only', () => {
    const preload = read('src/preload.js');
    const ctx = read('src/contexts/AppContext.jsx');
    const view = read('src/components/HistoryView.jsx');
    assert.ok(preload.includes('cleanupTempFiles: (options = {})'));
    assert.ok(ctx.includes('const cleanTempFiles = useCallback'));
    assert.ok(ctx.includes("showAppNotice('success', `Cleaned ${res.removed} folder"));
    assert.ok(ctx.includes("showAppNotice('info', 'Nothing to clean.')"));
    assert.ok(ctx.includes('    cleanTempFiles,'));
    assert.ok(view.includes('cleanTempFiles'));
    assert.ok(view.includes('Clean Temp'));
    assert.ok(view.includes('Eraser'));
    assert.ok(!view.includes('leftover files are'));
    assert.ok(!view.includes('point your'));
  });

  ok('no server, telemetry, auto-start or legacy conversion added', () => {
    const main = read('src/main.js');
    assert.ok(!main.includes('createServer'));
    assert.ok(!main.includes('.listen('));
    assert.ok(!main.includes('autoStart'));
    assert.ok(!main.includes('convertLegacy'));
    assert.ok(main.includes('--concurrent-fragments'));
    assert.ok(main.includes('cancel-all-jobs'));
    assert.ok(main.includes('ukdownloader'));
  });

  console.log(`\n${checks}/${checks} temp cleanup checks passed.`);
} catch (error) {
  console.error(`FAILED: ${error.stack || error.message}`);
  process.exitCode = 1;
} finally {
  try { fs.rmSync(root, { recursive: true, force: true }); } catch (e) { }
}
