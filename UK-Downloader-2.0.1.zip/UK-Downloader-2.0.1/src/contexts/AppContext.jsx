import React, { createContext, useContext, useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { toSingleVideoUrl } from '../lib/dragUrls';
import {
  coerceInputText,
  isUrlLike,
  normaliseUrlInput,
  rawInputText,
  resolveFetchDetailsInput,
  safeKeywordQuery,
} from '../lib/searchInput.mjs';
import { PARALLEL_DEFAULT } from '../lib/parallel.mjs';

const AppContext = createContext();

const isYouTubeUrl = (url) => {
  try {
    const host = new URL(url).hostname.toLowerCase().replace(/^www\./, '');
    return host === 'youtube.com' || host.endsWith('.youtube.com') ||
      host === 'youtu.be' || host.endsWith('.youtu.be');
  } catch (e) {
    return false;
  }
};

// Collection URLs on non-YouTube sites, kept deliberately narrow. Guessing
// wrong sends a single video into the playlist view, so anything unrecognised
// falls through to the single-video path — which is what every link did before.
const COLLECTION_PATHS = [
  /\/playlists?(\/|$)/i,   // generic, Dailymotion, Vimeo
  /\/sets\//i,             // SoundCloud
  /\/album\//i,            // Bandcamp
];

/**
 * Decide how a pasted link should be fetched: as a single video, as a
 * playlist, or as a YouTube watch-inside-playlist link that could be either
 * and therefore needs to ask.
 */
const classifyUrl = (url) => {
  let u;
  try { u = new URL(url); } catch (e) { return 'video'; }

  if (isYouTubeUrl(url)) {
    const hasList = u.searchParams.has('list');
    const hasVideo = u.searchParams.has('v') || url.includes('youtu.be/') || url.includes('/shorts/');
    if (hasList && hasVideo) return 'hybrid';
    if (hasList) return 'playlist';
    return 'video';
  }

  return COLLECTION_PATHS.some(re => re.test(u.pathname)) ? 'playlist' : 'video';
};

// URL / keyword helpers live in src/lib/searchInput.mjs. They accept ONLY real
// strings: an event object can never become the fake keyword "[object Object]".

// True when `latest` is strictly newer than `current` (dotted numeric
// versions). A plain inequality told anyone running a build ahead of the
// newest release — a dev build, a pre-release — to "update".
const isNewerVersion = (latest, current) => {
  // Drop any pre-release suffix ("1.1.0-rc.1") so it cannot masquerade as an
  // extra numeric component and outrank the final release.
  const nums = (v) => String(v).split('-')[0].split('.').map(n => parseInt(n, 10) || 0);
  const a = nums(latest);
  const b = nums(current);
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const d = (a[i] || 0) - (b[i] || 0);
    if (d !== 0) return d > 0;
  }
  return false;
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within AppProvider');
  }
  return context;
};

export const AppProvider = ({ children }) => {
  const [url, setUrl] = useState("");
  // Held here so the "/" shortcut can reach the URL field from anywhere.
  const urlInputRef = useRef(null);
  const [videoDetails, setVideoDetails] = useState(null);
  const [history, setHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [fetchError, setFetchError] = useState(null);
  // Which *kind* of failure it was ('age-blocked', 'private', 'geo-blocked'...),
  // so the error view can explain it instead of guessing at a bad URL.
  const [fetchErrorKind, setFetchErrorKind] = useState(null);
  const [ytDlpStatus, setYtDlpStatus] = useState(null);
  // Live state of the bundled yt-dlp engine (version, update phase, timestamps).
  const [ytDlpEngine, setYtDlpEngine] = useState({
    phase: 'idle',
    version: null,
    previousVersion: null,
    lastChecked: null,
    lastUpdated: null,
    message: '',
  });
  // True when user clicked "Get Video" while yt-dlp was still updating
  const [pendingFetch, setPendingFetch] = useState(false);

  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authExpired, setAuthExpired] = useState(false);
  const [isAgeRestricted, setIsAgeRestricted] = useState(false);

  const [playlistDetails, setPlaylistDetails] = useState(null);
  const [isPlaylistMode, setIsPlaylistMode] = useState(false);
  const [hybridPromptUrl, setHybridPromptUrl] = useState(null);

  // ── Download queue state (mirrors the main-process queue) ────────────────
  const [jobs, setJobs] = useState([]);
  const [jobProgress, setJobProgress] = useState({}); // jobId -> latest progress payload
  const [jobResults, setJobResults] = useState({});   // jobId -> { success, path, error, cancelled, ... }
  // The job the current Details/Playlist view is bound to (so re-opening an
  // active download shows the exact same view it was started from)
  const [boundJobId, setBoundJobId] = useState(null);
  // Instant drag feedback: optimistic rows shown in Downloads while yt-dlp
  // fetches metadata. Never persisted — this is not download history.
  const [preparingDrops, setPreparingDrops] = useState([]);
  const prepTimers = useRef(new Map());

  // ── Settings state ────────────────────────────────────────────────────────────
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState('general');

  // ── Pro license + daily limit ────────────────────────────────────────────────
  const [license, setLicense] = useState({
    isPro: false, type: null, key: null, activatedAt: null, expiresAt: null,
    dailyCount: 0, dailyLimit: 10, remaining: 10, today: '', limitReached: false,
  });
  const [isQrOpen, setIsQrOpen] = useState(false);
  const [qrReason, setQrReason] = useState(null); // 'manual' | 'limit'
  const [isLicenseOpen, setIsLicenseOpen] = useState(false);
  const [appNotice, setAppNotice] = useState(null);

  // ── Video settings (HD / MP3 presets, parallel, keyword limit, direct save) ──
  const [videoSettings, setVideoSettingsState] = useState({
    defaultQuality: 'hd720',
    directSave: true,
    directSaveDir: '',
    parallel: PARALLEL_DEFAULT,
    keywordLimit: 1,
  });
  // Playlist page switch: when ON and the Playlist view is open, dropping a
  // playlist URL also follows it for FUTURE videos (no old-video re-download).
  const [autoSubscribeDropped, setAutoSubscribeDroppedState] = useState(true);

  // ── Pages ─────────────────────────────────────────────────────────────────────
  // 'main' is the history / details / playlist surface; 'subscriptions' is the
  // separate subscriptions page reached from the header bell.
  const [activePage, setActivePage] = useState('main');
  const isPlaylistPageOpen = (activePage === 'main' && isPlaylistMode && !!playlistDetails) || activePage === 'playlists';

  // ── Subscriptions (playlists / channels that auto-download new videos) ──────
  const [subscriptions, setSubscriptions] = useState([]);
  // Scan engine: { running, intervalMinutes, lastSweepAt, lastSweepStatus }
  const [scanState, setScanState] = useState({
    running: true, intervalMinutes: 15, lastSweepAt: 0, lastSweepStatus: 'idle',
  });
  const [subsBusyId, setSubsBusyId] = useState(null); // id, 'all', or 'add'
  const [subsNotice, setSubsNotice] = useState(null);  // { kind: 'ok'|'error', text }
  // { phase, id, title, index, total } — which ONE playlist is being checked.
  const [subsCheckProgress, setSubsCheckProgress] = useState(null);
  const directDownloadRef = useRef(null);

  const openSettings = useCallback((tab = 'general') => {
    setSettingsTab(tab);
    setIsSettingsOpen(true);
  }, []);

  const closeSettings = useCallback(() => {
    setIsSettingsOpen(false);
  }, []);

  // QR (By Usman / daily limit) and the separate Pro-key window.
  const openQr = useCallback((reason = 'manual') => {
    setQrReason(reason);
    setIsQrOpen(true);
  }, []);
  const closeQr = useCallback(() => setIsQrOpen(false), []);
  const openLicense = useCallback(() => {
    setIsQrOpen(false);
    setIsLicenseOpen(true);
  }, []);
  const closeLicense = useCallback(() => setIsLicenseOpen(false), []);
  const showAppNotice = useCallback((kind, text) => {
    setAppNotice({ kind, text, at: Date.now() });
  }, []);

  useEffect(() => {
    window.electronAPI.getAutoSubscribeDropped()
      .then(v => setAutoSubscribeDroppedState(!!v))
      .catch(() => {});
  }, []);

  const updateAutoSubscribeDropped = useCallback(async (enabled) => {
    const next = await window.electronAPI.setAutoSubscribeDropped(enabled).catch(() => !!enabled);
    setAutoSubscribeDroppedState(!!next);
    return !!next;
  }, []);

  const openBrowser = useCallback(async () => {
    const res = await window.electronAPI.openBrowseWindow().catch(err => ({ success: false, error: err?.message }));
    if (res && res.success === false) {
      showAppNotice('error', res.error || 'Could not open the YouTube window.');
    }
    return res;
  }, [showAppNotice]);

  useEffect(() => {
    window.electronAPI.onBrowseDownloadUrl((payload) => {
      const url = typeof payload === 'string' ? payload : payload && payload.url;
      if (!url) return;
      const keyword = payload && typeof payload === 'object' ? payload.keyword : '';
      const fn = directDownloadRef.current;
      if (fn) fn([url], { keyword });
    });
  }, []);

  const cancelAllJobs = useCallback(async () => {
    const res = await window.electronAPI.cancelAllJobs().catch(() => ({ success: false }));
    if (res?.success) {
      showAppNotice('info', `${res.cancelled} download${res.cancelled === 1 ? '' : 's'} cancelled.`);
    } else {
      showAppNotice('error', 'Could not cancel the downloads.');
    }
    return res;
  }, [showAppNotice]);

  const cleanTempFiles = useCallback(async () => {
    const api = window.electronAPI;
    if (!api?.cleanupTempFiles) {
      showAppNotice('error', 'Cleanup is not available.');
      return { success: false };
    }
    try {
      const res = await api.cleanupTempFiles();
      if (!res?.success) {
        showAppNotice('error', res?.error || 'Cleanup failed.');
        return res;
      }
      if (res.removed) {
        showAppNotice('success', `Cleaned ${res.removed} folder${res.removed === 1 ? '' : 's'}.`);
      } else {
        showAppNotice('info', 'Nothing to clean.');
      }
      return res;
    } catch (err) {
      showAppNotice('error', err?.message || 'Cleanup failed.');
      return { success: false, error: err?.message || 'Cleanup failed.' };
    }
  }, [showAppNotice]);

  const removePreparingDrop = useCallback((id) => {
    const timer = prepTimers.current.get(id);
    if (timer) {
      clearTimeout(timer);
      prepTimers.current.delete(id);
    }
    setPreparingDrops(prev => prev.filter(item => item.id !== id));
  }, []);

  const addPreparingDrop = useCallback(({ label, detail }) => {
    const id = `prep-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    setPreparingDrops(prev => [...prev, { id, label, detail, startedAt: Date.now() }]);
    // Failsafe: never leave a stuck placeholder if an IPC call dies.
    const timer = setTimeout(() => removePreparingDrop(id), 20000);
    prepTimers.current.set(id, timer);
    return id;
  }, [removePreparingDrop]);

  const showDownloadsView = useCallback(() => {
    setActivePage('main');
    setVideoDetails(null);
    setPlaylistDetails(null);
    setIsPlaylistMode(false);
    setHybridPromptUrl(null);
    setFetchError(null);
    setFetchErrorKind(null);
    setIsLoading(false);
    setPendingFetch(false);
    setBoundJobId(null);
  }, []);

  /**
   * A song/keyword in the top bar becomes ytsearchN:<query>; the first N
   * results are queued with the current format / parallel / quota rules.
   */
  const queueKeywordSearch = useCallback(async (query) => {
    const q = safeKeywordQuery(query);
    if (!q) {
      showAppNotice('error', 'Type a valid song name or keyword first.');
      return { success: false, error: 'Type a valid song name or keyword first.' };
    }

    // Never leave a stale details/playlist sheet on screen for a plain search.
    setActivePage('main');
    setVideoDetails(null);
    setPlaylistDetails(null);
    setIsPlaylistMode(false);
    setHybridPromptUrl(null);
    setFetchError(null);
    setFetchErrorKind(null);
    setIsAgeRestricted(false);
    setIsLoading(false);
    setPendingFetch(false);
    setBoundJobId(null);

    showAppNotice('info', `Searching YouTube for "${q}"…`);
    try {
      const api = window.electronAPI;
      if (!api.queueKeywordSearch) {
        const res = { success: false, error: 'Keyword search is not available.' };
        showAppNotice('error', res.error);
        return res;
      }
      const settings = await api.getVideoSettings().catch(() => ({ keywordLimit: 1 }));
      const res = await api.queueKeywordSearch(q, settings.keywordLimit);
      if (!res?.success) {
        showAppNotice('error', res?.error || 'Search failed.');
        return res;
      }
      if (res.partial) {
        showAppNotice('warning', `Daily limit: ${res.queued} queued, ${res.skipped} skipped.`);
      } else {
        const n = res.queued || 1;
        showAppNotice('success', `${n} download${n === 1 ? '' : 's'} started.`);
      }
      return res;
    } catch (err) {
      showAppNotice('error', err?.message || 'Search failed.');
      return { success: false, error: err?.message || 'Search failed.' };
    }
  }, [setActivePage, showAppNotice]);
  const exportSubscriptions = useCallback(() => {
    if (!window.electronAPI.exportSubscriptions) return Promise.resolve({ success: false, error: 'Not available.' });
    return Promise.resolve(window.electronAPI.exportSubscriptions()).catch(err => ({ success: false, error: err?.message || 'Export failed.' }));
  }, []);
  const importSubscriptions = useCallback(() => {
    if (!window.electronAPI.importSubscriptions) return Promise.resolve({ success: false, error: 'Not available.' });
    return Promise.resolve(window.electronAPI.importSubscriptions()).catch(err => ({ success: false, error: err?.message || 'Import failed.' }));
  }, []);

  const redeemKey = useCallback(async (key) => {
    if (!window.electronAPI.redeemLicenseKey) {
      return { success: false, error: 'Key activation is not available.' };
    }
    try {
      const res = await window.electronAPI.redeemLicenseKey(key);
      if (res?.state) setLicense(res.state);
      if (res?.success) closeQr();
      return res;
    } catch (err) {
      return { success: false, error: err?.message || 'Activation failed.' };
    }
  }, [closeQr]);

  // Manual yt-dlp engine controls (Settings → yt-dlp engine).
  const checkYtDlpUpdate = useCallback(() => {
    if (!window.electronAPI.checkYtDlpUpdate) return Promise.resolve();
    return Promise.resolve(window.electronAPI.checkYtDlpUpdate()).catch(() => {});
  }, []);
  const downloadYtDlp = useCallback(() => {
    if (!window.electronAPI.downloadYtDlp) return Promise.resolve();
    return Promise.resolve(window.electronAPI.downloadYtDlp()).catch(() => {});
  }, []);

  const fetchIdRef = useRef(0);
  const urlRef = useRef(url);
  urlRef.current = url;
  const wasAuthenticatedRef = useRef(false);

  /** Single writer for the top-bar text: keeps state + ref in lockstep. */
  const setUrlInput = (value) => {
    const text = rawInputText(value);
    urlRef.current = text;
    setUrl(text);
    return text;
  };

  useEffect(() => {
    window.electronAPI.onYtDlpUpdateStatus(({ status }) => {
      setYtDlpStatus(status);
    });
  }, []);

  // yt-dlp engine: hydrate the Settings panel from the main process, then
  // follow every live phase (checking → downloading → updated / error).
  useEffect(() => {
    const api = window.electronAPI;
    if (api.getYtDlpEngine) {
      Promise.resolve(api.getYtDlpEngine())
        .then((state) => { if (state) setYtDlpEngine(state); })
        .catch(() => {});
    }
    if (api.onYtDlpEngineStatus) {
      api.onYtDlpEngineStatus((state) => {
        if (state) setYtDlpEngine(state);
      });
    }
  }, []);

  // Pro license / daily limit: hydrate from main.js, follow live updates, and
  // pop the WhatsApp QR automatically when the 10-video daily limit is hit.
  useEffect(() => {
    const api = window.electronAPI;
    if (api.getLicenseState) {
      Promise.resolve(api.getLicenseState())
        .then((state) => { if (state) setLicense(state); })
        .catch(() => {});
    }
    const apply = (state) => { if (state) setLicense(state); };
    if (api.onLicenseState) api.onLicenseState(apply);
    if (api.onLicenseUpdated) api.onLicenseUpdated(apply);
    if (api.onDailyUsageUpdated) api.onDailyUsageUpdated(apply);
    if (api.onDailyLimitReached) {
      api.onDailyLimitReached((state) => {
        if (state) setLicense(state);
        if (!state?.isPro) {
          setQrReason('limit');
          setIsQrOpen(true);
        }
      });
    }
    if (api.onAppNotice) api.onAppNotice((notice) => { if (notice) setAppNotice(notice); });
  }, []);

  // Fetch history on mount + refresh whenever main process writes new entries
  useEffect(() => {
    window.electronAPI.getHistory().then(setHistory);
    window.electronAPI.onHistoryUpdated(() => {
      window.electronAPI.getHistory().then(setHistory);
    });
  }, []);

  // Video settings: load once, then keep in sync with the main process
  useEffect(() => {
    window.electronAPI.getVideoSettings().then(setVideoSettingsState).catch(() => {});
    window.electronAPI.onVideoSettingsUpdated(setVideoSettingsState);
  }, []);

  const updateVideoSettings = useCallback(async (patch) => {
    const next = await window.electronAPI.setVideoSettings(patch);
    if (next) setVideoSettingsState(next);
    return next;
  }, []);

  // Subscriptions: initial load + live updates from the main process
  useEffect(() => {
    window.electronAPI.getSubscriptions().then(setSubscriptions).catch(() => {});
    window.electronAPI.onSubscriptionsUpdated(setSubscriptions);
    window.electronAPI.getSubscriptionScanState?.()
      .then((state) => { if (state) setScanState(state); })
      .catch(() => {});
    window.electronAPI.onSubscriptionScanState?.((state) => { if (state) setScanState(state); });
  }, []);
  useEffect(() => {
    window.electronAPI.onSubscriptionCheckProgress((p) => {
      if (!p) return;
      if (p.phase === 'checking') {
        setSubsBusyId(p.id);
        setSubsCheckProgress(p);
        setSubsNotice({ kind: 'ok', text: `Checking ${p.index} of ${p.total}: ${p.title}…` });
      } else if (p.phase === 'finished') {
        setSubsCheckProgress(null);
      }
    });
  }, []);

  // Queue subscriptions
  useEffect(() => {
    window.electronAPI.getQueue().then(setJobs);
    window.electronAPI.onQueueUpdated(setJobs);
    window.electronAPI.onDownloadProgress((p) => {
      if (!p || !p.jobId) return;
      setJobProgress(prev => {
        const old = prev[p.jobId] || {};
        // Pause/resume status events carry no byte counts — merge them
        if (p.paused !== undefined && p.percent === undefined) {
          return { ...prev, [p.jobId]: { ...old, paused: p.paused, pauseReason: p.reason || null, stage: p.stage || old.stage } };
        }
        return { ...prev, [p.jobId]: { ...old, ...p, paused: false, pauseReason: null } };
      });
    });
    window.electronAPI.onJobFinished((r) => {
      if (!r || !r.jobId) return;
      setJobResults(prev => ({ ...prev, [r.jobId]: r }));
      // Finished jobs clear themselves from the list. Keep the result just
      // long enough for the details/playlist view to show "Complete".
      setTimeout(() => {
        setJobResults(prev => {
          const next = { ...prev };
          delete next[r.jobId];
          return next;
        });
        setJobProgress(prev => {
          const next = { ...prev };
          delete next[r.jobId];
          return next;
        });
      }, 4500);
    });
  }, []);

  // Check initial youtube auth state
  useEffect(() => {
    window.electronAPI.checkYoutubeAuth().then((ok) => {
      setIsAuthenticated(ok);
      wasAuthenticatedRef.current = ok;
    });
  }, []);

  const refreshAuth = useCallback(async () => {
    const ok = await window.electronAPI.checkYoutubeAuth();
    if (!ok && wasAuthenticatedRef.current) {
      // Session that used to work no longer does — surface it so the user can re-login
      setAuthExpired(true);
    }
    if (ok) setAuthExpired(false);
    wasAuthenticatedRef.current = ok;
    setIsAuthenticated(ok);
    return ok;
  }, []);

  const loginYoutube = async () => {
    const success = await window.electronAPI.loginYoutube();
    if (success) {
      setIsAuthenticated(true);
      setAuthExpired(false);
      wasAuthenticatedRef.current = true;
    }
    return success;
  };

  const logoutYoutube = async () => {
    await window.electronAPI.logoutYoutube();
    setIsAuthenticated(false);
    setAuthExpired(false);
    wasAuthenticatedRef.current = false;
  };

  // ── Version checking ──────────────────────────────────────────────────────────
  const [appVersion, setAppVersion] = useState('');
  const [latestVersion, setLatestVersion] = useState('');
  const [hasNewVersion, setHasNewVersion] = useState(false);
  const [versionChecked, setVersionChecked] = useState(false);

  useEffect(() => {
    let mounted = true;
    window.electronAPI.getAppVersion().then(v => {
      if (!mounted) return;
      setAppVersion(v);
      // No upstream release check: this build has no website or GitHub links.
      setVersionChecked(true);
    });
    return () => { mounted = false; };
  }, []);

  // The actual fetch logic — uses urlRef so it's always fresh
  const runFetch = useCallback(async () => {
    const currentUrl = urlRef.current;
    if (!currentUrl) return;
    setIsLoading(true);
    setFetchError(null);
    setFetchErrorKind(null);
    setIsAgeRestricted(false);
    setIsPlaylistMode(false);
    setBoundJobId(null);
    const currentFetchId = ++fetchIdRef.current;
    try {
      const result = await window.electronAPI.getVideoInfo(currentUrl);
      if (currentFetchId !== fetchIdRef.current) return;
      if (result.success) {
        // Keep the URL this fetch was made from. It is the fallback the
        // download uses when the extractor didn't report a webpage_url.
        setVideoDetails({ ...result, sourceUrl: currentUrl });
      } else {
        console.error(`Error: ${result.error}`);
        setVideoDetails(null);
        if (result.isAgeRestricted) {
          setIsAgeRestricted(true);
          setIsAuthenticated(false);
        }
        setFetchError(result.error);
        setFetchErrorKind(result.errorKind || 'unknown');
      }
    } catch (error) {
      if (currentFetchId !== fetchIdRef.current) return;
      console.error("Failed to fetch video details:", error);
      setVideoDetails(null);
      setFetchError(error.message || 'Something went wrong');
      setFetchErrorKind('unknown');
    } finally {
      if (currentFetchId === fetchIdRef.current) {
        setIsLoading(false);
      }
    }
  }, []);

  const isYtDlpBusy = ytDlpStatus === 'checking' || ytDlpStatus === 'downloading';

  const handleFetchDetails = (explicitUrl) => {
    // A React click/key event is NOT a URL. Ignore non-string arguments and
    // use the current field text instead of stringifying the event object.
    const current = resolveFetchDetailsInput(explicitUrl, urlRef.current);
    if (!current) return;
    if (current !== urlRef.current) setUrlInput(current);

    // Plain text => keyword/song search, not the details page.
    if (!isUrlLike(current)) {
      queueKeywordSearch(current);
      return;
    }

    if (isYtDlpBusy) {
      setPendingFetch(true);
      setIsLoading(true);
      setFetchError(null);
      setFetchErrorKind(null);

      if (classifyUrl(current) === 'playlist') {
        setIsPlaylistMode(true);
      }

      return;
    }

    const kind = classifyUrl(current);
    if (kind === 'hybrid') {
      setHybridPromptUrl(current);
      return;
    }
    if (kind === 'playlist') {
      runPlaylistFetch();
      return;
    }

    runFetch();
  };

  /**
   * Open a link in the details/playlist view. Drag & drop no longer uses this
   * path — dropped links go straight to directDownloadUrls() below.
   */
  const openUrl = (raw) => {
    const next = normaliseUrlInput(coerceInputText(raw));
    if (!next) return;
    setActivePage('main');
    setUrlInput(next);
    handleFetchDetails(next);
  };

  /**
   * Drag & drop: resolve each link to downloadable video(s) and queue them
   * immediately, with no details page and no Save dialog. The main-process
   * batch queue enforces the 10/day free limit once for the whole drop and
   * starts up to the configured 2 / 4 / 8 / 16 / 32 (custom 1–64) jobs in parallel.
   */
  const directDownloadUrls = useCallback(async (rawUrls, options = {}) => {
    const api = window.electronAPI;
    const keyword = typeof options.keyword === 'string' ? options.keyword : '';
    const urls = [...new Set(
      (Array.isArray(rawUrls) ? rawUrls : [rawUrls])
        .map(u => String(u || '').trim())
        .filter(u => /^https?:\/\//i.test(u))
    )];
    if (urls.length === 0) return;

    // showDownloadsView() clears playlistDetails below, so capture the page
    // state FIRST. Auto-subscribe is only allowed while the Playlist view was
    // actually open and the Playlist-page switch was ON.
    const playlistPageWasOpen = isPlaylistPageOpen;
    const autoSub = autoSubscribeDropped;
    const follows = [];

    // Show the Downloads page and an animated "preparing" row IMMEDIATELY,
    // before the ~5 s getVideoInfo/getPlaylistInfo round-trip. It is a fake
    // progress row only; real queue rows replace it when the jobs are queued.
    showDownloadsView();
    const prepIds = urls.map((rawUrl) => {
      const { forcedSingle } = toSingleVideoUrl(rawUrl);
      return addPreparingDrop({
        label: forcedSingle ? 'Getting your song ready…' : 'Preparing dropped link…',
        detail: rawUrl,
      });
    });
    const clearPreparing = () => prepIds.forEach(id => removePreparingDrop(id));

    try {
      showAppNotice('info', `Preparing ${urls.length} direct download${urls.length === 1 ? '' : 's'}…`);

      const settings = await api.getVideoSettings().catch(() => ({ defaultQuality: 'hd720', directSave: true, directSaveDir: '' }));
      const targetDir = settings.directSaveDir || await api.getDefaultDownloadDir().catch(() => '');
      if (!targetDir) {
        showAppNotice('error', 'Could not find a download folder. Choose one in Settings → Video.');
        return;
      }

      const preset = settings.defaultQuality || 'hd720';
      const wantsMp3 = preset === 'mp3';
      const quality = (preset === 'ask' || wantsMp3) ? 'hd720' : preset;
      const qualityLabel = wantsMp3 ? 'MP3' : quality === 'hd720' ? '720p HD' : quality === 'hd480' ? '480p HD' : 'Best';
      const defaultType = wantsMp3 ? 'mp3' : 'mp4';

      const items = [];
      let failures = 0;
      for (const rawUrl of urls) {
        try {
          // A dropped song link often carries &list=RD…&start_radio=1 (YouTube
          // radio/mix). Strip those params and force the SINGLE-video path so
          // the downloader never tries to read a whole playlist. A real
          // /playlist?list=… link has no video id and still expands normally.
          const single = toSingleVideoUrl(rawUrl);
          const fetchUrl = single.forcedSingle ? single.url : rawUrl;
          const kind = single.forcedSingle ? 'video' : classifyUrl(rawUrl);
          if (kind === 'playlist' || kind === 'hybrid') {
            const playlist = await api.getPlaylistInfo(rawUrl);
            if (!playlist?.success || !Array.isArray(playlist.videos)) {
              failures += 1;
              continue;
            }
            if (playlistPageWasOpen && autoSub && !single.forcedSingle) {
              follows.push(rawUrl);
            }
            for (const v of playlist.videos) {
              items.push({
                videoId: v.id,
                url: v.url,
                title: v.title,
                playlistIndex: v.playlistIndex ?? null,
                thumbnailUrl: v.thumbnail || '',
                quality,
                qualityLabel,
                type: defaultType,
                convertToH264: false,
                sizeBytes: 0,
              });
            }
          } else {
            const info = await api.getVideoInfo(fetchUrl);
            if (!info?.success) {
              failures += 1;
              continue;
            }
            const type = info.isAudioOnly ? 'mp3' : defaultType;
            items.push({
              videoId: info.videoId,
              url: info.webpageUrl || fetchUrl,
              title: info.title,
              thumbnailUrl: info.thumbnailUrl || '',
              quality,
              qualityLabel: type === 'mp3' ? 'MP3' : qualityLabel,
              type,
              convertToH264: false,
              sizeBytes: type === 'mp3' ? (info.audioSize || 0) : 0,
            });
          }
        } catch (err) {
          failures += 1;
        }
      }

      if (items.length === 0) {
        showAppNotice('error', failures ? 'Those links could not be read.' : 'No downloadable link was found.');
        return;
      }

      let result;
      if (api.queueVideoBatch) {
        result = await api.queueVideoBatch({ items, targetDir, keyword }).catch(err => ({ success: false, error: err?.message || 'Could not start downloads.' }));
      } else {
        // Older main process: still direct-download, but one IPC call per item.
        const queued = [];
        for (const item of items) {
          const res = await api.queueVideo({
            ...item,
            direct: true,
            targetDir,
          }).catch(() => ({ success: false }));
          if (res?.success) queued.push(res.jobId);
        }
        result = { success: queued.length > 0, queued: queued.length, jobIds: queued };
      }

      if (!result?.success) {
        showAppNotice('error', result?.error || 'Could not start downloads.');
        return;
      }
      if (result.partial) {
        showAppNotice('warning', `Daily limit: ${result.queued} queued, ${result.skipped} skipped.`);
      } else {
        showAppNotice('success', `${result.queued || items.length} download${(result.queued || items.length) === 1 ? '' : 's'} started.`);
      }

      // Auto-subscribe: follow the dropped playlist without queuing old videos.
      // The drag above already downloads the existing ones; the subscription
      // stores the full ID baseline so only NEW uploads auto-download later.
      for (const feedUrl of follows) {
        try {
          if (subscriptions.some(sub => sub.url === feedUrl)) {
            showAppNotice('info', 'Playlist already followed.');
            continue;
          }
          const res = await window.electronAPI.addSubscription({
            url: feedUrl,
            targetDir,
            downloadExisting: false,
            autoDownload: true,
            quality,
            type: defaultType,
          });
          if (res?.success) {
            showAppNotice('success', 'Playlist followed.');
          } else if (!/already following/i.test(res?.error || '')) {
            showAppNotice('warning', res?.error || 'Could not auto-subscribe to that playlist.');
          }
        } catch (err) {
          showAppNotice('warning', 'Could not auto-subscribe to that playlist.');
        }
      }

      if (failures > 0) {
        showAppNotice('warning', `${failures} link${failures === 1 ? '' : 's'} could not be read; the rest started downloading.`);
      }
    } finally {
      clearPreparing();
    }
  }, [addPreparingDrop, removePreparingDrop, showAppNotice, showDownloadsView,
      isPlaylistPageOpen, autoSubscribeDropped, subscriptions]);

  directDownloadRef.current = directDownloadUrls;

  const handleHybridChoice = (choice) => {
    setHybridPromptUrl(null);
    if (choice === 'playlist') {
      runPlaylistFetch();
    } else {
      runFetch();
    }
  };

  const runPlaylistFetch = useCallback(async () => {
    const currentUrl = urlRef.current;
    if (!currentUrl) return;
    setIsLoading(true);
    setFetchError(null);
    setFetchErrorKind(null);
    setIsAgeRestricted(false);
    setIsPlaylistMode(true);
    setBoundJobId(null);
    const currentFetchId = ++fetchIdRef.current;

    try {
      const result = await window.electronAPI.getPlaylistInfo(currentUrl);
      if (currentFetchId !== fetchIdRef.current) return;
      if (result.success) {
        setPlaylistDetails({ ...result, sourceUrl: currentUrl });
      } else {
        console.error(`Error: ${result.error}`);
        setPlaylistDetails(null);
        if (result.isAgeRestricted) {
          setIsAgeRestricted(true);
          setIsAuthenticated(false);
        }
        setFetchError(result.error);
        setFetchErrorKind(result.errorKind || 'unknown');
      }
    } catch (error) {
      if (currentFetchId !== fetchIdRef.current) return;
      console.error("Failed to fetch playlist details:", error);
      setPlaylistDetails(null);
      setFetchError(error.message || 'Something went wrong');
      setFetchErrorKind('unknown');
    } finally {
      if (currentFetchId === fetchIdRef.current) {
        setIsLoading(false);
      }
    }
  }, []);

  // When yt-dlp finishes and there's a pending fetch queued, auto-trigger it
  const pendingFetchRef = useRef(pendingFetch);
  pendingFetchRef.current = pendingFetch;

  useEffect(() => {
    const done = !ytDlpStatus || ytDlpStatus === 'updated' || ytDlpStatus === 'up-to-date' || ytDlpStatus === 'error';
    if (!done) return;
    if (!pendingFetchRef.current) return;
    const timer = setTimeout(() => {
      setPendingFetch(false);
      const kind = classifyUrl(urlRef.current);
      if (kind === 'hybrid') {
        setIsLoading(false);
        setHybridPromptUrl(urlRef.current);
      } else if (kind === 'playlist') {
        runPlaylistFetch();
      } else {
        runFetch();
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [ytDlpStatus, runFetch, runPlaylistFetch]);

  const goBackToHistory = () => {
    setActivePage('main');
    setUrlInput("");
    setVideoDetails(null);
    setPlaylistDetails(null);
    setIsPlaylistMode(false);
    setHybridPromptUrl(null);
    setFetchError(null);
    setFetchErrorKind(null);
    setIsAgeRestricted(false);
    setPendingFetch(false);
    setIsLoading(false);
    setBoundJobId(null);
    window.electronAPI.cancelPlaylistPrefetch();
  };

  // ── Subscription actions ────────────────────────────────────────────────────
  const openSubscriptions = useCallback(() => {
    setActivePage('subscriptions');
    setVideoDetails(null);
    setPlaylistDetails(null);
    setIsPlaylistMode(false);
    setHybridPromptUrl(null);
    setFetchError(null);
    setFetchErrorKind(null);
    setIsAgeRestricted(false);
    setIsLoading(false);
    setBoundJobId(null);
    setSubsNotice(null);
    // Everything on the page counts as seen once it is on screen
    window.electronAPI.markSubscriptionsSeen()
      .then(() => window.electronAPI.getSubscriptions())
      .then(setSubscriptions)
      .catch(() => {});
  }, []);

  const closeSubscriptions = useCallback(() => {
    setActivePage('main');
    setSubsNotice(null);
  }, []);

  const openPlaylists = useCallback(() => {
    setActivePage('playlists');
    setVideoDetails(null);
    setPlaylistDetails(null);
    setIsPlaylistMode(false);
    setHybridPromptUrl(null);
    setFetchError(null);
    setFetchErrorKind(null);
    setIsAgeRestricted(false);
    setIsLoading(false);
    setPendingFetch(false);
    setBoundJobId(null);
    setSubsNotice(null);
  }, []);

  const closePlaylists = useCallback(() => setActivePage('main'), []);

  const openKeyword = useCallback(() => {
    setActivePage('keyword');
    setVideoDetails(null);
    setPlaylistDetails(null);
    setIsPlaylistMode(false);
    setHybridPromptUrl(null);
    setFetchError(null);
    setFetchErrorKind(null);
    setIsAgeRestricted(false);
    setIsLoading(false);
    setPendingFetch(false);
    setBoundJobId(null);
    setSubsNotice(null);
  }, []);

  const closeKeyword = useCallback(() => setActivePage('main'), []);

  const addSubscription = useCallback(async (payload) => {
    setSubsBusyId('add');
    setSubsNotice(null);
    try {
      const fallbackDir = payload?.targetDir || await window.electronAPI.getLastSubscriptionDir();
      let targetDir = payload?.targetDir || fallbackDir;
      if (!targetDir) {
        targetDir = await window.electronAPI.pickSubscriptionFolder();
        if (!targetDir) return { success: false, canceled: true };
      }
      const res = await window.electronAPI.addSubscription({ ...payload, targetDir });
      if (res.success) {
        setSubsNotice({ kind: 'ok', text: `Following "${res.subscription.title}".` });
      } else {
        setSubsNotice({ kind: 'error', text: res.error || 'Could not subscribe.' });
      }
      return res;
    } finally {
      setSubsBusyId(null);
    }
  }, []);

  const updateSubscription = useCallback(async (id, patch) => {
    const res = await window.electronAPI.updateSubscription(id, patch);
    if (!res.success) setSubsNotice({ kind: 'error', text: res.error || 'Update failed.' });
    return res;
  }, []);

  const removeSubscription = useCallback(async (id) => {
    const res = await window.electronAPI.removeSubscription(id);
    if (res.success) setSubsNotice({ kind: 'ok', text: 'Subscription removed.' });
    return res;
  }, []);

  const checkSubscription = useCallback(async (id = null) => {
    setSubsBusyId(id || 'all');
    setSubsNotice(null);
    setSubsCheckProgress(id ? null : { phase: 'starting', index: 0, total: 0, title: '' });
    try {
      const res = await window.electronAPI.checkSubscription(id);
      if (res.success) {
        const results = res.results || [];
        const found = results.reduce((acc, r) => acc + (r.found || 0), 0);
        const baseline = results.filter(r => r.baseline).length;
        const failed = results.filter(r => r.ok === false).length;
        let text = 'Scan finished — nothing new.';
        if (found > 0) text = `Scan finished — ${found} new video${found === 1 ? '' : 's'} downloading.`;
        else if (baseline > 0) text = 'Following — only new uploads will download.';
        if (failed > 0) text += ` ${failed} playlist${failed === 1 ? '' : 's'} could not be read.`;
        setSubsNotice({ kind: failed ? 'error' : 'ok', text });
      } else {
        setSubsNotice({ kind: 'error', text: res.error || 'Check failed.' });
      }
      return res;
    } finally {
      setSubsBusyId(null);
      setSubsCheckProgress(null);
    }
  }, []);

  /** Adopt the newest video as the saved id without downloading anything. */
  const rebaselineSubscription = useCallback(async (id) => {
    if (!id || !window.electronAPI.rebaselineSubscription) {
      return { success: false, error: 'Not available.' };
    }
    setSubsBusyId(id);
    setSubsNotice(null);
    try {
      const res = await window.electronAPI.rebaselineSubscription(id);
      setSubsNotice(res.success
        ? { kind: 'ok', text: 'Saved the newest video as the starting point.' }
        : { kind: 'error', text: res.error || 'Could not re-baseline this playlist.' });
      return res;
    } finally {
      setSubsBusyId(null);
    }
  }, []);

  /** Start Scan — scans now, then keeps to the saved interval. */
  const startSubscriptionScan = useCallback(async () => {
    setSubsNotice(null);
    const res = await window.electronAPI.startSubscriptionScan?.();
    if (res?.state) setScanState(res.state);
    return res;
  }, []);

  /** Stop Scan — no scheduled scans until started again. */
  const stopSubscriptionScan = useCallback(async () => {
    const res = await window.electronAPI.stopSubscriptionScan?.();
    if (res?.state) setScanState(res.state);
    setSubsNotice({ kind: 'ok', text: 'Scan stopped.' });
    return res;
  }, []);

  const setSubscriptionScanInterval = useCallback(async (minutes) => {
    const res = await window.electronAPI.setSubscriptionScanInterval?.(minutes);
    if (res?.state) setScanState(res.state);
    return res;
  }, []);

  const downloadSubscriptionVideo = useCallback(async (subscriptionId, videoId) => {
    return window.electronAPI.downloadSubscriptionVideo({ subscriptionId, videoId });
  }, []);

  const changeSubscriptionFolder = useCallback(async (id) => {
    const dir = await window.electronAPI.pickSubscriptionFolder();
    if (!dir) return { success: false, canceled: true };
    return updateSubscription(id, { targetDir: dir });
  }, [updateSubscription]);

  const unsubscribeCount = useMemo(() => subscriptions.length, [subscriptions]);
  // Bell badge: videos found since this subscription was last looked at
  const subscriptionUnseen = useMemo(
    () => subscriptions.reduce(
      (acc, s) => acc + (s.newVideos || []).filter(v => (v.detectedAt || 0) > (s.lastSeenAt || 0)).length,
      0
    ),
    [subscriptions]
  );

  const cancelFetchDetails = () => {
    fetchIdRef.current++;
    window.electronAPI.cancelInfoFetch();
    goBackToHistory();
  };

  const handleUrlChange = (newUrl) => {
    const next = rawInputText(newUrl);
    setUrlInput(next);
    if (!next.trim()) {
      setVideoDetails(null);
      setPlaylistDetails(null);
      setIsPlaylistMode(false);
      setHybridPromptUrl(null);
      setFetchError(null);
      setFetchErrorKind(null);
      setIsAgeRestricted(false);
      setBoundJobId(null);
    }
  };

  const refreshHistory = async () => {
    const data = await window.electronAPI.getHistory();
    setHistory(data);
  };

  /**
   * Open the view for an in-flight job — restores the exact Details/Playlist
   * view the download was started from.
   */
  const viewJob = (job) => {
    setFetchError(null);
    setFetchErrorKind(null);
    setHybridPromptUrl(null);
    setIsAgeRestricted(false);
    setIsLoading(false);
    if (job.kind === 'video') {
      setPlaylistDetails(null);
      setIsPlaylistMode(false);
      setVideoDetails(job.meta || {
        videoId: job.videoId,
        title: job.title,
        thumbnailUrl: job.thumbnailUrl,
        description: '',
        formats: [],
      });
    } else {
      setVideoDetails(null);
      setPlaylistDetails({
        title: job.title,
        uploader: job.uploader,
        videos: (job.items || []).map(it => ({
          id: it.id,
          url: it.url,
          title: it.title,
          duration: it.duration,
          thumbnail: it.thumbnail,
          uploader: job.uploader,
        })),
      });
      setIsPlaylistMode(true);
    }
    setBoundJobId(job.id);
  };

  const activeJobs = useMemo(() => jobs.filter(j => j.status === 'queued' || j.status === 'downloading'), [jobs]);
  const isDownloading = activeJobs.some(j => j.status === 'downloading');

  const value = {
    url,
    urlInputRef,
    videoDetails,
    playlistDetails,
    isPlaylistMode,
    hybridPromptUrl,
    history,
    isLoading,
    fetchError,
    fetchErrorKind,
    ytDlpStatus,
    ytDlpEngine,
    checkYtDlpUpdate,
    downloadYtDlp,
    // Pro license + daily limit
    license,
    redeemKey,
    isQrOpen,
    qrReason,
    openQr,
    closeQr,
    isLicenseOpen,
    openLicense,
    closeLicense,
    appNotice,
    exportSubscriptions,
    importSubscriptions,
    pendingFetch,
    isYtDlpBusy,
    isAuthenticated,
    authExpired,
    isAgeRestricted,
    // queue
    jobs,
    activeJobs,
    preparingDrops,
    cancelAllJobs,
    cleanTempFiles,
    isDownloading,
    jobProgress,
    jobResults,
    boundJobId,
    setBoundJobId,
    viewJob,
    // pages
    activePage,
    isPlaylistPageOpen,
    autoSubscribeDropped,
    updateAutoSubscribeDropped,
    openSubscriptions,
    closeSubscriptions,
    openPlaylists,
    closePlaylists,
    openKeyword,
    closeKeyword,
    openBrowser,
    // subscriptions
    subscriptions,
    subscriptionUnseen,
    unsubscribeCount,
    subsBusyId,
    subsNotice,
    subsCheckProgress,
    setSubsNotice,
    addSubscription,
    updateSubscription,
    removeSubscription,
    checkSubscription,
    rebaselineSubscription,
    downloadSubscriptionVideo,
    scanState,
    startSubscriptionScan,
    stopSubscriptionScan,
    setSubscriptionScanInterval,
    changeSubscriptionFolder,
    // settings
    isSettingsOpen,
    settingsTab,
    openSettings,
    closeSettings,
    // versions
    appVersion,
    latestVersion,
    hasNewVersion,
    versionChecked,
    // actions
    setUrl,
    setVideoDetails,
    setPlaylistDetails,
    setHistory,
    setIsLoading,
    handleUrlChange,
    handleFetchDetails,
    openUrl,
    directDownloadUrls,
    queueKeywordSearch,
    videoSettings,
    updateVideoSettings,
    handleHybridChoice,
    cancelFetchDetails,
    goBackToHistory,
    refreshHistory,
    loginYoutube,
    logoutYoutube,
    refreshAuth,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};
