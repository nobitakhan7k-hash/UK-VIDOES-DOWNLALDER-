const { contextBridge, ipcRenderer } = require("electron");

// Helper: single-listener subscription (replaces any previous listener to prevent stacking)
const subscribe = (channel) => (callback) => {
  ipcRenderer.removeAllListeners(channel);
  ipcRenderer.on(channel, (_event, value) => callback(value));
};

contextBridge.exposeInMainWorld("electronAPI", {
  platform: process.platform,

  // Info fetching
  getVideoInfo: (url) => ipcRenderer.invoke("get-video-info", url),
  getPlaylistInfo: (url) => ipcRenderer.invoke("get-playlist-info", url),
  cancelInfoFetch: () => ipcRenderer.send("cancel-info-fetch"),

  // Playlist format prefetching (parallel, streamed results)
  prefetchPlaylistFormats: (videos) => ipcRenderer.invoke("prefetch-playlist-formats", videos),
  cancelPlaylistPrefetch: () => ipcRenderer.send("cancel-playlist-prefetch"),
  onPlaylistFormatResult: subscribe("playlist-format-result"),

  // Download queue
  queueVideo: (options) => ipcRenderer.invoke("queue-video", options),
  queueVideoBatch: (options) => ipcRenderer.invoke("queue-video-batch", options),
  queueKeywordSearch: (query, limit) => ipcRenderer.invoke("queue-keyword-search", {
    query: typeof query === 'string' ? query : '',
    limit,
  }),
  keywordScan: (options = {}) => ipcRenderer.invoke('keyword-page:scan', options),
  queuePlaylist: (options) => ipcRenderer.invoke("queue-playlist", options),
  getQueue: () => ipcRenderer.invoke("get-queue"),
  cancelJob: (options) => ipcRenderer.send("cancel-job", options),
  cancelAllJobs: () => ipcRenderer.invoke("cancel-all-jobs"),
  skipPlaylistItem: (options) => ipcRenderer.send("skip-playlist-item", options),
  pauseDownload: () => ipcRenderer.send("pause-download"),
  resumeDownload: () => ipcRenderer.send("resume-download"),
  onQueueUpdated: subscribe("queue-updated"),
  onDownloadProgress: subscribe("download-progress"),
  onJobFinished: subscribe("job-finished"),

  // Files & folders
  chooseDirectory: () => ipcRenderer.invoke("choose-directory"),
  getDefaultDownloadDir: () => ipcRenderer.invoke("get-default-download-dir"),
  cleanupTempFiles: (options = {}) => ipcRenderer.invoke("cleanup-temp-files", options),
  downloadThumbnail: (options) => ipcRenderer.invoke("download-thumbnail", options),
  openFileLocation: (filePath) => ipcRenderer.invoke("open-file-location", filePath),
  openFileOrFolder: (options) => ipcRenderer.invoke("open-file-or-folder", options),
  fileExists: (filePath) => ipcRenderer.invoke("file-exists", filePath),
  openExternalLink: (url) => ipcRenderer.invoke("open-external-link", url),
  // Separate YouTube Browse window + right-click download bridge
  openBrowseWindow: () => ipcRenderer.invoke("browse:open"),
  onBrowseDownloadUrl: subscribe("browse-download-url"),

  // History
  getHistory: () => ipcRenderer.invoke("get-history"),
  clearHistory: () => ipcRenderer.invoke("clear-history"),
  addHistoryItem: (item) => ipcRenderer.invoke("add-history-item", item),
  updateHistoryItem: (item) => ipcRenderer.invoke("update-history-item", item),
  deleteHistoryItem: (timestamp) => ipcRenderer.invoke("delete-history-item", timestamp),
  onHistoryUpdated: subscribe("history-updated"),

  // YouTube auth
  loginYoutube: () => ipcRenderer.invoke("login-youtube"),
  logoutYoutube: () => ipcRenderer.invoke("logout-youtube"),
  checkYoutubeAuth: () => ipcRenderer.invoke("check-youtube-auth"),

  // Per-playlist download folder (remembered per playlist)
  getPlaylistDir: (payload) => ipcRenderer.invoke("get-playlist-dir", payload),
  setPlaylistDir: (payload) => ipcRenderer.invoke("set-playlist-dir", payload),

  // Video settings (720p HD / 480p HD / MP3, 2-4-6 parallel, keyword limit, direct save)
  getVideoSettings: () => ipcRenderer.invoke("get-video-settings"),
  setVideoSettings: (patch) => ipcRenderer.invoke("set-video-settings", patch),
  onVideoSettingsUpdated: subscribe("video-settings-updated"),

  // Playlist / channel subscriptions (auto-download new videos)
  getSubscriptions: () => ipcRenderer.invoke("subscriptions:list"),
  getSubscriptionOptions: () => ipcRenderer.invoke("subscriptions:options"),
  addSubscription: (payload) => ipcRenderer.invoke("subscriptions:add", payload),
  updateSubscription: (id, patch) => ipcRenderer.invoke("subscriptions:update", { id, patch }),
  removeSubscription: (id) => ipcRenderer.invoke("subscriptions:remove", id),
  checkSubscription: (id = null) => ipcRenderer.invoke("subscriptions:check", id),
  // Smart scan engine: start / stop / interval are owned by the main process.
  getSubscriptionScanState: () => ipcRenderer.invoke("subscriptions:scan-state"),
  startSubscriptionScan: (intervalMinutes = null) => ipcRenderer.invoke("subscriptions:scan-start", intervalMinutes),
  stopSubscriptionScan: () => ipcRenderer.invoke("subscriptions:scan-stop"),
  setSubscriptionScanInterval: (minutes) => ipcRenderer.invoke("subscriptions:scan-interval", minutes),
  onSubscriptionScanState: subscribe("subscription-scan-state"),
  markSubscriptionsSeen: () => ipcRenderer.invoke("subscriptions:mark-seen"),
  downloadSubscriptionVideo: (payload) => ipcRenderer.invoke("subscriptions:download-video", payload),
  openSubscriptionFolder: (id) => ipcRenderer.invoke("subscriptions:open-folder", id),
  pickSubscriptionFolder: () => ipcRenderer.invoke("subscriptions:pick-folder"),
  getLastSubscriptionDir: () => ipcRenderer.invoke("get-last-subscription-dir"),
  // Dedicated Playlists hub — recent playlists (local electron-store only)
  playlistHubList: () => ipcRenderer.invoke("playlist-hub:list"),
  playlistHubAdd: (entry) => ipcRenderer.invoke("playlist-hub:add", entry),
  playlistHubRemove: (url) => ipcRenderer.invoke("playlist-hub:remove", url),
  getAutoSubscribeDropped: () => ipcRenderer.invoke("get-auto-subscribe-dropped"),
  setAutoSubscribeDropped: (enabled) => ipcRenderer.invoke("set-auto-subscribe-dropped", enabled),
  exportSubscriptions: () => ipcRenderer.invoke("subscriptions:export"),
  importSubscriptions: () => ipcRenderer.invoke("subscriptions:import"),
  rebaselineSubscription: (id) => ipcRenderer.invoke("subscriptions:rebaseline", id),
  onSubscriptionsUpdated: subscribe("subscriptions-updated"),
  onSubscriptionNewVideos: subscribe("subscription-new-videos"),
  onSubscriptionCheckProgress: subscribe("subscription-check-progress"),

  // yt-dlp update status (legacy loading-screen channel)
  onYtDlpUpdateStatus: subscribe("ytdlp-update-status"),
  getYtDlpStatus: () => ipcRenderer.invoke("get-ytdlp-status"),

  // yt-dlp engine — auto-download / auto-update, shown in Settings + toast
  onYtDlpEngineStatus: subscribe("ytdlp-engine-status"),
  getYtDlpEngine: () => ipcRenderer.invoke("get-yt-dlp-engine"),
  checkYtDlpUpdate: () => ipcRenderer.invoke("check-yt-dlp-update"),
  downloadYtDlp: () => ipcRenderer.invoke("download-yt-dlp"),

  // Pro keys + daily download limit (offline)
  getLicenseState: () => ipcRenderer.invoke("get-license-state"),
  redeemLicenseKey: (key) => ipcRenderer.invoke("redeem-license-key", key),
  onLicenseState: subscribe("license-state"),
  onLicenseUpdated: subscribe("license-updated"),
  onDailyUsageUpdated: subscribe("daily-usage-updated"),
  onDailyLimitReached: subscribe("daily-limit-reached"),

  // Generic on-screen notice (big-playlist partial queue, import/export, etc.)
  onAppNotice: subscribe("app-notice"),

  // App version
  getAppVersion: () => ipcRenderer.invoke("get-app-version"),

  // Appearance — read synchronously at preload time so the renderer can paint
  // the right theme on its very first frame (no flash on startup).
  initialAppearance: ipcRenderer.sendSync("get-appearance-sync"),
  getAppearance: () => ipcRenderer.invoke("get-appearance"),
  setAppearance: (preference) => ipcRenderer.invoke("set-appearance", preference),
  onAppearanceChanged: subscribe("appearance-changed"),
});
