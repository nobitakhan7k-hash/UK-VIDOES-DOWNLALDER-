// Minimal preload for the separate YouTube Browse window.
// It exposes NO app internals to a remote page. It only:
//   1) reports the link under a right-click to the main process,
//   2) focuses YouTube's search box after the page loads, and
//   3) mounts a tiny floating Back / Forward / Home / Reload toolbar.
//
// IMPORTANT: with contextIsolation:true this file runs in an isolated world.
// contextBridge.exposeInMainWorld() makes `window.ukBrowse` visible to the
// PAGE's main world, NOT to this preload. Keep a local `api` object and use it
// directly here; never call `window.ukBrowse` from the preload itself.
const { contextBridge, ipcRenderer } = require('electron');

function absoluteHref(el) {
  let node = el;
  while (node && node !== document) {
    const href = node.getAttribute && node.getAttribute('href');
    if (href) {
      try { return new URL(href, location.href).toString(); } catch (e) { return null; }
    }
    node = node.parentElement;
  }
  return null;
}

const api = {
  reportContextUrl: (url) => ipcRenderer.send('browse:context-url', url),
  goBack: () => ipcRenderer.invoke('browse:back'),
  goForward: () => ipcRenderer.invoke('browse:forward'),
  goHome: () => ipcRenderer.invoke('browse:home'),
  reload: () => ipcRenderer.invoke('browse:reload'),
  navState: () => ipcRenderer.invoke('browse:nav-state'),
};
contextBridge.exposeInMainWorld('ukBrowse', api);

// Capture phase so YouTube's own handlers cannot swallow the event first.
document.addEventListener('contextmenu', (event) => {
  const url = absoluteHref(event.target);
  if (url) ipcRenderer.send('browse:context-url', url);
}, true);

function focusSearch() {
  const input = document.querySelector(
    'input#search, input[name="search_query"], input[aria-label*="Search"], input[placeholder*="Search"]'
  );
  if (input) {
    input.focus();
    if (typeof input.select === 'function') input.select();
  }
}

let lastReportedQuery = '';
function currentSearchQuery() {
  try {
    const u = new URL(location.href);
    const fromUrl = u.searchParams.get('search_query');
    if (fromUrl && fromUrl.trim()) return fromUrl.trim();
    // Only a results page may fall back to the visible search box; a watch
    // page can hold unrelated text in that input.
    if (u.pathname !== '/results' && u.pathname !== '/search') return '';
  } catch (e) {
    return '';
  }
  try {
    const input = document.querySelector(
      'input#search, input[name="search_query"], input[aria-label*="Search"], input[placeholder*="Search"]'
    );
    const value = input && input.value ? String(input.value).trim() : '';
    return value && !/^https?:\/\//i.test(value) ? value : '';
  } catch (e) {
    return '';
  }
}

function reportSearchQuery() {
  const q = currentSearchQuery();
  if (!q || q === lastReportedQuery) return;
  lastReportedQuery = q;
  ipcRenderer.send('browse:search-query', { query: q, url: location.href });
}

const NAV_ACTIONS = {
  back: async () => {
    const res = await api.goBack().catch(() => ({ success: false }));
    // Fallback for pure pushState navigations Electron's history may not see.
    if (!res || res.success === false) window.history.back();
  },
  forward: async () => {
    const res = await api.goForward().catch(() => ({ success: false }));
    if (!res || res.success === false) window.history.forward();
  },
  home: () => api.goHome(),
  reload: () => api.reload(),
};

function mountNav() {
  if (!document.body || document.getElementById('uk-browse-nav')) return;
  const bar = document.createElement('div');
  bar.id = 'uk-browse-nav';
  bar.setAttribute('role', 'toolbar');
  bar.setAttribute('aria-label', 'Navigation');

  const make = (act, label, text, title) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.dataset.act = act;
    b.className = 'uk-browse-nav-btn';
    b.textContent = text;
    b.setAttribute('aria-label', label);
    b.title = title || label;
    return b;
  };

  bar.appendChild(make('back', 'Back', '← Back', 'Back'));
  bar.appendChild(make('forward', 'Forward', '→', 'Forward'));
  bar.appendChild(make('home', 'Home', '⌂', 'Home'));
  bar.appendChild(make('reload', 'Reload', '⟳', 'Reload'));
  document.body.appendChild(bar);

  function applyState(state) {
    if (!state) return;
    const back = bar.querySelector('[data-act="back"]');
    const forward = bar.querySelector('[data-act="forward"]');
    if (back) back.disabled = !state.canGoBack;
    if (forward) forward.disabled = !state.canGoForward;
  }
  function updateNav() {
    api.navState().then(applyState).catch(() => {});
  }

  bar.addEventListener('click', (event) => {
    const btn = event.target.closest && event.target.closest('button[data-act]');
    if (!btn || btn.disabled) return;
    const fn = NAV_ACTIONS[btn.dataset.act];
    if (fn) Promise.resolve(fn()).then(updateNav).catch(() => {});
  });

  // Main process pushes state on did-navigate / did-navigate-in-page.
  ipcRenderer.on('browse:nav-updated', (_event, state) => applyState(state));
  // Keyboard shortcut: Alt+Left / Alt+Right, like a real browser.
  document.addEventListener('keydown', (event) => {
    if (event.altKey && event.key === 'ArrowLeft') {
      event.preventDefault();
      NAV_ACTIONS.back().then(updateNav).catch(() => {});
    } else if (event.altKey && event.key === 'ArrowRight') {
      event.preventDefault();
      NAV_ACTIONS.forward().then(updateNav).catch(() => {});
    }
  }, true);

  updateNav();
  // SPA navigations do not always emit did-navigate; keep the buttons honest.
  setInterval(updateNav, 1200);
}

document.addEventListener('DOMContentLoaded', () => {
  setTimeout(focusSearch, 600);
  setTimeout(focusSearch, 1500);
  setTimeout(mountNav, 400);
  setTimeout(mountNav, 1200);
  setTimeout(reportSearchQuery, 600);
  setTimeout(reportSearchQuery, 1500);
  window.addEventListener('popstate', () => setTimeout(reportSearchQuery, 250));
  // YouTube uses pushState for search; poll so SPA changes are not missed.
  setInterval(reportSearchQuery, 900);
});
