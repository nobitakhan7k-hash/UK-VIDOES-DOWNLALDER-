const { app, BrowserWindow, ipcMain, dialog, shell, net, session, nativeTheme, Notification, Menu, clipboard } = require("electron");
const path = require("path");
const fs = require("fs");
const os = require("os");
const { pathToFileURL } = require("url");
const { spawn, execFile, execFileSync } = require("child_process");
const crypto = require("crypto");
const {
  FOLDER_THUMBNAIL_NAME,
  safeFolderName,
  uniqueFolderPath,
  ensureFolder,
  replaceFolderThumbnail,
} = require('./lib/subscriptionFolder.cjs');
const {
  KEYWORD_THUMBNAIL_NAME,
  safeKeyword,
  ensureKeywordFolder,
  keywordThumbnailCandidates,
} = require('./lib/keywordFolder.cjs');
const {
  buildKeywordSearchUrl,
  normalizeKeywordScanOptions,
  summarizeKeywordEntries,
} = require('./lib/keywordScan.cjs');
const { PARALLEL_DEFAULT, clampParallel } = require('./lib/parallel.cjs');
const { cleanupLeftovers } = require('./lib/tempCleanup.cjs');
const {
  isUnavailableEntry,
  findNewVideos,
  advanceAnchor,
  isScanDue,
  mergeDetected,
  normalizeRecord,
  toStorageDocument,
  writeJsonAtomic,
  readSubscriptionsFile,
  saveSubscriptionsFile,
} = require('./lib/playlistSubscription.cjs');

// Fix asar-packed paths: ffmpeg-static/ffprobe-static resolve inside .asar
// which isn't executable. asarUnpack extracts them to .asar.unpacked.
const fixAsar = (p) => p.replace('app.asar', 'app.asar.unpacked');
const ffmpegPath = fixAsar(require('ffmpeg-static'));
const ffprobePath = fixAsar(require('ffprobe-static').path);

// Build env with ffmpeg+ffprobe directories on PATH so yt-dlp can find both.
// Inject ELECTRON_RUN_AS_NODE=1 so if yt-dlp spawns us as a Node JS runtime,
// Electron acts as a headless Node terminal instead of opening a second GUI window.
function getYtDlpEnv() {
  const dirs = new Set([path.dirname(ffmpegPath), path.dirname(ffprobePath)]);
  const extraPath = [...dirs].join(path.delimiter);
  return {
    ...process.env,
    PATH: `${extraPath}${path.delimiter}${process.env.PATH || ''}`,
    ELECTRON_RUN_AS_NODE: '1'
  };
}

// electron-store v8 exports the class directly.
//
// Do NOT reintroduce a `.default || ` interop guard here. ElectronStore extends
// Conf, and conf's CJS interop sets `Conf.default = Conf`, so
// `ElectronStore.default` resolves *up the static chain* to plain Conf — which
// knows nothing about Electron and writes to envPaths('electron-store') instead
// of app.getPath('userData'). That regression silently moved every user's
// config out of userData; migrateMisplacedStore() below cleans it up.
const Store = require("electron-store");


// Base yt-dlp flags shared by info fetch and download
const BASE_ARGS = [
  '--no-playlist',
  '--ignore-config',
  '--retries', '10',
  '--retry-sleep', '3',
  '--fragment-retries', '10',
  '--socket-timeout', '20',
  // Explicitly command yt-dlp to use our bundled Electron executable as the Node.js runtime to solve YouTube's bot-challenges (HTTP Error 429).
  '--js-runtimes', `node:${process.execPath}`,
];

// Download-only fragment connections are built dynamically from the SAME
// global setting that controls parallel jobs (see downloadSpeedArgs below).

/**
 * The config location plain `conf` falls back to when it cannot see Electron's
 * `app` module — i.e. env-paths('electron-store', { suffix: 'nodejs' }).config.
 * Spelled out per platform rather than pulled from env-paths so it stays
 * readable and does not depend on a transitive dependency surviving bundling.
 */
function legacyMisplacedConfigPath() {
  const name = 'electron-store-nodejs';
  const home = os.homedir();
  if (process.platform === 'darwin') {
    return path.join(home, 'Library', 'Preferences', name, 'config.json');
  }
  if (process.platform === 'win32') {
    const appData = process.env.APPDATA || path.join(home, 'AppData', 'Roaming');
    return path.join(appData, name, 'Config', 'config.json');
  }
  return path.join(process.env.XDG_CONFIG_HOME || path.join(home, '.config'), name, 'config.json');
}

function readJsonOrNull(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
}


/**
 * One-time data migration for the rename to UK Downloader.
 *
 * Electron derives userData from package.json's productName, so changing the
 * product name would move config.json (history, settings, subscriptions,
 * playlist folders), youtube_cookies.txt and the writable yt-dlp binary into a
 * new folder. Copy the old YT-Forge data across once, without overwriting
 * anything the new build has already written. The old folder is left in place
 * as a backup — nothing is deleted.
 */
function migrateLegacyBrandData() {
  const legacyDir = path.join(app.getPath('appData'), 'YT-Forge');
  const currentDir = app.getPath('userData');
  if (legacyDir === currentDir || !fs.existsSync(legacyDir)) return;

  const copied = [];
  const filesToCopy = ['config.json', 'config.json.pre-migration-backup', 'youtube_cookies.txt'];
  for (const name of filesToCopy) {
    const from = path.join(legacyDir, name);
    const to = path.join(currentDir, name);
    if (!fs.existsSync(from) || fs.existsSync(to)) continue;
    try {
      fs.mkdirSync(path.dirname(to), { recursive: true });
      fs.copyFileSync(from, to);
      copied.push(name);
    } catch (err) {
      console.error('[store] could not migrate ' + name + ':', err);
    }
  }

  // The self-updating yt-dlp binary lives in userData/bin. Reuse it so the
  // first launch after the rename does not need a fresh download.
  const legacyBin = path.join(legacyDir, 'bin');
  const currentBin = path.join(currentDir, 'bin');
  if (fs.existsSync(legacyBin)) {
    try {
      fs.mkdirSync(currentBin, { recursive: true });
      for (const entry of fs.readdirSync(legacyBin)) {
        const from = path.join(legacyBin, entry);
        const to = path.join(currentBin, entry);
        if (!fs.statSync(from).isFile() || fs.existsSync(to)) continue;
        fs.copyFileSync(from, to);
        if (process.platform !== 'win32') {
          try { fs.chmodSync(to, '755'); } catch { /* non-fatal */ }
        }
        copied.push('bin/' + entry);
      }
    } catch (err) {
      console.error('[store] could not migrate yt-dlp binary:', err);
    }
  }

  if (copied.length) {
    console.log('[store] migrated from ' + legacyDir + ': ' + copied.join(', '));
  }
}

/**
 * One-time repair for a config file written outside userData.
 *
 * Affected builds instantiated raw `conf` instead of electron-store (see the
 * note above the require), so settings, theme and download history landed in
 * ~/Library/Preferences/electron-store-nodejs (and the equivalent elsewhere)
 * instead of userData. Installs that predate the regression also have an older
 * config in the correct place, so this MERGES the two rather than overwriting:
 *
 *   - scalar keys come from the misplaced file, which is always the newer one;
 *   - downloadHistory is concatenated and re-sorted newest-first. Nothing is
 *     deduplicated — history entries are addressed by `timestamp` elsewhere in
 *     this file and duplicates already occur legitimately, so dropping any
 *     would delete real history.
 *
 * Runs before the store is constructed. On success the misplaced file is
 * renamed, not deleted, which both keeps the original bytes recoverable and
 * makes this a no-op on every later launch.
 */
function migrateMisplacedStore() {
  const legacyPath = legacyMisplacedConfigPath();
  const legacy = readJsonOrNull(legacyPath);
  if (!legacy) return; // nothing misplaced, or unreadable — leave it alone

  const correctPath = path.join(app.getPath('userData'), 'config.json');
  const current = readJsonOrNull(correctPath);

  const merged = { ...(current || {}), ...legacy };
  const history = [
    ...(Array.isArray(legacy.downloadHistory) ? legacy.downloadHistory : []),
    ...(current && Array.isArray(current.downloadHistory) ? current.downloadHistory : []),
  ];
  if (history.length) {
    history.sort((a, b) => String(b.timestamp ?? '').localeCompare(String(a.timestamp ?? '')));
    merged.downloadHistory = history;
  }

  try {
    fs.mkdirSync(path.dirname(correctPath), { recursive: true });
    // Keep whatever we are about to replace, so a bad merge stays recoverable.
    if (current) fs.copyFileSync(correctPath, correctPath + '.pre-migration-backup');
    // '\t' matches conf's own serialisation, so the file format is unchanged.
    fs.writeFileSync(correctPath, JSON.stringify(merged, null, '\t'), 'utf8');
    fs.renameSync(legacyPath, legacyPath + '.migrated');
    console.log('[store] merged misplaced config into ' + correctPath);
  } catch (err) {
    // A failed migration must never stop the app launching — the store simply
    // loads whatever is already at the correct path.
    console.error('[store] config migration failed:', err);
  }
}

migrateLegacyBrandData();
migrateMisplacedStore();

const store = new Store();
// Clear any download history migrated from an older install, never write a
// new entry, and let finished jobs leave the active list.
store.set('downloadHistory', []);
let mainWindow;
let browseWindow = null;   // separate YouTube browsing GUI
let browseContextUrl = null; // link reported by the browse preload on right-click
let browseKeyword = '';      // most recent YouTube search term in the Browse window

/** Read the search term out of a YouTube results URL. */
function searchQueryFromUrl(raw) {
  try {
    const u = new URL(String(raw || ''));
    if (!isYouTubeUrl(u.toString())) return '';
    const q = u.searchParams.get('search_query') || u.searchParams.get('q') || '';
    return safeKeyword(q);
  } catch (e) {
    return '';
  }
}

/** Remember the latest term, so opening a video still keeps its search. */
function captureBrowseKeyword(rawUrl) {
  const q = searchQueryFromUrl(rawUrl);
  if (q) browseKeyword = q;
}

function currentBrowseKeyword() {
  try {
    return searchQueryFromUrl(browseWindow && !browseWindow.isDestroyed()
      ? browseWindow.webContents.getURL() : '') || browseKeyword;
  } catch (e) {
    return browseKeyword;
  }
}
let currentInfoFetchProcess = null;
let isUpdatingYtDlp = false;
let ytDlpPhase = null; // legacy 'checking' | 'downloading' | null — get-ytdlp-status
let ytDlpUpdateRunning = false;
let ytDlpRecheckTimer = null;

// Persistent, GUI-visible state of the bundled yt-dlp engine. The app downloads
// the binary itself when it is missing, self-updates it, and shows every phase
// (including the version before/after) in Settings plus a toast.
const YTDLP_ENGINE_KEY = 'ytDlpEngineV1';
const YTDLP_RECHECK_MS = 6 * 60 * 60 * 1000;
let ytDlpEngine = {
  phase: 'idle', // idle | checking | downloading | installing | updated | up-to-date | postponed | error
  version: null,
  previousVersion: null,
  lastChecked: null,
  lastUpdated: null,
  message: '',
};
try {
  const savedEngine = store.get(YTDLP_ENGINE_KEY, null);
  if (savedEngine && typeof savedEngine === 'object') {
    // Never restore a transient phase after a restart.
    ytDlpEngine = { ...ytDlpEngine, ...savedEngine, phase: 'idle' };
  }
} catch (err) {
  console.error('[ytdlp] could not restore engine state:', err);
}
// ---------------------------------------------------------------------------
// Pro keys + daily download limit (offline, no server, no telemetry)
// ---------------------------------------------------------------------------
const LICENSE_SECRET = 'UK-Downloader-Pro-2026-Usman-v6-local';
const LICENSE_KEY = 'licenseV1';
const DAILY_USAGE_KEY = 'dailyUsageV1';
const DAILY_LIMIT = 10;

function todayKey() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

function getDailyUsage() {
  const today = todayKey();
  const stored = store.get(DAILY_USAGE_KEY, null);
  if (!stored || stored.date !== today) {
    const fresh = { date: today, count: 0 };
    store.set(DAILY_USAGE_KEY, fresh);
    return fresh;
  }
  return stored;
}

function getLicenseRecord() {
  const rec = store.get(LICENSE_KEY, null);
  return rec && typeof rec === 'object' ? rec : null;
}

function isProActive() {
  const rec = getLicenseRecord();
  if (!rec) return false;
  if (rec.type === 'LIFE') return true;
  if (rec.type === '6M' && rec.expiresAt && Date.now() < new Date(rec.expiresAt).getTime()) return true;
  return false;
}

function getLicenseState() {
  const usage = getDailyUsage();
  const rec = getLicenseRecord();
  const isPro = isProActive();
  const count = usage.count || 0;
  return {
    isPro,
    type: rec?.type || null,
    key: rec?.key || null,
    activatedAt: rec?.activatedAt || null,
    expiresAt: rec?.expiresAt || null,
    dailyCount: count,
    dailyLimit: DAILY_LIMIT,
    remaining: Math.max(0, DAILY_LIMIT - count),
    today: usage.date,
    limitReached: !isPro && count >= DAILY_LIMIT,
  };
}

function publishLicenseState(state) {
  safeSend('license-state', state);
  safeSend('license-updated', state);
  safeSend('daily-usage-updated', state);
}

function validateLicenseKey(raw) {
  const key = String(raw || '').trim().toUpperCase().replace(/\s+/g, '');
  const m = key.match(/^UKD-(6M|LIFE)-([0-9A-F]{8})-([0-9A-F]{8})$/);
  if (!m) {
    return {
      valid: false,
      error: 'Invalid key.',
    };
  }
  const [, type, id, sig] = m;
  const expected = crypto.createHmac('sha256', LICENSE_SECRET)
    .update(`${type}:${id}`)
    .digest('hex')
    .slice(0, 8)
    .toUpperCase();
  if (sig !== expected) return { valid: false, error: 'This key is not valid for UK Downloader.' };
  return { valid: true, type, key };
}

function redeemLicenseKey(raw) {
  const check = validateLicenseKey(raw);
  if (!check.valid) return { success: false, error: check.error };
  const now = new Date();
  let expiresAt = null;
  if (check.type === '6M') {
    const d = new Date(now);
    d.setMonth(d.getMonth() + 6);
    expiresAt = d.toISOString();
  }
  store.set(LICENSE_KEY, {
    key: check.key,
    type: check.type,
    activatedAt: now.toISOString(),
    expiresAt,
  });
  const state = getLicenseState();
  publishLicenseState(state);
  console.log('[license] Pro activated:', check.type, expiresAt || 'lifetime');
  return { success: true, state };
}

function recordVideosDownloaded(n) {
  const count = Math.max(0, Number(n) || 0);
  if (!count) return getLicenseState();
  const usage = getDailyUsage();
  usage.count = (usage.count || 0) + count;
  store.set(DAILY_USAGE_KEY, usage);
  const state = getLicenseState();
  safeSend('daily-usage-updated', state);
  if (!state.isPro && usage.count >= DAILY_LIMIT) {
    safeSend('daily-limit-reached', state);
  }
  return state;
}

// Jobs reserved while they are queued/running. Without this, six parallel
// drag-downloads could all pass the 10/day gate before any of them finishes
// and the counter catches up.
let reservedVideoCount = 0;

function reserveVideos(n) {
  reservedVideoCount += Math.max(0, Number(n) || 0);
}
function releaseVideos(n) {
  reservedVideoCount = Math.max(0, reservedVideoCount - Math.max(0, Number(n) || 0));
}
function releaseJobReservation(job) {
  const n = Number(job?.reservedCount) || 0;
  if (n > 0) {
    releaseVideos(n);
    job.reservedCount = 0;
  }
}

function canQueueDownloads(n) {
  const state = getLicenseState();
  if (state.isPro) return { ok: true, state };
  const requested = Math.max(1, Number(n) || 1);
  if (state.dailyCount + reservedVideoCount + requested > DAILY_LIMIT) {
    safeSend('daily-limit-reached', state);
    return {
      ok: false,
      state,
      error: `Daily limit reached (${state.dailyCount}/${DAILY_LIMIT} videos today). Enter a Pro key to continue.`,
    };
  }
  return { ok: true, state };
}

let networkCheckInterval = null;
let wasOnline = true;

// ---------------------------------------------------------------------------
// Cross-platform yt-dlp binary resolution
// ---------------------------------------------------------------------------

function getBinaryName() {
  switch (process.platform) {
    case 'win32': return 'yt-dlp.exe';
    case 'darwin': return 'yt-dlp_macos';
    case 'linux': return 'yt-dlp_linux';
    default: return 'yt-dlp_linux'; // best guess
  }
}

function getBundledBinaryPath() {
  if (app.isPackaged) {
    return path.join(process.resourcesPath, 'bin', getBinaryName());
  }
  // The repo keeps one Linux build per CPU (electron-builder installs the
  // right one as plain `yt-dlp_linux` at package time); in dev pick it here.
  const devName = process.platform === 'linux'
    ? `yt-dlp_linux_${process.arch === 'arm64' ? 'arm64' : 'x64'}`
    : getBinaryName();
  return path.join(app.getAppPath(), 'bin', devName);
}

function getWritableBinaryPath() {
  if (!app.isPackaged) return getBundledBinaryPath(); // dev mode — bin/ is already writable
  return path.join(app.getPath('userData'), 'bin', getBinaryName());
}

function ensureYtDlpBinary() {
  const writable = getWritableBinaryPath();
  const bundled = getBundledBinaryPath();

  if (!app.isPackaged) {
    if (!fs.existsSync(writable)) {
      console.log('[ytdlp] binary missing in dev — it will be downloaded automatically on startup:', writable);
      return writable;
    }
  } else {
    const dir = path.dirname(writable);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    if (!fs.existsSync(writable)) {
      if (fs.existsSync(bundled)) {
        fs.copyFileSync(bundled, writable);
        console.log('Copied yt-dlp binary to writable location:', writable);
      } else {
        console.log('[ytdlp] bundled binary missing — it will be downloaded automatically on startup');
      }
    }
  }

  if (process.platform !== 'win32' && fs.existsSync(writable)) {
    try {
      fs.chmodSync(writable, '755');
    } catch (err) {
      console.error('Failed to chmod yt-dlp binary:', err);
    }
  }

  console.log('Using yt-dlp binary at:', writable);
  return writable;
}

const ytDlpBinaryPath = ensureYtDlpBinary();

/** Safe send — guard against destroyed window (e.g. app quit during async callback) */
function safeSend(channel, data) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send(channel, data);
  }
}

/** Publish engine state to the renderer and persist it for the next launch. */
function publishYtDlpState(patch = {}) {
  ytDlpEngine = { ...ytDlpEngine, ...patch };
  const busy = ['checking', 'downloading', 'installing'].includes(ytDlpEngine.phase);
  ytDlpPhase = busy
    ? (ytDlpEngine.phase === 'installing' ? 'downloading' : ytDlpEngine.phase)
    : null;
  try {
    store.set(YTDLP_ENGINE_KEY, ytDlpEngine);
  } catch (err) {
    console.error('[ytdlp] could not save engine state:', err);
  }

  safeSend('ytdlp-engine-status', ytDlpEngine);

  // Keep the original channel alive for the loading screen / pending-fetch
  // logic, which only understands these five legacy statuses.
  let legacy = ytDlpEngine.phase;
  if (legacy === 'installing') legacy = 'downloading';
  if (!['checking', 'downloading', 'updated', 'up-to-date', 'error'].includes(legacy)) {
    legacy = 'up-to-date';
  }
  safeSend('ytdlp-update-status', {
    status: legacy,
    version: ytDlpEngine.version,
    previousVersion: ytDlpEngine.previousVersion,
    message: ytDlpEngine.message,
  });
}

/** Read the version string from the bundled binary (null if it is missing). */
function getYtDlpVersion() {
  return new Promise((resolve) => {
    if (!fs.existsSync(ytDlpBinaryPath)) { resolve(null); return; }
    let out = '';
    let settled = false;
    const finish = (v) => { if (!settled) { settled = true; resolve(v); } };
    let proc;
    try {
      proc = spawn(ytDlpBinaryPath, ['--version'], { env: getYtDlpEnv(), windowsHide: true });
    } catch {
      finish(null);
      return;
    }
    proc.stdout?.on('data', (c) => { out += c.toString(); });
    proc.on('error', () => finish(null));
    proc.on('close', (code) => finish(code === 0 ? (out.trim().split(/\s+/)[0] || null) : null));
  });
}

function ytDlpDownloadUrl() {
  const base = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/';
  if (process.platform === 'win32') return base + 'yt-dlp.exe';
  if (process.platform === 'darwin') return base + 'yt-dlp_macos';
  return base + (process.arch === 'arm64' ? 'yt-dlp_linux_aarch64' : 'yt-dlp_linux');
}

/**
 * Download a fresh standalone yt-dlp into the writable bin directory.
 * Used when the binary is missing (or the user presses "Re-download engine"),
 * so the app repairs itself without a reinstall. Every phase is shown in GUI.
 */
async function downloadYtDlpBinary() {
  publishYtDlpState({
    phase: 'installing',
    message: 'Downloading yt-dlp from GitHub…',
    lastChecked: new Date().toISOString(),
  });
  const res = await net.fetch(ytDlpDownloadUrl(), {
    redirect: 'follow',
    credentials: 'omit',
    signal: AbortSignal.timeout(120000),
  });
  if (!res.ok) throw new Error(`Download failed (HTTP ${res.status})`);
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length < 100000) throw new Error('Downloaded file is too small to be yt-dlp');

  fs.mkdirSync(path.dirname(ytDlpBinaryPath), { recursive: true });
  const tmp = ytDlpBinaryPath + '.download';
  fs.writeFileSync(tmp, buf);
  try { fs.rmSync(ytDlpBinaryPath, { force: true }); } catch { /* first install */ }
  fs.renameSync(tmp, ytDlpBinaryPath);
  if (process.platform !== 'win32') {
    try { fs.chmodSync(ytDlpBinaryPath, '755'); }
    catch (err) { console.error('[ytdlp] chmod failed:', err); }
  }
  if (process.platform === 'darwin') {
    execFile('xattr', ['-dr', 'com.apple.quarantine', ytDlpBinaryPath], () => {});
  }

  const version = await getYtDlpVersion();
  const now = new Date().toISOString();
  publishYtDlpState({
    phase: 'updated',
    version,
    previousVersion: null,
    lastChecked: now,
    lastUpdated: now,
    message: version ? `yt-dlp ${version} downloaded and ready` : 'yt-dlp downloaded and ready',
  });
  return version;
}

/** Run `yt-dlp -U` and resolve with its output (never rejects). */
function runYtDlpSelfUpdate() {
  return new Promise((resolve) => {
    let stdoutAll = '';
    let stderrAll = '';
    let downloadingSignalled = false;
    let proc;
    try {
      proc = spawn(ytDlpBinaryPath, ['-U'], { env: getYtDlpEnv(), windowsHide: true });
    } catch (err) {
      resolve({ code: -1, stdoutAll, stderrAll: err.message });
      return;
    }
    proc.stdout?.on('data', (chunk) => {
      const t = chunk.toString();
      stdoutAll += t;
      if (!downloadingSignalled && (t.includes('Updating yt-dlp') || t.includes('Downloading'))) {
        downloadingSignalled = true;
        publishYtDlpState({ phase: 'downloading', message: 'Installing the latest yt-dlp…' });
      }
      console.log('yt-dlp update stdout:', t.trim());
    });
    proc.stderr?.on('data', (chunk) => { stderrAll += chunk.toString(); });
    proc.on('error', (err) => resolve({ code: -1, stdoutAll, stderrAll: err.message }));
    proc.on('close', (code) => resolve({ code, stdoutAll, stderrAll }));
  });
}

/**
 * Auto-download / auto-update yt-dlp. Runs on launch, every 6 hours while the
 * app is open, and when the user clicks "Check for updates" in Settings.
 * Every phase is published to the GUI, including the version before/after.
 */
async function updateYtDlp() {
  if (ytDlpUpdateRunning) return ytDlpEngine;
  if (activeJobs.size > 0) {
    console.log('Skipping yt-dlp update — download in progress');
    publishYtDlpState({ phase: 'postponed', message: 'Update postponed — a video download is running' });
    return ytDlpEngine;
  }

  ytDlpUpdateRunning = true;
  isUpdatingYtDlp = true;
  publishYtDlpState({
    phase: 'checking',
    message: 'Checking for yt-dlp updates…',
    lastChecked: new Date().toISOString(),
  });

  try {
    if (!fs.existsSync(ytDlpBinaryPath)) {
      await downloadYtDlpBinary();
      return ytDlpEngine;
    }

    const before = await getYtDlpVersion();
    publishYtDlpState({ version: before, previousVersion: before });

    const { code, stdoutAll, stderrAll } = await runYtDlpSelfUpdate();
    if (code !== 0) throw new Error(stderrAll.trim() || `yt-dlp -U exited with ${code}`);

    const after = await getYtDlpVersion();
    const saidUpdated = stdoutAll.includes('Updated yt-dlp') || stdoutAll.includes('Successfully updated');
    const updated = saidUpdated || (!!before && !!after && before !== after);
    const now = new Date().toISOString();

    if (process.platform !== 'win32') {
      try { fs.chmodSync(ytDlpBinaryPath, '755'); } catch { /* non-fatal */ }
    }
    if (process.platform === 'darwin') {
      execFile('xattr', ['-dr', 'com.apple.quarantine', ytDlpBinaryPath], () => {});
    }

    publishYtDlpState({
      phase: updated ? 'updated' : 'up-to-date',
      version: after || before,
      previousVersion: before,
      lastChecked: now,
      lastUpdated: updated ? now : ytDlpEngine.lastUpdated,
      message: updated
        ? (before && after ? `Updated yt-dlp ${before} → ${after}` : 'yt-dlp updated to the latest version')
        : 'yt-dlp is already up to date',
    });
    if (stdoutAll) console.log('yt-dlp update:', stdoutAll.trim());
    if (stderrAll) console.log('yt-dlp update stderr:', stderrAll.trim());
    return ytDlpEngine;
  } catch (err) {
    console.error('[ytdlp] update failed (non-critical):', err.message);
    publishYtDlpState({ phase: 'error', message: err.message || 'yt-dlp update failed' });
    return ytDlpEngine;
  } finally {
    ytDlpUpdateRunning = false;
    isUpdatingYtDlp = false;
    ytDlpPhase = null;
    processQueue();
  }
}

/** Manual "Re-download engine" button: always fetch a fresh binary. */
async function forceDownloadYtDlp() {
  if (ytDlpUpdateRunning) return ytDlpEngine;
  if (activeJobs.size > 0) {
    publishYtDlpState({ phase: 'postponed', message: 'Re-download postponed — a video download is running' });
    return ytDlpEngine;
  }
  ytDlpUpdateRunning = true;
  isUpdatingYtDlp = true;
  try {
    await downloadYtDlpBinary();
  } catch (err) {
    console.error('[ytdlp] download failed:', err.message);
    publishYtDlpState({ phase: 'error', message: err.message || 'yt-dlp download failed' });
  } finally {
    ytDlpUpdateRunning = false;
    isUpdatingYtDlp = false;
    ytDlpPhase = null;
    processQueue();
  }
  return ytDlpEngine;
}

ipcMain.handle('get-ytdlp-status', () => ytDlpPhase);
ipcMain.handle('get-yt-dlp-engine', () => ytDlpEngine);
ipcMain.handle('check-yt-dlp-update', () => updateYtDlp());
ipcMain.handle('download-yt-dlp', () => forceDownloadYtDlp());

// ---------------------------------------------------------------------------
// Appearance (system / light / dark)
//
// The *preference* is what we persist; the *resolved* theme is what the UI
// paints. They only differ under 'system', where the OS decides — and keeps
// deciding, so we forward nativeTheme changes to the renderer.
//
// The preload reads the state synchronously before the renderer's first paint,
// which together with the matching window backgroundColor keeps startup
// flash-free.
// ---------------------------------------------------------------------------
const THEME_KEY = 'appearance';
const THEME_PREFERENCES = ['system', 'light', 'dark', 'forest'];
// Window backgroundColor per resolved theme. Must match the palette's
// --background, otherwise the first frame flashes before CSS is applied.
const WINDOW_BG = { dark: '#0a0a0a', light: '#f9f9f9', forest: '#12160c' };
// nativeTheme only understands light/dark/system; forest is a dark palette.
const nativeThemeSource = (preference) => (preference === 'forest' ? 'dark' : preference);

const getThemePreference = () => {
  const stored = store.get(THEME_KEY);
  return THEME_PREFERENCES.includes(stored) ? stored : 'system';
};

const getAppearance = () => {
  const preference = getThemePreference();
  const resolved = preference === 'system'
    ? (nativeTheme.shouldUseDarkColors ? 'dark' : 'light')
    : preference;
  return { preference, resolved };
};

const applyWindowBackground = (resolved) => {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.setBackgroundColor(WINDOW_BG[resolved]);
  }
};

ipcMain.on('get-appearance-sync', (event) => { event.returnValue = getAppearance(); });
ipcMain.handle('get-appearance', () => getAppearance());
ipcMain.handle('set-appearance', (event, preference) => {
  const next = THEME_PREFERENCES.includes(preference) ? preference : 'system';
  store.set(THEME_KEY, next);
  nativeTheme.themeSource = nativeThemeSource(next);
  const appearance = getAppearance();
  applyWindowBackground(appearance.resolved);
  return appearance;
});

// OS switched between light and dark — only meaningful while following it.
nativeTheme.on('updated', () => {
  const appearance = getAppearance();
  applyWindowBackground(appearance.resolved);
  safeSend('appearance-changed', appearance);
});

const BROWSE_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

/** Only YouTube video / playlist links get the context-menu download item. */
function cleanBrowseVideoUrl(raw) {
  if (!raw || !isYouTubeUrl(raw)) return null;
  try {
    const u = new URL(raw);
    const host = u.hostname.toLowerCase().replace(/^www\./, '');
    let videoId = null;
    if (host === 'youtu.be' || host.endsWith('.youtu.be')) {
      videoId = u.pathname.split('/').filter(Boolean)[0] || null;
    } else {
      const v = u.searchParams.get('v');
      if (v) videoId = v;
      else {
        const m = u.pathname.match(/^\/(?:shorts|live|embed|v)\/([^/?#]+)/);
        if (m) videoId = m[1];
      }
    }
    if (videoId) {
      // Strip &list=RD… / &start_radio=1 etc. so ONE song downloads, not a mix.
      const clean = new URL(`https://www.youtube.com/watch?v=${encodeURIComponent(videoId)}`);
      const t = u.searchParams.get('t');
      if (t) clean.searchParams.set('t', t);
      return clean.toString();
    }
    if (u.searchParams.get('list') && !u.searchParams.get('v')) {
      // Real /playlist?list=… link — still allowed (expands into separate jobs).
      return `https://www.youtube.com/playlist?list=${encodeURIComponent(u.searchParams.get('list'))}`;
    }
    return null;
  } catch (e) {
    return null;
  }
}

const BROWSE_NAV_CSS = `
  #uk-browse-nav {
    position: fixed; left: 14px; bottom: 14px; z-index: 2147483647;
    display: flex; align-items: center; gap: 4px;
    padding: 5px; border-radius: 10px;
    background: rgba(24,24,27,.96); color: #fff;
    box-shadow: 0 2px 8px rgba(0,0,0,.35);
    font: 600 12px/1 system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
  }
  .uk-browse-nav-btn {
    appearance: none; border: 1px solid rgba(255,255,255,.18);
    background: rgba(255,255,255,.08); color: #fff;
    min-width: 30px; height: 28px; padding: 0 9px;
    border-radius: 7px; cursor: pointer; font: inherit; white-space: nowrap;
  }
  .uk-browse-nav-btn:hover:not(:disabled) { background: rgba(255,255,255,.2); }
  .uk-browse-nav-btn:disabled { opacity: .38; cursor: default; }
  .uk-browse-nav-btn[data-act="back"] { background: rgba(59,130,246,.35); border-color: rgba(59,130,246,.6); }
  @media (prefers-color-scheme: light) {
    #uk-browse-nav { background: rgba(255,255,255,.97); color: #111; box-shadow: 0 2px 8px rgba(0,0,0,.2); }
    .uk-browse-nav-btn { background: rgba(0,0,0,.06); color: #111; border-color: rgba(0,0,0,.15); }
    .uk-browse-nav-btn:hover:not(:disabled) { background: rgba(0,0,0,.12); }
    .uk-browse-nav-btn[data-act="back"] { background: rgba(59,130,246,.18); border-color: rgba(59,130,246,.5); }
  }
`;

function browseNavState(wc) {
  const nav = wc.navigationHistory;
  return {
    canGoBack: !!(nav && nav.canGoBack && nav.canGoBack()),
    canGoForward: !!(nav && nav.canGoForward && nav.canGoForward()),
    url: wc.getURL(),
  };
}

function sendBrowseNavState(wc) {
  try { wc.send('browse:nav-updated', browseNavState(wc)); } catch (e) { /* window gone */ }
}

/** Attach nav toolbar CSS + live state to any YouTube webContents (incl. popups). */
function attachBrowseNav(wc) {
  const refresh = () => {
    if (!isYouTubeUrl(wc.getURL())) return;
    captureBrowseKeyword(wc.getURL());
    wc.insertCSS(BROWSE_NAV_CSS).catch(() => {});
    sendBrowseNavState(wc);
  };
  wc.on('did-finish-load', refresh);
  wc.on('did-navigate', refresh);
  wc.on('did-navigate-in-page', refresh);
}

// Covers YouTube windows opened via window.open (they inherit the same preload).
app.on('web-contents-created', (event, wc) => attachBrowseNav(wc));

/** Open / focus the second GUI: a real Electron window showing YouTube. */
function createBrowseWindow() {
  if (browseWindow && !browseWindow.isDestroyed()) {
    browseWindow.focus();
    return { success: true, alreadyOpen: true };
  }
  const { resolved } = getAppearance();
  const preload = path.join(__dirname, 'browse-preload.js');
  browseKeyword = '';
  browseContextUrl = null;

  browseWindow = new BrowserWindow({
    width: 1100,
    height: 760,
    minWidth: 880,
    minHeight: 600,
    resizable: true,
    title: 'UK Downloader — Browse YouTube',
    autoHideMenuBar: true,
    backgroundColor: WINDOW_BG[resolved],
    webPreferences: {
      preload,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  browseWindow.setMenu(null);
  browseWindow.webContents.setUserAgent(BROWSE_USER_AGENT);
  attachBrowseNav(browseWindow.webContents);

  // Keep YouTube navigation inside this window; everything else goes to the
  // user's real browser. New windows inherit the same locked-down preload.
  browseWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (isYouTubeUrl(url)) {
      return {
        action: 'allow',
        overrideBrowserWindowOptions: {
          webPreferences: { preload, contextIsolation: true, nodeIntegration: false, sandbox: true },
        },
      };
    }
    shell.openExternal(url);
    return { action: 'deny' };
  });
  browseWindow.webContents.on('will-navigate', (event, target) => {
    if (!isYouTubeUrl(target)) {
      event.preventDefault();
      shell.openExternal(target);
    }
  });

  // Native right-click menu on YouTube links.
  browseWindow.webContents.on('context-menu', (event, params) => {
    const candidates = [
      browseContextUrl,
      params.linkURL,
      params.pageURL,
      params.frameURL,
      params.srcURL,
    ].filter(Boolean);
    let target = null;
    for (const c of candidates) {
      const cleaned = cleanBrowseVideoUrl(c);
      if (cleaned) { target = cleaned; break; }
    }
    browseContextUrl = null;
    if (!target) return;
    const menu = Menu.buildFromTemplate([
      {
        label: 'Download',
        click: () => {
          // Reuse the renderer's proven directDownloadUrls() path: global
          // quality/MP3, song-link cleaning, 10/day + Pro, preparing row, etc.
          safeSend('browse-download-url', {
            url: target,
            keyword: currentBrowseKeyword(),
          });
          if (mainWindow && !mainWindow.isDestroyed()) mainWindow.focus();
        },
      },
      { type: 'separator' },
      { label: 'Copy link', click: () => clipboard.writeText(target) },
    ]);
    menu.popup({ window: browseWindow });
  });

  // YouTube home opens with the search box focused ("youtube_search" choice).
  browseWindow.webContents.on('did-finish-load', () => {
    browseWindow.webContents.executeJavaScript(`
      (function () {
        try {
          var i = document.querySelector('input#search, input[name="search_query"], input[aria-label*="Search"], input[placeholder*="Search"]');
          if (i) { i.focus(); if (i.select) i.select(); }
        } catch (e) {}
      })();
    `).catch(() => {});
  });

  browseWindow.on('closed', () => { browseWindow = null; browseKeyword = ''; });
  browseWindow.loadURL('https://www.youtube.com/').catch(() => {});
  return { success: true };
}

ipcMain.on('browse:context-url', (event, url) => {
  if (typeof url === 'string') browseContextUrl = url;
});
ipcMain.on('browse:search-query', (event, payload) => {
  const raw = typeof payload === 'string' ? payload : payload && payload.query;
  const q = safeKeyword(raw || '');
  if (q) browseKeyword = q;
});
ipcMain.handle('browse:open', () => createBrowseWindow());

ipcMain.handle('browse:nav-state', (event) => browseNavState(event.sender));
ipcMain.handle('browse:back', (event) => {
  const nav = event.sender.navigationHistory;
  if (!nav || !nav.canGoBack()) return { success: false };
  nav.goBack();
  return { success: true };
});
ipcMain.handle('browse:forward', (event) => {
  const nav = event.sender.navigationHistory;
  if (!nav || !nav.canGoForward()) return { success: false };
  nav.goForward();
  return { success: true };
});
ipcMain.handle('browse:home', async (event) => {
  await event.sender.loadURL('https://www.youtube.com/').catch(() => {});
  return { success: true };
});
ipcMain.handle('browse:reload', (event) => {
  event.sender.reload();
  return { success: true };
});

function createWindow() {
  nativeTheme.themeSource = nativeThemeSource(getThemePreference());
  const { resolved } = getAppearance();

  mainWindow = new BrowserWindow({
    width: 800,
    height: 700,
    minWidth: 720,
    minHeight: 560,
    resizable: true,
    title: 'UK Downloader',
    autoHideMenuBar: true,
    backgroundColor: WINDOW_BG[resolved],
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.setMenu(null);
  // The renderer is local UI. Nothing it shows may ever navigate this
  // privileged window anywhere else — not to a remote page, and not to a
  // local file dropped onto the window (Chromium's default drop action is a
  // navigation) — nor open a second window. Outbound links go through
  // 'open-external-link' to the system browser instead. Only the renderer's
  // own URL is allowed, which keeps reloads working.
  const indexHtml = path.join(__dirname, '../dist/index.html');
  const rendererUrl = app.isPackaged ? pathToFileURL(indexHtml).href : 'http://localhost:5173';
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  mainWindow.webContents.on('will-navigate', (event, target) => {
    if (!target.startsWith(rendererUrl)) event.preventDefault();
  });

  // The offscreen PO-token window is an implementation detail of this one:
  // it must never be the last window standing, or window-all-closed would
  // wait on its idle timer and the app would linger invisibly after close.
  mainWindow.on('closed', () => {
    destroyPotWindow();
    if (browseWindow && !browseWindow.isDestroyed()) browseWindow.close();
  });

  if (!app.isPackaged) {
    mainWindow.loadURL(rendererUrl);
  } else {
    mainWindow.loadFile(indexHtml);
  }
}

// ---------------------------------------------------------------------------
// Network monitoring — auto-pause/resume downloads on connectivity changes
// ---------------------------------------------------------------------------
function startNetworkMonitoring() {
  if (networkCheckInterval) return;
  wasOnline = net.isOnline();
  networkCheckInterval = setInterval(() => {
    const online = net.isOnline();
    if (online === wasOnline) return;
    wasOnline = online;
    for (const ctl of jobControls.values()) {
      if (!online && !ctl.isPaused) {
        // Lost connectivity — auto-pause to prevent yt-dlp from burning retries
        ctl.pause('network');
      } else if (online && ctl.isPaused && ctl.pauseReason === 'network') {
        // Back online — auto-resume only network-paused downloads (respect user pauses)
        ctl.resume();
      }
    }
  }, 3000);
}

ipcMain.handle('get-app-version', () => app.getVersion());
ipcMain.handle('get-license-state', () => getLicenseState());
ipcMain.handle('redeem-license-key', (event, key) => redeemLicenseKey(key));


// --- ukdownloader:// custom protocol (NO local server) ---------------------
if (!app.isDefaultProtocolClient('ukdownloader')) {
  try { app.setAsDefaultProtocolClient('ukdownloader'); } catch (e) { /* dev build */ }
}

function handleUkDownloaderUrl(raw) {
  try {
    const u = new URL(raw);
    if (u.hostname !== 'download') return { success: false, error: 'Unknown protocol action.' };
    const fileUrl = u.searchParams.get('u') || u.searchParams.get('url');
    const name = u.searchParams.get('n') || u.searchParams.get('name') || '';
    if (!fileUrl) return { success: false, error: 'No download URL in request.' };
    if (mainWindow && !mainWindow.isDestroyed()) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.show(); mainWindow.focus();
    } else {
      createWindow();
    }
    return enqueueGenericFileDownload(fileUrl, name, 'extension');
  } catch (e) {
    return { success: false, error: e.message || 'Bad protocol URL.' };
  }
}

const gotSingleInstanceLock = app.requestSingleInstanceLock();
if (!gotSingleInstanceLock) {
  app.quit();
} else {
  app.on('second-instance', (event, argv) => {
    const raw = argv.find(a => String(a).startsWith('ukdownloader://'));
    if (raw) handleUkDownloaderUrl(raw);
    if (mainWindow && !mainWindow.isDestroyed()) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}
app.on('open-url', (event, raw) => { event.preventDefault(); handleUkDownloaderUrl(raw); });

app.whenReady().then(() => {
  createWindow();
  restoreResumeQueue();
  // Restored jobs are protected; anything else is an orphan from a cut download.
  sweepOrphanWorkDirs();
  startNetworkMonitoring();
  // Start yt-dlp update check AFTER the renderer finishes loading so the
  // 'checking' IPC event is never sent before the listener is registered.
  mainWindow.webContents.once('did-finish-load', () => {
    // Hydrate the Settings panel and the Pro/daily-limit UI on first paint.
    safeSend('ytdlp-engine-status', ytDlpEngine);
    safeSend('license-state', getLicenseState());
    updateYtDlp();
    // Restored jobs wait until the GUI is listening, then start resuming.
    processQueue();
    // Cold start from a ukdownloader:// link (Windows/Linux argv).
    const cold = process.argv.find(a => String(a).startsWith('ukdownloader://'));
    if (cold) handleUkDownloaderUrl(cold);
    // Long-running sessions get re-checked too, not just cold starts.
    if (!ytDlpRecheckTimer) {
      ytDlpRecheckTimer = setInterval(() => {
        if (activeJobs.size === 0 && !isUpdatingYtDlp) updateYtDlp();
      }, YTDLP_RECHECK_MS);
    }
  });
});
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

// Clean up paused downloads on quit — a SIGSTOPped process can't handle SIGTERM
app.on('before-quit', () => {
  if (browseWindow && !browseWindow.isDestroyed()) browseWindow.destroy();
  destroyPotWindow();
  // Snapshot BEFORE killing yt-dlp: the scratch dirs + .part files must stay
  // on disk so the next launch can --continue from the same byte.
  saveResumeQueue();
  downloadQueue.forEach(j => { j.cancelled = true; });
  for (const ctl of jobControls.values()) {
    ctl.cancel(false, { preserveForResume: true });
  }
  if (networkCheckInterval) {
    clearInterval(networkCheckInterval);
    networkCheckInterval = null;
  }
});
app.on("activate", () => {
  // Count the main window specifically — a helper window (sign-in, PO token)
  // must not stop the dock icon from bringing the app back.
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

const formatBytes = (bytes, decimals = 2) => {
  if (!+bytes) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
};

const sizeToBytes = (value, unit) => {
  const normalizedUnit = (unit || '').toUpperCase();
  const multiplierMap = {
    B: 1,
    KB: 1024,
    KIB: 1024,
    MB: 1024 ** 2,
    MIB: 1024 ** 2,
    GB: 1024 ** 3,
    GIB: 1024 ** 3,
    TB: 1024 ** 4,
    TIB: 1024 ** 4,
  };
  const multiplier = multiplierMap[normalizedUnit] || 1;
  return Math.round(value * multiplier);
};

// ---------------------------------------------------------------------------
// History
// ---------------------------------------------------------------------------
ipcMain.handle("get-history", () => []);
ipcMain.handle("clear-history", () => { store.set('downloadHistory', []); safeSend('history-updated'); return []; });
ipcMain.handle("add-history-item", () => []);
ipcMain.handle("delete-history-item", () => []);
// Replace an existing history entry in-place (matched by timestamp).
// Kept for API compatibility; this build intentionally stores no history.
ipcMain.handle("update-history-item", () => []);

ipcMain.handle("open-file-location", (event, filePath) => {
  if (filePath && fs.existsSync(filePath)) {
    shell.showItemInFolder(filePath);
  } else {
    dialog.showErrorBox(
      "File Not Found",
      "The file could not be found at the original location. It may have been moved or deleted."
    );
  }
});

const isDirectory = (p) => {
  try { return !!p && fs.statSync(p).isDirectory(); } catch (e) { return false; }
};

// Reveal a specific file if it still exists, otherwise fall back to opening
// the containing folder (used by playlist history items).
ipcMain.handle("open-file-or-folder", (event, { filePath, fallbackDir }) => {
  if (filePath && fs.existsSync(filePath)) {
    shell.showItemInFolder(filePath);
    return { opened: 'file' };
  }
  // openPath *executes* a file, so only ever hand it a directory.
  if (isDirectory(fallbackDir)) {
    shell.openPath(fallbackDir);
    return { opened: 'folder' };
  }
  dialog.showErrorBox(
    "Not Found",
    "The file and its folder could not be found. They may have been moved or deleted."
  );
  return { opened: 'none' };
});

ipcMain.handle("file-exists", (event, filePath) => {
  try {
    return !!filePath && fs.existsSync(filePath);
  } catch (e) {
    return false;
  }
});

// Web URLs only. Several call sites hand this a page URL straight out of
// extractor output or the stored history, and shell.openExternal on a file://
// or custom-scheme URL would launch local programs.
ipcMain.handle("open-external-link", async (event, url) => {
  let parsed;
  try { parsed = new URL(String(url)); } catch (e) { parsed = null; }
  if (!parsed || (parsed.protocol !== 'https:' && parsed.protocol !== 'http:')) {
    console.warn('Refusing to open non-web URL:', String(url).slice(0, 200));
    return false;
  }
  try {
    await shell.openExternal(parsed.toString());
    return true;
  } catch (e) {
    console.error('Failed to open external link:', e.message);
    return false;
  }
});

ipcMain.on("cancel-info-fetch", () => {
  if (currentInfoFetchProcess) {
    try {
      currentInfoFetchProcess.kill('SIGTERM');
    } catch (e) {
      console.error('Failed to kill info fetch process:', e.message);
    }
    currentInfoFetchProcess = null;
  }
});

// ---------------------------------------------------------------------------
// YouTube authentication (cookies)
// ---------------------------------------------------------------------------
const COOKIES_PATH = path.join(app.getPath('userData'), 'youtube_cookies.txt');

async function extractYouTubeCookies() {
  const cookies = await session.defaultSession.cookies.get({ domain: '.youtube.com' });
  let cookieText = '# Netscape HTTP Cookie File\n';
  cookies.forEach(cookie => {
    const domain = cookie.domain;
    const includeSubDomain = domain.startsWith('.') ? 'TRUE' : 'FALSE';
    const cPath = cookie.path;
    const secure = cookie.secure ? 'TRUE' : 'FALSE';
    const expiry = cookie.expirationDate ? Math.floor(cookie.expirationDate) : 0;
    cookieText += `${domain}\t${includeSubDomain}\t${cPath}\t${secure}\t${expiry}\t${cookie.name}\t${cookie.value}\n`;
  });
  fs.writeFileSync(COOKIES_PATH, cookieText, 'utf8');
}

ipcMain.handle("login-youtube", async () => {
  return new Promise((resolve) => {
    const loginWin = new BrowserWindow({
      width: 500,
      height: 600,
      title: "Sign in to YouTube",
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true
      },
      autoHideMenuBar: true
    });

    loginWin.loadURL('https://accounts.google.com/ServiceLogin?service=youtube');

    let resolved = false;

    loginWin.webContents.on('did-navigate', async (event, url) => {
      // If we landed back on youtube, login was likely successful
      if (url.includes('youtube.com') && !url.includes('accounts.google.com') && !resolved) {
        resolved = true;
        await extractYouTubeCookies();
        loginWin.close();
        resolve(true);
      }
    });

    loginWin.on('closed', () => {
      if (!resolved) {
        resolved = true;
        resolve(false);
      }
    });
  });
});

ipcMain.handle("logout-youtube", async () => {
  // Clear just youtube cookies so we don't nuke everything else if the user uses the app for other things
  const cookies = await session.defaultSession.cookies.get({ domain: '.youtube.com' });
  for (const cookie of cookies) {
    let url = (cookie.secure ? 'https://' : 'http://') + cookie.domain.replace(/^\./, '') + cookie.path;
    await session.defaultSession.cookies.remove(url, cookie.name);
  }
  const googleCookies = await session.defaultSession.cookies.get({ domain: '.google.com' });
  for (const cookie of googleCookies) {
    let url = (cookie.secure ? 'https://' : 'http://') + cookie.domain.replace(/^\./, '') + cookie.path;
    await session.defaultSession.cookies.remove(url, cookie.name);
  }
  if (fs.existsSync(COOKIES_PATH)) {
    fs.unlinkSync(COOKIES_PATH);
  }
  return true;
});

ipcMain.handle("check-youtube-auth", async () => {
  const cookies = await session.defaultSession.cookies.get({ domain: '.youtube.com', name: 'LOGIN_INFO' });
  if (cookies.length > 0) {
    await extractYouTubeCookies();
    return true;
  }
  const sidCookies = await session.defaultSession.cookies.get({ domain: '.youtube.com', name: 'SID' });
  if (sidCookies.length > 0) {
    await extractYouTubeCookies();
    return true;
  }
  return false;
});

/**
 * True for youtube.com / youtu.be (and their subdomains) only.
 *
 * yt-dlp supports 1000+ sites and most of them need none of the YouTube
 * workarounds below. Anything YouTube-specific — the cookie jar, the
 * player-client retry, playlist URL reconstruction — is gated on this so a
 * PornHub or Dailymotion link takes the plain, generic path.
 */
function isYouTubeUrl(url) {
  try {
    const host = new URL(url).hostname.toLowerCase().replace(/^www\./, '');
    return host === 'youtube.com' || host.endsWith('.youtube.com') ||
      host === 'youtu.be' || host.endsWith('.youtu.be');
  } catch (e) {
    return false;
  }
}

/**
 * The cookie jar is scraped from an embedded *YouTube* login, so it only ever
 * belongs on YouTube requests. Handing it to unrelated extractors leaks the
 * user's Google session cookies to third-party hosts for no benefit.
 */
function getAuthArgs(url) {
  if (url !== undefined && !isYouTubeUrl(url)) return [];
  if (fs.existsSync(COOKIES_PATH)) {
    return ['--cookies', COOKIES_PATH];
  }
  return [];
}

// ---------------------------------------------------------------------------
// PO Tokens
// ---------------------------------------------------------------------------
/**
 * YouTube gates most streaming URLs behind a "Proof of Origin" token. Minting
 * one means running Google's BotGuard VM — obfuscated JS that needs a real DOM
 * — so the usual yt-dlp answer is a headless-Chrome or jsdom sidecar. We are
 * already a browser, so we run the VM in an offscreen window instead (see
 * src/potoken/) and hand the token to yt-dlp via --extractor-args.
 *
 * Without one, a client whose formats need a token yields a single 360p muxed
 * stream; with one, the full adaptive ladder comes back.
 *
 * This is deliberately only reached on the *retry* path: the clients that
 * serve most videos (tv, web_embedded) need no token at all, so minting on
 * every fetch would add a BotGuard run per video and buy nothing.
 */

// Every client that can require a GVS token. android/ios additionally gate the
// player response itself, hence the extra `.player` entries. One mint covers
// them all — they share the same content binding.
const POTOKEN_CLIENTS = ['web', 'web_safari', 'web_creator', 'web_music', 'mweb', 'tv_simply'];
const POTOKEN_PLAYER_CLIENTS = ['android', 'ios'];

// WAA's integrity token outlives this comfortably; the cap exists so a token
// minted before a network/account change doesn't linger.
const POTOKEN_TTL_MS = 60 * 60 * 1000;
const POTOKEN_IDLE_MS = 5 * 60 * 1000;
const POTOKEN_MINT_TIMEOUT_MS = 30 * 1000;

// The only hosts the offscreen window is allowed to reach through the bridge.
const POTOKEN_ALLOWED_ORIGINS = new Set(['https://jnn-pa.googleapis.com', 'https://www.youtube.com']);

let potWindow = null;
let potWindowPromise = null;
let potIdleTimer = null;
const potTokenCache = new Map(); // videoId -> { token, t }

/**
 * The offscreen window talks to Google's WAA API through here rather than
 * fetching directly, which keeps it at default security settings — no
 * disabled webSecurity, no host permissions of its own.
 */
ipcMain.handle('potoken:fetch', async (event, url, init = {}) => {
  if (!potWindow || event.sender !== potWindow.webContents) {
    return { error: 'not permitted', status: 0, statusText: '', body: '' };
  }
  let origin;
  try {
    origin = new URL(url).origin;
  } catch (e) {
    return { error: 'bad url', status: 0, statusText: '', body: '' };
  }
  if (!POTOKEN_ALLOWED_ORIGINS.has(origin)) {
    return { error: `blocked origin ${origin}`, status: 0, statusText: '', body: '' };
  }
  try {
    const res = await net.fetch(url, {
      method: init.method || 'GET',
      headers: init.headers || {},
      body: init.body,
    });
    return { status: res.status, statusText: res.statusText, body: await res.text() };
  } catch (e) {
    return { error: e.message, status: 0, statusText: '', body: '' };
  }
});

function destroyPotWindow() {
  if (potIdleTimer) { clearTimeout(potIdleTimer); potIdleTimer = null; }
  if (potWindow && !potWindow.isDestroyed()) potWindow.destroy();
  potWindow = null;
}

function schedulePotWindowTeardown() {
  if (potIdleTimer) clearTimeout(potIdleTimer);
  potIdleTimer = setTimeout(destroyPotWindow, POTOKEN_IDLE_MS);
  // A pending teardown must not hold the app open on quit.
  if (potIdleTimer.unref) potIdleTimer.unref();
}

async function getPotWindow() {
  if (potWindow && !potWindow.isDestroyed()) return potWindow;
  if (potWindowPromise) return potWindowPromise;

  const dir = path.join(__dirname, 'potoken');
  potWindowPromise = (async () => {
    const win = new BrowserWindow({
      show: false,
      webPreferences: {
        preload: path.join(dir, 'preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
        // A hidden window gets its timers throttled, and BotGuard leans on
        // them heavily enough to stall the mint.
        backgroundThrottling: false,
      },
    });
    win.on('closed', () => { potWindow = null; });
    // Publish only once the page is up: a concurrent caller that sees
    // `potWindow` set mid-load would call __mintPoToken before entry.js has
    // defined it. The IPC bridge keys off the same variable, but nothing
    // fetches until the mint starts, which is strictly after this point.
    await win.loadFile(path.join(dir, 'index.html'));
    potWindow = win;
    return win;
  })();

  try {
    return await potWindowPromise;
  } catch (err) {
    if (potWindow && !potWindow.isDestroyed()) potWindow.destroy();
    potWindow = null;
    throw err;
  } finally {
    potWindowPromise = null;
  }
}

async function mintPoToken(videoId) {
  const hit = potTokenCache.get(videoId);
  if (hit && Date.now() - hit.t < POTOKEN_TTL_MS) {
    schedulePotWindowTeardown();
    return hit.token;
  }

  const win = await getPotWindow();
  const mint = win.webContents.executeJavaScript(
    `window.__mintPoToken(${JSON.stringify(videoId)})`, true);
  const token = await Promise.race([
    mint,
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error('PO token mint timed out')), POTOKEN_MINT_TIMEOUT_MS)),
  ]);

  if (typeof token !== 'string' || !token) throw new Error('PO token mint returned nothing');
  potTokenCache.set(videoId, { token, t: Date.now() });
  schedulePotWindowTeardown();
  return token;
}

/**
 * The 11-character id YouTube binds tokens to. Anything else (a playlist page,
 * a channel URL, another site) has no video-id binding and gets no token.
 */
function youTubeVideoId(url) {
  if (!isYouTubeUrl(url)) return null;
  const id = videoKeyFromUrl(url);
  return typeof id === 'string' && /^[\w-]{11}$/.test(id) ? id : null;
}

function potTokenExtractorValue(token) {
  return [
    ...POTOKEN_CLIENTS.map(c => `${c}.gvs+${token}`),
    ...POTOKEN_PLAYER_CLIENTS.flatMap(c => [`${c}.gvs+${token}`, `${c}.player+${token}`]),
  ].join(',');
}

/**
 * Mints (or reuses) a token for `url` and returns the `po_token=` fragment for
 * --extractor-args, or null when one isn't applicable or minting failed.
 * Never throws: a missing token is a missed upgrade, not a failed download.
 */
async function getPoTokenArg(url) {
  const videoId = youTubeVideoId(url);
  if (!videoId) return null;
  try {
    return potTokenExtractorValue(await mintPoToken(videoId));
  } catch (err) {
    console.warn('PO token mint failed:', err.message);
    return null;
  }
}

// ---------------------------------------------------------------------------
// YouTube player-client retries
// ---------------------------------------------------------------------------
/**
 * Which clients to ask when the default set comes back empty or stripped.
 *
 * It is the historical `default,android` plus web_music, and it is used for
 * every retry — a stripped response, an age gate, a bot check. One list rather
 * than one per symptom, because the additions are strictly free: measured
 * identical ladders to `default,android` on normal videos, and identical to
 * web_music alone on age-gated ones (15 formats, 1608p), downloading cleanly
 * at every quality rung.
 *
 * web_music is the load-bearing entry. Since ~Aug 2026 the TV client answers
 * age-gated videos with "The page needs to be reloaded" and the plain web
 * clients are SABR-only (no URLs at all); web_music is the one client that
 * still clears the gate *and* serves downloadable URLs — given a PO token.
 *
 * mweb is deliberately absent. It also clears the gate and looks healthy in
 * `-J`, but its age-gated media URLs 403, so including it risks yt-dlp
 * choosing a dead URL for an itag another client also offers.
 */
const YT_RETRY_CLIENTS = 'default,android,web_music';

// yt-dlp failure kinds worth a second attempt with the gated client set.
const YT_RETRYABLE_KINDS = new Set(['age-blocked', 'no-formats', 'bot-check']);

/**
 * Video id -> the player_client list that produced the formats we showed.
 * A download re-extracts, so it must ask the *same* clients (with a fresh
 * token) or the age gate slams shut again between "fetch" and "download".
 */
const ytClientOverrides = new Map();
const YT_CLIENT_OVERRIDES_MAX = 500;

function rememberClientOverride(url, clients) {
  const videoId = youTubeVideoId(url);
  if (!videoId) return;
  if (ytClientOverrides.size >= YT_CLIENT_OVERRIDES_MAX) {
    ytClientOverrides.delete(ytClientOverrides.keys().next().value);
  }
  ytClientOverrides.set(videoId, clients);
}

/** `--extractor-args` value for a YouTube retry: the client list plus a PO
 *  token when one can be minted. */
async function ytExtractorArgs(url, clients) {
  const poToken = await getPoTokenArg(url);
  return poToken
    ? `youtube:player_client=${clients};po_token=${poToken}`
    : `youtube:player_client=${clients}`;
}

/** Extra yt-dlp args a download needs to see the same formats the fetch did. */
async function ytDownloadArgs(url) {
  const videoId = youTubeVideoId(url);
  const clients = videoId && ytClientOverrides.get(videoId);
  if (!clients) return [];
  return ['--extractor-args', await ytExtractorArgs(url, clients)];
}


// ---------------------------------------------------------------------------
// Error classification
// ---------------------------------------------------------------------------
/**
 * yt-dlp reports why a fetch failed, but the reasons arrive as raw stderr
 * ("ERROR: [youtube] abc123: Sorry, this content is age-restricted"). Reduce
 * that to a stable `kind` the renderer can turn into an explanation, plus a
 * cleaned-up sentence to fall back on.
 *
 * Order matters: the specific patterns have to win over the generic
 * "Video unavailable" that YouTube attaches to several of them.
 */
const YTDLP_ERROR_KINDS = [
  ['age-signin', /Sign in to confirm your age|confirm your age/i],
  ['age-blocked', /content is age.restricted|requiring account age.verification/i],
  ['bot-check', /confirm you'?re not a bot|Sign in to confirm/i],
  ['members-only', /members.only|available to this channel's members|join this channel/i],
  ['private', /Private video|This video is private/i],
  ['geo-blocked', /available in your country|blocked it in your country|geo.?restrict|available from your location|available in your location/i],
  ['upcoming', /Premieres in|This live event will begin|premiere/i],
  ['removed', /has been removed|terminated|no longer available|removed by the uploader/i],
  ['no-formats', /Requested format is not available|Only images are available|SABR|missing a URL/i],
  ['rate-limited', /HTTP Error 429|Too Many Requests|rate.?limit/i],
  ['network', /Unable to download|Connection reset|Temporary failure in name resolution|getaddrinfo|timed out|Network is unreachable|SSL|certificate/i],
  ['unsupported', /Unsupported URL|is not a valid URL|Unable to extract|Unable to recognize/i],
  ['unavailable', /Video unavailable|This video is unavailable/i],
];

function classifyYtDlpError(stderr) {
  for (const [kind, re] of YTDLP_ERROR_KINDS) {
    if (re.test(stderr)) return kind;
  }
  return 'unknown';
}

/**
 * Turn multi-line yt-dlp stderr into one sentence: take the last ERROR line
 * (earlier ones are usually per-client noise) and strip the
 * "ERROR: [extractor] id:" prefix and any "; please report this" tail.
 */
function cleanYtDlpError(stderr) {
  const lines = String(stderr || '').split('\n').map(l => l.trim()).filter(Boolean);
  const errorLines = lines.filter(l => l.startsWith('ERROR:'));
  const line = errorLines.length ? errorLines[errorLines.length - 1] : lines[lines.length - 1] || '';
  return line
    .replace(/^ERROR:\s*/, '')
    .replace(/^\[[^\]]+\]\s*/, '')
    .replace(/^[\w-]{3,24}:\s*/, '')
    .replace(/\s*[;.]?\s*(Please report this issue|You might want to use|See\s+https?:\/\/\S+).*$/i, '')
    .trim() || 'yt-dlp could not read this URL';
}

function ytDlpError(stderr) {
  const err = new Error(cleanYtDlpError(stderr));
  err.kind = classifyYtDlpError(stderr);
  err.raw = stderr;
  return err;
}

// ---------------------------------------------------------------------------
// Info fetching
// ---------------------------------------------------------------------------
async function runYtDlpJson(url, extraArgs = [], silent = false) {
  return new Promise((resolve, reject) => {
    const proc = spawn(ytDlpBinaryPath, [
      url,
      '-J',
      ...getAuthArgs(url),
      ...BASE_ARGS,
      ...extraArgs,
    ], { env: getYtDlpEnv(), windowsHide: true });
    if (!silent) currentInfoFetchProcess = proc;
    let out = '';
    let err = '';
    proc.stdout.on('data', d => { out += d.toString(); });
    proc.stderr.on('data', d => { err += d.toString(); });
    proc.on('close', code => {
      if (!silent) currentInfoFetchProcess = null;
      if (code === 0) {
        try {
          resolve(JSON.parse(out));
        } catch (parseErr) {
          reject(new Error('Failed to parse video info'));
        }
      } else {
        const errorMsg = err || `yt-dlp exited with code ${code}`;
        reject(ytDlpError(errorMsg));
      }
    });
    proc.on('error', (e) => {
      if (!silent) currentInfoFetchProcess = null;
      reject(e);
    });
  });
}

/**
 * Returns true when yt-dlp handed back a "basic" YouTube player response —
 * i.e. very few formats or only muxed (combined) streams with no adaptive
 * video-only tracks. In this case we should retry with a different player client.
 */
function isBasicPlayerResponse(formats) {
  if (!formats || formats.length < 10) return true;
  const adaptiveVideo = formats.some(f => f.vcodec && f.vcodec !== 'none' && f.acodec === 'none');
  return !adaptiveVideo;
}

/**
 * In yt-dlp's schema the string 'none' means "this stream has no video/audio".
 * A missing/null codec means "unknown", NOT absent — most non-YouTube
 * extractors leave the codec unset on progressive streams they never probed.
 * Treating unknown as absent is what made every PornHub format disappear.
 */
const codecAbsent = (c) => c === 'none';
const codecKnown = (c) => typeof c === 'string' && c !== 'none' && c !== 'unknown';

/**
 * Height above which the H.264 conversion gets an explicit slowness warning.
 *
 * Measured on an M4 with a real 8K AV1 60fps clip: AV1 decode alone runs at
 * 0.17x realtime and decode + `libx264 -preset medium -crf 18` at 0.04x —
 * roughly 25 minutes of work per minute of video. Decoding dominates, so no
 * encoder preset rescues it, and VideoToolbox refuses to encode H.264 above 4K
 * at all (`cannot create compression session: -12903`).
 *
 * This is deliberately only a warning. The conversion stays available at any
 * resolution: the progress UI reports live speed and ETA, and cancelling
 * during the convert stage offers to keep the already-downloaded original, so
 * a user who changes their mind loses nothing but time.
 */
const H264_SLOW_CONVERT_HEIGHT = 2160;

/** yt-dlp marks audio-only streams with resolution === 'audio only'. */
function isAudioOnlyFormat(f) {
  return codecAbsent(f.vcodec) || f.resolution === 'audio only';
}

/**
 * Best-effort pixel height for a format.
 *
 * YouTube always populates `height`. Other extractors may only give
 * `resolution` ('1080p' or '1920x1080') or a `format_note`/`format_id` that
 * names the rung ('1080p60', 'hd1080'), so fall through those in turn rather
 * than dropping the format.
 */
function formatHeight(f) {
  if (f.height > 0) return f.height;
  for (const s of [f.resolution, f.format_note, f.format_id]) {
    if (typeof s !== 'string') continue;
    const wxh = s.match(/^(\d+)\s*[x×]\s*(\d+)$/);
    if (wxh) return parseInt(wxh[2], 10);
    const p = s.match(/(\d{3,5})\s*p/i);
    if (p) return parseInt(p[1], 10);
  }
  return 0;
}

/** Byte size as reported by the extractor, or 0 when it didn't say. */
function reportedSize(f) {
  return f.filesize || f.filesize_approx || 0;
}

/**
 * Bitrate × duration, the same arithmetic yt-dlp uses for `filesize_approx`.
 *
 * Display only. A guess must never outrank a reported size when picking which
 * format represents a rung, or a stream that merely forgot to declare its
 * length wins on an inflated number.
 */
function estimatedSize(f, durationSec) {
  const kbps = f.tbr || ((f.vbr || 0) + (f.abr || 0));
  if (kbps > 0 && durationSec > 0) return Math.round((kbps * 1000 * durationSec) / 8);
  return 0;
}

/**
 * Build the unique quality list from a yt-dlp info dump.
 *
 * One rung per (height, fps). Where several formats share a rung we keep the
 * one the download is most likely to actually get: adaptive over muxed, then
 * H.264 over VP9 over anything else, then the largest. Codec suffixes are
 * only added to the label when the codec is actually known.
 */
function extractFormats(info) {
  const duration = info.duration || 0;
  const heightMap = {};
  const rawFormats = info.formats || [];

  rawFormats.forEach(f => {
    if (isAudioOnlyFormat(f)) return;

    const rawH = formatHeight(f);
    const rawW = f.width || 0;

    // Use the shorter dimension as the display quality (handles portrait/vertical videos)
    const displayH = (rawW > 0 && rawH > 0) ? Math.min(rawW, rawH) : rawH;

    if (!displayH) return;

    const vcodec = f.vcodec;
    const known = codecKnown(vcodec);
    const size = reportedSize(f);
    const guessedSize = size || estimatedSize(f, duration);
    const fps = f.fps || 30;
    const isAdaptive = codecAbsent(f.acodec);
    const isH264 = known && (vcodec.startsWith('avc') || vcodec.startsWith('h264'));
    const isVP9 = known && (vcodec.startsWith('vp09') || vcodec.startsWith('vp9'));
    const isAV1 = known && vcodec.startsWith('av01');

    const key = `${displayH}_${fps > 30 ? fps : 30}`;

    const codecScore = isH264 ? 2 : (isVP9 ? 1 : 0);
    const score = (isAdaptive ? 4 : 0) + codecScore;

    const cur = heightMap[key];
    const curScore = cur ? (cur.isAdaptive ? 4 : 0) + (cur.isH264 ? 2 : (cur.isVP9 ? 1 : 0)) : -1;

    if (score > curScore || (score === curScore && size > (cur?.size || 0))) {
      heightMap[key] = {
        displayHeight: displayH,   // shorter dimension — for UI label
        ytdlpHeight: rawH,         // actual yt-dlp height — for format filter
        fps, size, guessedSize, isAdaptive, isH264, isVP9, isAV1, known
      };
    }
  });

  // Sub-240p rungs are noise next to a full YouTube ladder, but on a site that
  // only offers 144p they are the whole menu — so drop them only when
  // something better survives.
  const rungs = Object.values(heightMap);
  const above240 = rungs.filter(f => f.displayHeight >= 240);

  const uniqueFormats = (above240.length > 0 ? above240 : rungs)
    .map(f => ({
      itag: `${f.ytdlpHeight}`,   // actual yt-dlp height, used in download format arg
      quality: `${f.displayHeight}p${f.fps > 30 ? f.fps : ''}${f.isVP9 ? ' (VP9)' : (f.isAV1 ? ' (AV1)' : '')}`,
      height: f.displayHeight,
      fps: f.fps > 30 ? f.fps : 30,
      size: f.guessedSize,
      sizeFormatted: f.guessedSize > 0 ? formatBytes(f.guessedSize) : 'N/A',
      // Drives the "convert to H.264" offer. An unknown codec is assumed
      // compatible — offering a needless re-encode is worse than skipping it,
      // and the download itself already prefers H.264 wherever it exists.
      isH264: f.isH264 || !f.known,
      codecKnown: f.known,
      // Not a restriction — the UI uses this to warn how long converting this
      // rung will take before the user commits to it.
      slowToConvert: f.displayHeight > H264_SLOW_CONVERT_HEIGHT,
    }))
    .sort((a, b) => (b.height - a.height) || (b.fps - a.fps));

  const audioFormat = rawFormats
    .filter(f => isAudioOnlyFormat(f) && !codecAbsent(f.acodec))
    .sort((a, b) => (b.abr || 0) - (a.abr || 0))[0];
  const audioSize = audioFormat
    ? (reportedSize(audioFormat) || estimatedSize(audioFormat, duration))
    : 0;

  // Nothing with a picture in it: SoundCloud, Bandcamp, podcast feeds. The UI
  // uses this to stay in MP3 mode instead of offering an MP4 that would come
  // out as a soundtrack in a box.
  //
  // Requires a real audio stream, so a page that yielded only storyboards or
  // no usable formats at all is reported as a failure rather than quietly
  // presented as a music track.
  const isAudioOnly = uniqueFormats.length === 0 && !!audioFormat &&
    rawFormats.every(isAudioOnlyFormat);

  return {
    formats: uniqueFormats.length > 0
      ? uniqueFormats
      : (isAudioOnly ? [] : [{ itag: 'best', quality: 'Best', height: 0, size: 0, sizeFormatted: 'N/A', isH264: true, codecKnown: false }]),
    audioSize,
    isAudioOnly,
  };
}

/**
 * Fetch a single video's info, with the YouTube player-client retry.
 *
 * The retry is YouTube-only on purpose. `--extractor-args youtube:...` means
 * nothing to the other 1000+ extractors, and "fewer than 10 formats" is normal
 * for most of them — so running it everywhere bought a second cold start per
 * fetch and nothing else.
 *
 * It also only *upgrades*. Some sites hand back a shorter list on a second
 * call (PornHub's HLS manifests expire within minutes), and blindly taking the
 * retry's answer would throw away the better one we already had.
 */
async function fetchVideoInfoWithRetry(url, silent) {
  let info;
  try {
    info = await runYtDlpJson(url, [], silent);
  } catch (err) {
    // The default clients refused outright. For a signed-in YouTube user that
    // is almost always the age gate, which only the gated client set (plus a
    // PO token) gets past. If that fails too, surface the *original* error —
    // it carries the meaningful classification.
    if (!isYouTubeUrl(url) || !YT_RETRYABLE_KINDS.has(err.kind)) throw err;
    let retried;
    try {
      retried = await runYtDlpJson(url, ['--extractor-args', await ytExtractorArgs(url, YT_RETRY_CLIENTS)], silent);
    } catch (retryErr) {
      console.warn('Retry with explicit client set failed:', retryErr.message);
      throw err;
    }
    rememberClientOverride(url, YT_RETRY_CLIENTS);
    return retried;
  }
  if (!isYouTubeUrl(url) || !isBasicPlayerResponse(info.formats)) return info;

  // A stripped response usually means the client that answered needs a PO
  // token. Mint one before retrying so the pot-gated clients are actually
  // usable; without it the retry can only shuffle between clients that are
  // equally blocked.
  try {
    const retried = await runYtDlpJson(url, ['--extractor-args', await ytExtractorArgs(url, YT_RETRY_CLIENTS)], silent);
    const before = (info.formats || []).length;
    const after = (retried.formats || []).length;
    if (after >= before) {
      rememberClientOverride(url, YT_RETRY_CLIENTS);
      return retried;
    }
    return info;
  } catch (retryErr) {
    // Retry failed — carry on with whatever we got the first time
    console.warn('Player-client retry failed, using initial result:', retryErr.message);
    return info;
  }
}

// Short-lived, in-memory only. Bouncing between the playlist prompt, the
// details view and back is common, and each miss costs a full yt-dlp launch.
const VIDEO_INFO_TTL_MS = 10 * 60 * 1000;
const VIDEO_INFO_MAX = 50;
const videoInfoCache = new Map(); // videoId (or raw url) -> { t, payload }

/**
 * Stable cache key for a watch/shorts/youtu.be URL.
 *
 * Only YouTube collapses to a bare id — other sites use `?v=` for unrelated
 * things, and keying on it would let two different sites' videos share a cache
 * entry. Everything else keys on the full URL.
 */
function videoKeyFromUrl(url) {
  if (!isYouTubeUrl(url)) return url;
  try {
    const u = new URL(url);
    const v = u.searchParams.get('v');
    if (v) return v;
    if (u.hostname.endsWith('youtu.be')) return u.pathname.slice(1) || url;
    const m = u.pathname.match(/\/shorts\/([^/?#]+)/);
    if (m) return m[1];
  } catch (e) { /* not a URL — fall through */ }
  return url;
}

ipcMain.handle("get-video-info", async (event, url) => {
  if (isUpdatingYtDlp) {
    return { success: false, error: 'yt-dlp is updating. Try again shortly.' };
  }

  const cacheKey = videoKeyFromUrl(url);
  const cached = videoInfoCache.get(cacheKey);
  if (cached && Date.now() - cached.t < VIDEO_INFO_TTL_MS) {
    console.log('Serving video info from cache:', cacheKey);
    return cached.payload;
  }

  try {
    console.log('Fetching video info for:', url);
    const info = await fetchVideoInfoWithRetry(url, false);
    const { formats, audioSize, isAudioOnly } = extractFormats(info);
    console.log('Available qualities:', isAudioOnly ? 'audio only' : formats.map(f => f.quality).join(', '));

    const payload = {
      success: true,
      videoId: info.id,
      formats,
      title: info.title,
      description: info.description || '',
      thumbnailUrl: info.thumbnail,
      duration: info.duration || 0,
      uploader: info.uploader || info.channel || '',
      audioSize,
      audioSizeFormatted: formatBytes(audioSize),
      isAudioOnly,
      // The URL the download must actually use. yt-dlp ids are only
      // round-trippable back into a URL on YouTube; everywhere else the id is
      // extractor-local ('65a46f8847bef') and rebuilding a link from it
      // produces a dead one.
      webpageUrl: info.webpage_url || info.original_url || url,
      extractor: info.extractor_key || info.extractor || '',
    };

    if (videoInfoCache.size >= VIDEO_INFO_MAX) {
      videoInfoCache.delete(videoInfoCache.keys().next().value);
    }
    videoInfoCache.set(cacheKey, { t: Date.now(), payload });
    // The playlist view can reuse the derived formats for this video for free
    if (info.id) cacheFormats(info.id, { success: true, formats, audioSize, isAudioOnly });

    return payload;
  } catch (error) {
    console.error("Error fetching video info:", error.raw || error);
    return {
      success: false,
      error: error.message,
      errorKind: error.kind || 'unknown',
      // Only the "not signed in" flavour is fixable by signing in; being
      // blocked *while* signed in must not send the user back to the login.
      isAgeRestricted: error.kind === 'age-signin',
    };
  }
});

ipcMain.handle("get-playlist-info", async (event, url) => {
  if (isUpdatingYtDlp) {
    return { success: false, error: 'yt-dlp is updating. Try again shortly.' };
  }
  try {
    // On YouTube a watch URL carrying ?list= is ambiguous, so rebuild a bare
    // playlist URL to force the playlist reading. Elsewhere `list` is just
    // another query parameter and rewriting the URL would point at the wrong
    // site entirely — pass those through untouched.
    let cleanUrl = url;
    if (isYouTubeUrl(url)) {
      try {
        const listId = new URL(url).searchParams.get('list');
        if (listId) cleanUrl = `https://www.youtube.com/playlist?list=${listId}`;
      } catch (e) {}
    }

    console.log('Fetching playlist info for:', cleanUrl);
    const info = await runYtDlpJson(cleanUrl, ['--flat-playlist', '--yes-playlist']);

    const entries = info.entries || [];
    const fromYouTube = isYouTubeUrl(cleanUrl);

    const videos = entries
      .filter(v => v.id && v.title && v.title !== '[Private video]' && v.title !== '[Deleted video]')
      .map((v, i) => {
        // Only YouTube ids round-trip into a URL. For every other extractor a
        // missing entry URL means we have nothing to download from, so drop
        // the entry rather than fabricate a youtube.com link that 404s.
        const entryUrl = v.url || v.webpage_url ||
          (fromYouTube ? `https://www.youtube.com/watch?v=${v.id}` : null);
        if (!entryUrl) return null;
        const realIndex = Number.isFinite(Number(v.playlist_index)) && Number(v.playlist_index) > 0
          ? Number(v.playlist_index)
          : (Number.isFinite(Number(v.playlist_autonumber)) && Number(v.playlist_autonumber) > 0
              ? Number(v.playlist_autonumber)
              : i + 1);
        return {
          id: v.id,
          url: entryUrl,
          title: v.title,
          playlistIndex: realIndex,
          duration: v.duration || 0,
          uploader: v.uploader || v.channel || info.uploader || info.channel || 'Unknown',
          thumbnail: v.thumbnails && v.thumbnails.length > 0
            ? v.thumbnails[v.thumbnails.length - 1].url
            : (fromYouTube ? `https://i.ytimg.com/vi/${v.id}/hqdefault.jpg` : '')
        };
      })
      .filter(Boolean);

    if (videos.length === 0) {
      return { success: false, error: 'No downloadable videos were found at that link.' };
    }

    return {
      success: true,
      title: info.title || 'Unknown Playlist',
      uploader: info.uploader || info.channel || 'Unknown',
      description: info.description || '',
      videos
    };
  } catch (error) {
    console.error('Error fetching playlist info:', error.raw || error);
    return {
      success: false,
      error: error.message,
      errorKind: error.kind || 'unknown',
      isAgeRestricted: error.kind === 'age-signin',
    };
  }
});

// ---------------------------------------------------------------------------
// Playlist format prefetching — staggered worker pool + persistent cache.
// Results are streamed back per-video via 'playlist-format-result' events so
// the UI fills in as fast as each video resolves instead of waiting in line.
//
// Sizing note: a yt-dlp launch pays several seconds of fixed, CPU-bound
// startup before it extracts anything. Those startups do NOT overlap — running
// six at once simply serialises them and pushes the FIRST result minutes out.
// One process starts immediately on the head of the list; extra ones are added
// only for long playlists, staggered so their startups don't collide.
// ---------------------------------------------------------------------------
const PREFETCH_MAX_PROCS = 3;
const PREFETCH_VIDEOS_PER_PROC = 15; // only add a worker when it has real work
const PREFETCH_STAGGER_MS = 7000;    // roughly one cold start apart

const delay = (ms) => new Promise(r => setTimeout(r, ms));

let prefetchToken = 0;
const prefetchProcs = new Set(); // live child processes, killed on cancel/restart

function killPrefetchProcs() {
  for (const proc of prefetchProcs) {
    try { proc.kill('SIGTERM'); } catch (e) { }
  }
  prefetchProcs.clear();
}

// ── Format cache ────────────────────────────────────────────────────────────
// Only derived metadata (heights, fps, codec flags, byte sizes) is stored —
// no stream URLs — so entries stay valid for a long time and survive restarts.
const FORMAT_CACHE_KEY = 'formatCacheV1';
const FORMAT_CACHE_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days
// ~800 bytes/entry, and electron-store writes synchronously on the main
// thread — 500 keeps each write well under half a megabyte.
const FORMAT_CACHE_MAX = 500;
// Longer than the gap between streamed results, so a whole playlist prefetch
// collapses into a single write instead of one per video.
const FORMAT_CACHE_SAVE_DEBOUNCE_MS = 5000;

const formatCache = new Map(); // videoId -> { success, formats, audioSize, t }

(function loadFormatCache() {
  try {
    const now = Date.now();
    for (const [id, v] of Object.entries(store.get(FORMAT_CACHE_KEY, {}) || {})) {
      if (v && v.t && Array.isArray(v.formats) && now - v.t < FORMAT_CACHE_TTL_MS) {
        formatCache.set(id, v);
      }
    }
    console.log(`Format cache: ${formatCache.size} entries restored`);
  } catch (e) {
    console.log('Format cache unreadable, starting fresh:', e.message);
  }
})();

let formatCacheSaveTimer = null;
let formatCacheDirty = false;

function flushFormatCache() {
  clearTimeout(formatCacheSaveTimer);
  formatCacheSaveTimer = null;
  if (!formatCacheDirty) return;
  formatCacheDirty = false;
  try {
    let entries = [...formatCache.entries()];
    if (entries.length > FORMAT_CACHE_MAX) {
      entries.sort((a, b) => b[1].t - a[1].t);
      entries = entries.slice(0, FORMAT_CACHE_MAX);
      formatCache.clear();
      for (const [k, v] of entries) formatCache.set(k, v);
    }
    store.set(FORMAT_CACHE_KEY, Object.fromEntries(entries));
  } catch (e) {
    // A cache write must never take the app down — worst case we re-fetch
    console.log('Failed to persist format cache (non-critical):', e.message);
  }
}

function persistFormatCache() {
  formatCacheDirty = true;
  clearTimeout(formatCacheSaveTimer);
  formatCacheSaveTimer = setTimeout(flushFormatCache, FORMAT_CACHE_SAVE_DEBOUNCE_MS);
}

// Don't lose a prefetch that finished seconds before the user quit
app.on('before-quit', flushFormatCache);

function cacheFormats(id, result) {
  formatCache.set(id, { ...result, t: Date.now() });
  persistFormatCache();
}

/** Cached entry in the shape the renderer expects (no bookkeeping fields). */
function cachedFormatResult(id) {
  const { t, ...rest } = formatCache.get(id);
  return rest;
}

/**
 * Spawn ONE yt-dlp process for a batch of video URLs. yt-dlp prints one JSON
 * line per video as it extracts (-j), so results stream in at ~2s/video after
 * a single process startup instead of paying ~5-30s of process+challenge
 * overhead per video.
 */
function streamFormatsBatch(videos, token, onRetry) {
  return new Promise((resolve) => {
    if (videos.length === 0) return resolve();
    const args = [
      ...videos.map(v => v.url),
      '-j',
      '--ignore-errors',
      // A batch always comes from one playlist, so one host — the first entry
      // decides whether the YouTube cookie jar applies to the whole run.
      ...getAuthArgs(videos[0]?.url),
      ...BASE_ARGS,
    ];
    const proc = spawn(ytDlpBinaryPath, args, { env: getYtDlpEnv(), windowsHide: true });
    prefetchProcs.add(proc);

    const received = new Set();
    let buf = '';

    proc.stdout.on('data', (chunk) => {
      buf += chunk.toString();
      const lines = buf.split('\n');
      buf = lines.pop();
      for (const line of lines) {
        if (!line.trim()) continue;
        try {
          const info = JSON.parse(line);
          const id = info.id;
          if (!id) continue;
          received.add(id);
          const { formats, audioSize, isAudioOnly } = extractFormats(info);
          const result = { success: true, formats, audioSize, isAudioOnly };
          // A stripped "basic" response is worth a targeted retry later, but
          // still send it now so the row becomes interactive immediately.
          // Only YouTube has a second player client to retry against, and only
          // YouTube ids can be turned back into a URL — everything else keeps
          // whatever the extractor gave us.
          const pageUrl = info.webpage_url || info.original_url;
          const canRetry = pageUrl ? isYouTubeUrl(pageUrl) : isYouTubeUrl(videos[0]?.url);
          if (canRetry && isBasicPlayerResponse(info.formats) && onRetry) {
            onRetry({ id, url: pageUrl || `https://www.youtube.com/watch?v=${id}`, clients: YT_RETRY_CLIENTS });
          } else {
            cacheFormats(id, result);
          }
          if (token === prefetchToken) safeSend('playlist-format-result', { id, ...result });
        } catch (e) { /* partial/non-JSON line — ignore */ }
      }
    });

    // --ignore-errors keeps the batch going past a failed video, and yt-dlp
    // names the video in each ERROR line — enough to tell an age gate (worth
    // a gated-client retry) from a private or deleted video (not).
    let errBuf = '';
    proc.stderr.on('data', (chunk) => { errBuf += chunk.toString(); });

    const finish = () => {
      prefetchProcs.delete(proc);
      const failureKinds = new Map();
      for (const line of errBuf.split('\n')) {
        const m = line.match(/^ERROR: \[[^\]]+\] ([\w-]{11}): /);
        if (m) failureKinds.set(m[1], classifyYtDlpError(line));
      }
      // Videos the process never produced output for (private, deleted, error)
      for (const v of videos) {
        if (received.has(v.id) || token !== prefetchToken) continue;
        if (onRetry && isYouTubeUrl(v.url) && YT_RETRYABLE_KINDS.has(failureKinds.get(v.id))) {
          // Hold the failure back: the retry reports success or failure itself.
          onRetry({ id: v.id, url: v.url, clients: YT_RETRY_CLIENTS, reportFailure: true });
          continue;
        }
        safeSend('playlist-format-result', { id: v.id, success: false, formats: [], audioSize: 0 });
      }
      resolve();
    };
    proc.on('close', finish);
    proc.on('error', finish);
  });
}

ipcMain.handle("prefetch-playlist-formats", async (event, videos) => {
  const token = ++prefetchToken;
  killPrefetchProcs(); // a new prefetch supersedes any previous one
  if (!Array.isArray(videos) || videos.length === 0) return { done: true };

  // Serve cached entries instantly — a revisited playlist needs no work at all
  const pending = [];
  for (const v of videos) {
    if (formatCache.has(v.id)) {
      safeSend('playlist-format-result', { id: v.id, ...cachedFormatResult(v.id) });
    } else {
      pending.push(v);
    }
  }
  if (pending.length === 0) return { done: true };

  const nProcs = Math.min(
    PREFETCH_MAX_PROCS,
    Math.max(1, Math.ceil(pending.length / PREFETCH_VIDEOS_PER_PROC))
  );

  // Contiguous split: the first process owns the head of the list, which is
  // what the user is actually looking at while the rest streams in.
  const per = Math.ceil(pending.length / nProcs);
  const batches = Array.from({ length: nProcs }, (_, i) => pending.slice(i * per, (i + 1) * per))
    .filter(b => b.length > 0);

  // Videos that returned a stripped player response, or were refused by the
  // age gate, get a targeted 2nd pass with an explicit client set.
  const retries = [];
  const onRetry = (r) => retries.push(r);

  await Promise.all(batches.map(async (batch, i) => {
    if (i > 0) {
      await delay(i * PREFETCH_STAGGER_MS);
      if (token !== prefetchToken) return;
    }
    return streamFormatsBatch(batch, token, onRetry);
  }));

  // Second pass: retry stripped responses with an explicit player client.
  // Sequential — these are extra cold starts, and parallelising them only
  // makes each one finish later.
  for (const v of retries) {
    if (token !== prefetchToken) break;
    const failed = () => {
      // A stripped result was already sent and stays; a held-back gate
      // failure is reported now that the retry has also come up empty.
      if (v.reportFailure && token === prefetchToken) {
        safeSend('playlist-format-result', { id: v.id, success: false, formats: [], audioSize: 0 });
      }
    };
    try {
      const info = await runYtDlpJson(v.url, ['--extractor-args', await ytExtractorArgs(v.url, v.clients)], true);
      const { formats, audioSize, isAudioOnly } = extractFormats(info);
      if (formats.length === 0 && !isAudioOnly) { failed(); continue; }
      rememberClientOverride(v.url, v.clients);
      const result = { success: true, formats, audioSize, isAudioOnly };
      cacheFormats(v.id, result);
      if (token === prefetchToken) safeSend('playlist-format-result', { id: v.id, ...result });
    } catch (e) { failed(); }
  }

  return { done: true };
});

ipcMain.on("cancel-playlist-prefetch", () => {
  prefetchToken++;
  killPrefetchProcs();
});

// ---------------------------------------------------------------------------
// Per-playlist download folders + the “Video settings” defaults
//
// Every playlist can point at its own folder. Keyed by the playlist URL
// (title as a fallback for links that have no canonical URL).
// ---------------------------------------------------------------------------
const PLAYLIST_DIRS_KEY = 'playlistDirsV1';
const VIDEO_SETTINGS_KEY = 'videoSettingsV1';
const RESUME_QUEUE_KEY = 'resumeQueueV1';
const AUTO_SUBSCRIBE_KEY = 'autoSubscribeDroppedPlaylistsV1';
const PLAYLIST_HUB_KEY = 'playlistHubV1';

function playlistDirKey(url, title) {
  return String(url || '').trim() || `title:${String(title || '').trim()}`;
}

ipcMain.handle('get-playlist-dir', (event, { url, title } = {}) => {
  const dirs = store.get(PLAYLIST_DIRS_KEY, {}) || {};
  return dirs[playlistDirKey(url, title)] || null;
});

ipcMain.handle('set-playlist-dir', (event, { url, title, dir } = {}) => {
  if (!dir) return { success: false, error: 'No folder given.' };
  const dirs = store.get(PLAYLIST_DIRS_KEY, {}) || {};
  dirs[playlistDirKey(url, title)] = dir;
  store.set(PLAYLIST_DIRS_KEY, dirs);
  return { success: true, dir };
});

const DEFAULT_VIDEO_SETTINGS = {
  // 'hd720' | 'hd480' | 'mp3' | 'ask' — the preselected output everywhere.
  defaultQuality: 'hd720',
  // Single videos skip the Save dialog and land here.
  directSave: true,
  directSaveDir: '',
  // How many queued jobs run at the same time AND how many DASH/HLS fragments
  // each video downloads concurrently. Presets 2/4/8/16/32, custom 1–64.
  parallel: PARALLEL_DEFAULT,
  // Typing a song/keyword instead of a link downloads this many search results.
  keywordLimit: 1,
  // OFF by default. When ON, playlist-origin files get "01 - ", "02 - " …
  // from yt-dlp's REAL playlist_index. The GUI list itself stays unnumbered.
  playlistNumbering: false,
};
const KEYWORD_LIMIT_MIN = 1;
const KEYWORD_LIMIT_MAX = 50;

function getParallelLimit() {
  const settings = { ...DEFAULT_VIDEO_SETTINGS, ...(store.get(VIDEO_SETTINGS_KEY, {}) || {}) };
  return clampParallel(settings.parallel, PARALLEL_DEFAULT);
}

/** Same global number also drives per-video DASH/HLS fragment connections. */
function getConcurrentFragments() {
  return getParallelLimit();
}

function downloadSpeedArgs() {
  return ['--concurrent-fragments', String(getConcurrentFragments())];
}

ipcMain.handle('get-video-settings', () => ({
  ...DEFAULT_VIDEO_SETTINGS,
  ...(store.get(VIDEO_SETTINGS_KEY, {}) || {}),
}));

ipcMain.handle('set-video-settings', (event, patch = {}) => {
  const current = { ...DEFAULT_VIDEO_SETTINGS, ...(store.get(VIDEO_SETTINGS_KEY, {}) || {}) };
  const next = { ...current };

  if (patch.defaultQuality !== undefined) {
    const q = String(patch.defaultQuality);
    next.defaultQuality = (q === 'ask' || q === 'mp3' || isHdQuality(q)) ? q : current.defaultQuality;
  }
  if (patch.directSave !== undefined) next.directSave = !!patch.directSave;
  if (patch.directSaveDir !== undefined) next.directSaveDir = String(patch.directSaveDir || '');
  if (patch.parallel !== undefined) {
    next.parallel = clampParallel(patch.parallel, current.parallel);
  }
  if (patch.keywordLimit !== undefined) {
    const n = Math.round(Number(patch.keywordLimit));
    next.keywordLimit = Number.isFinite(n)
      ? Math.min(KEYWORD_LIMIT_MAX, Math.max(KEYWORD_LIMIT_MIN, n))
      : current.keywordLimit;
  }
  if (patch.playlistNumbering !== undefined) next.playlistNumbering = !!patch.playlistNumbering;
  store.set(VIDEO_SETTINGS_KEY, next);
  safeSend('video-settings-updated', next);
  // Raising the limit must start waiting jobs immediately, not on the next
  // job-finished event.
  processQueue();
  return next;
});

ipcMain.handle('get-default-download-dir', () => app.getPath('downloads'));

ipcMain.handle("choose-directory", async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory', 'createDirectory']
  });
  if (result.canceled || result.filePaths.length === 0) {
    return null;
  }
  return result.filePaths[0];
});

// Ordered download candidates for a thumbnail URL. Playlist entries carry
// hqdefault (480x360, letterboxed to 4:3), so for i.ytimg.com try the clean
// 16:9 variants in descending quality, falling back until one exists (missing
// variants return a real 404). The /vi/*.jpg form is preferred so writeJpeg
// can skip the transcode. Non-YouTube URLs are used as-is.
function thumbnailCandidates(rawUrl) {
  // Some extractors emit protocol-relative URLs; the <img> tag resolves them
  // against the page, net.fetch cannot.
  if (typeof rawUrl === 'string' && rawUrl.startsWith('//')) rawUrl = 'https:' + rawUrl;
  try {
    const u = new URL(rawUrl);
    if (u.hostname === 'i.ytimg.com') {
      u.search = '';
      u.pathname = u.pathname.replace('/vi_webp/', '/vi/').replace(/\.webp$/, '.jpg');
      const m = u.pathname.match(/^\/vi\/([^/]+)\//);
      if (m) {
        const urls = ['maxresdefault.jpg', 'hq720.jpg', 'sddefault.jpg', 'hqdefault.jpg']
          .map(name => `https://i.ytimg.com/vi/${m[1]}/${name}`);
        if (!urls.includes(u.toString())) urls.push(u.toString());
        return urls;
      }
      return [u.toString()];
    }
  } catch (e) { }
  return [rawUrl];
}

/**
 * Download an image into memory.
 *
 * Goes through Electron's net stack rather than Node's https module on
 * purpose: outside YouTube, thumbnails are routinely served over plain http
 * and sit behind 30x redirects (Reddit, X and Instagram CDNs all do this).
 * https.get() throws on the http: scheme and reports a redirect as a failed
 * status, so it could only ever save YouTube's.
 */
const THUMBNAIL_TIMEOUT_MS = 20000;
const THUMBNAIL_MAX_BYTES = 20 * 1024 * 1024; // a poster frame, not a video

async function fetchImageBuffer(url, timeoutMs = THUMBNAIL_TIMEOUT_MS) {
  const res = await net.fetch(url, {
    redirect: 'follow',
    // Thumbnails are public; never attach the session's (YouTube login) cookies.
    credentials: 'omit',
    // A CDN that accepts the connection and never answers must not hang the
    // save forever, and a URL that resolves to something huge must not be
    // buffered whole in the main process.
    signal: AbortSignal.timeout(timeoutMs),
  });
  if (!res.ok) throw new Error(`Download failed. Status: ${res.status}`);
  const declared = Number(res.headers.get('content-length'));
  if (declared > THUMBNAIL_MAX_BYTES) throw new Error('Image is too large to be a thumbnail.');
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length === 0) throw new Error('Empty image response.');
  if (buf.length > THUMBNAIL_MAX_BYTES) throw new Error('Image is too large to be a thumbnail.');
  // A CDN can answer 200 with an HTML challenge or error page. Only the bytes
  // prove it is a picture — and a non-image must fail here so the caller
  // moves on to the next candidate instead of saving it as a ".jpg".
  if (!isImageBuffer(buf)) throw new Error('Response was not an image.');
  return buf;
}

const JPEG_MAGIC = Buffer.from([0xff, 0xd8, 0xff]);

/** JPEG, PNG, GIF, WebP, BMP or AVIF/HEIF by magic bytes. */
function isImageBuffer(buf) {
  if (buf.length < 12) return false;
  if (buf.subarray(0, 3).equals(JPEG_MAGIC)) return true;
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return true;
  const head = buf.subarray(0, 4).toString('latin1');
  if (head === 'GIF8' || head.startsWith('BM')) return true;
  if (head === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return true;
  if (buf.subarray(4, 8).toString('latin1') === 'ftyp') return true;
  return false;
}

/**
 * Write an image as a real JPEG. The save dialog promised a .jpg, and most
 * sites serve thumbnails as WebP or PNG, so anything that isn't JPEG already
 * is transcoded through the bundled ffmpeg. Should that fail, the original
 * bytes are kept — the caller has already verified they are an image, and a
 * mislabelled image beats no image.
 */
async function writeJpeg(buf, filePath) {
  if (buf.subarray(0, 3).equals(JPEG_MAGIC)) {
    fs.writeFileSync(filePath, buf);
    return;
  }
  const tmpIn = path.join(os.tmpdir(), `uk-downloader-thumb-${process.pid}-${Date.now()}`);
  fs.writeFileSync(tmpIn, buf);
  try {
    await new Promise((resolve, reject) => {
      execFile(ffmpegPath, [
        '-y', '-v', 'error', '-i', tmpIn,
        '-frames:v', '1', '-q:v', '2',
        // `-update 1` makes image2 write to the literal filename instead of
        // treating it as a numbered pattern.
        '-f', 'image2', '-update', '1', filePath,
      ], { windowsHide: true }, (err) => (err ? reject(err) : resolve()));
    });
  } catch (e) {
    console.warn('Thumbnail transcode failed, saving original bytes:', e.message);
    fs.writeFileSync(filePath, buf);
  } finally {
    try { fs.unlinkSync(tmpIn); } catch (e) { }
  }
}

ipcMain.handle("download-thumbnail", async (event, { url, title }) => {
  if (!url) return { success: false, error: 'No thumbnail URL.' };
  const safeTitle = safeFileStem(title, 'jpg');
  const { canceled, filePath } = await dialog.showSaveDialog(mainWindow, {
    title: 'Save Thumbnail', defaultPath: `${safeTitle}_thumbnail.jpg`,
    buttonLabel: 'Save Image', filters: [{ name: 'JPEG Image', extensions: ['jpg'] }]
  });
  if (canceled || !filePath) return { success: false, error: 'Save dialog was canceled.' };
  // Fetch inside the loop, write once after it: a disk error on the chosen
  // path is not a bad candidate and must not trigger four more downloads.
  let buf = null;
  let lastError = 'Download failed.';
  for (const candidate of thumbnailCandidates(url)) {
    try {
      buf = await fetchImageBuffer(candidate);
      break;
    } catch (e) {
      lastError = e.message;
    }
  }
  if (!buf) return { success: false, error: lastError };
  try {
    await writeJpeg(buf, filePath);
    return { success: true, path: filePath };
  } catch (e) {
    // Don't leave a half-written file behind a failed save.
    try { fs.unlinkSync(filePath); } catch (e2) { }
    return { success: false, error: e.message };
  }
});

/**
 * `--output` is a *template*, not a literal path: yt-dlp expands `%(title)s`
 * and friends inside it. A destination the user picked can legitimately
 * contain a percent sign, so escape it as `%%` or the download dies with
 * "invalid field" on a filename the save dialog itself produced.
 */
function outputTemplate(filePath) {
  return filePath.replace(/%/g, '%%');
}

/**
 * A private scratch directory for one download, created next to the
 * destination file.
 *
 * yt-dlp writes every intermediate straight into the output directory — the
 * separate video and audio streams (`Title.f399.mp4`), each in-flight fragment
 * (`.part-Frag12`), and the pre-merge container. With
 * `--concurrent-fragments` that is a handful of files materialising and
 * vanishing in the user's Downloads folder for the whole download, which looks
 * exactly like the app is thrashing.
 *
 * It has to sit on the SAME volume as the destination: yt-dlp finishes with a
 * `[MoveFiles]` step, which is an instant rename within a volume but a full
 * byte copy across one — and on an external drive that would silently double
 * both the time and the peak disk usage. A dot prefix keeps it out of Finder.
 */
/** Windows ignores a leading dot; set the real Hidden attribute too. */
function hideWorkDir(workDir) {
  if (!workDir || process.platform !== 'win32') return;
  try {
    execFileSync('attrib', ['+H', workDir], { windowsHide: true, stdio: 'ignore' });
  } catch (e) {
    console.warn('Could not mark work dir hidden:', workDir, e.message);
  }
}

/**
 * A private scratch directory for one download, created next to the
 * destination file. On resume the SAME directory is reused so yt-dlp's
 * --continue can find the .part / fragment files left by the previous run.
 */
function createWorkDir(filePath, label = 'job', existing = null) {
  if (existing) {
    try {
      fs.mkdirSync(existing, { recursive: true });
      hideWorkDir(existing);
      return existing;
    } catch (e) {
      console.warn('Resume work dir unavailable, starting fresh:', e.message);
    }
  }
  const workDir = path.join(path.dirname(filePath), `.uk-downloader-${label}-${Date.now()}`);
  try {
    fs.mkdirSync(workDir, { recursive: true });
    hideWorkDir(workDir);
    return workDir;
  } catch (e) {
    // Read-only or otherwise hostile destination — fall back to the system
    // temp dir and accept the possible cross-volume copy.
    try {
      const fallback = fs.mkdtempSync(path.join(os.tmpdir(), 'uk-downloader-'));
      hideWorkDir(fallback);
      console.warn('Falling back to system temp dir for intermediates:', e.message);
      return fallback;
    } catch (e2) {
      console.error('No usable temp directory, downloading in place:', e2.message);
      return null;
    }
  }
}

/** Best-effort removal of a work directory and anything left inside it. */
function removeWorkDir(workDir) {
  if (!workDir) return;
  try {
    fs.rmSync(workDir, { recursive: true, force: true });
  } catch (e) {
    console.error('Failed to remove work dir:', workDir, e.message);
  }
}

/** Places where an interrupted download may have left a scratch folder. */
function cleanupScanRoots() {
  const roots = [];
  const addRoot = (dir, extra = {}) => {
    const p = String(dir || '').trim();
    if (!p) return;
    roots.push({ dir: p, maxDepth: 3, ...extra });
  };
  try {
    const settings = { ...DEFAULT_VIDEO_SETTINGS, ...(store.get(VIDEO_SETTINGS_KEY, {}) || {}) };
    addRoot(settings.directSaveDir);
    addRoot(app.getPath('downloads'));
    const playlistDirs = store.get(PLAYLIST_DIRS_KEY, {}) || {};
    for (const dir of Object.values(playlistDirs)) addRoot(dir);
    for (const sub of getSubscriptions()) {
      addRoot(sub.folderPath);
      addRoot(sub.targetDir);
    }
    addRoot(store.get('lastSubscriptionDir', ''));
  } catch (e) { }
  // createWorkDir falls back to the system temp dir on a read-only destination.
  addRoot(os.tmpdir(), { inTemp: true, maxDepth: 1 });

  const seen = new Set();
  return roots.filter(r => {
    const key = `${r.inTemp ? 't' : 'd'}:${path.resolve(r.dir).toLowerCase()}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

/** Scratch dirs of live / resumable jobs must never be swept. */
function protectedWorkDirs() {
  const out = [];
  const push = (p) => { if (p) out.push(String(p)); };
  for (const job of downloadQueue) {
    push(job.workDir);
    if (Array.isArray(job.items)) for (const it of job.items) push(it.workDir);
  }
  try {
    const saved = store.get(RESUME_QUEUE_KEY, []) || [];
    for (const job of saved) {
      if (!job) continue;
      push(job.workDir);
      if (Array.isArray(job.items)) for (const it of job.items) push(it && it.workDir);
    }
  } catch (e) { }
  return out;
}

/** Silent startup sweep after the resume queue has been restored. */
function sweepOrphanWorkDirs(options = {}) {
  try {
    const report = cleanupLeftovers({
      roots: cleanupScanRoots(),
      protectedPaths: protectedWorkDirs(),
      dryRun: !!options.dryRun,
    });
    if (report.removed) {
      console.log(`Cleaned ${report.removed} leftover work folder(s), ${report.files} file(s).`);
    }
    return report;
  } catch (error) {
    console.log('Leftover cleanup failed (non-critical):', error?.message || error);
    return { success: false, error: error?.message || 'Cleanup failed.' };
  }
}

ipcMain.handle('cleanup-temp-files', async (event, options = {}) =>
  sweepOrphanWorkDirs({ dryRun: !!(options && options.dryRun) }));

/**
 * Translate a UI quality choice into a yt-dlp format selector plus sort order.
 *
 * Two flags replace what used to be a twelve-alternative fallback chain:
 *
 *   -f  says which *combinations are acceptable*. `bv*` is "best stream that
 *       has video" (it may carry audio too) rather than `bestvideo`, which is
 *       video-ONLY and therefore matches nothing on the many sites that ship
 *       muxed streams exclusively. `/b` then accepts a single combined stream.
 *
 *   -S  says which of the acceptable ones to *prefer*. Fields are applied in
 *       order, so `res:H` decides first and `vcodec:h264` only breaks ties
 *       between formats at the same resolution. That is what lets us keep
 *       preferring H.264 for editor compatibility without ever capping
 *       resolution — the trap the old chain fell into, since H.264 stops at
 *       1080p on YouTube.
 *
 * Quality is the priority throughout: the requested rung wins over codec
 * preference, and codec preference wins over container convenience.
 */
/**
 * Video settings presets:
 *
 *   Video : H.264 / AVC1 only · max 720p (1280px wide) · MP4 · stream-copy
 *   Audio : first track only · AAC-LC stereo copied, otherwise re-encoded to
 *           AAC-LC 128 kbps / 44.1 kHz / 2 channels
 *   Tags  : audio track titled “English”, language “eng” (metadata only)
 *
 * The selector below is what makes the video half true: `vcodec^=avc1` means
 * yt-dlp only considers H.264 streams, so the merge is a stream copy and the
 * file never gets re-encoded. The portrait/landscape pair exists because the
 * caps have to be swapped for vertical video — a 720×1280 Short has a height
 * of 1280 and would be excluded by a bare `height<=720`.
 */
const HD_PRESETS = {
  hd720: { height: 720, width: 1280, label: '720p HD' },
  hd480: { height: 480, width: 854, label: '480p HD' },
};

const HD_QUALITY_KEYS = Object.keys(HD_PRESETS);
const isHdQuality = (quality) => Object.prototype.hasOwnProperty.call(HD_PRESETS, String(quality));

function hdFormatSelector({ height: H, width: W }) {
  const base =
      // H.264 landscape, H.264 portrait
      `bv*[vcodec^=avc1][height<=${H}][width<=${W}]+ba[acodec^=mp4a]/` +
      `bv*[vcodec^=avc1][height<=${H}][width<=${W}]+ba/` +
      `bv*[vcodec^=avc1][height<=${W}][width<=${H}]+ba[acodec^=mp4a]/` +
      `bv*[vcodec^=avc1][height<=${W}][width<=${H}]+ba/` +
      // muxed H.264 (sites that ship a single progressive file)
      `b[vcodec^=avc1][height<=${H}][width<=${W}]/` +
      // last resort: anything that fits the caps, so the download still lands
      `bv*[height<=${H}][width<=${W}]+ba/b[height<=${H}][width<=${W}]/` +
      `bv*+ba/b`;
  return {
    formatArg: base,
    sortArg: `res:${H},vcodec:h264,acodec:aac,lang:en`,
  };
}

function buildFormatSelector(quality, type) {
  if (type === 'mp3') {
    return {
      // A muxed stream is a perfectly good source to extract audio from, and
      // on muxed-only sites it is the ONLY source — without the `/b` fallback
      // yt-dlp aborts with "Requested format is not available".
      formatArg: 'ba/b',
      // Deliberately NOT sorted by `abr`. YouTube ships a dynamic-range
      // compressed twin of each audio track (140-drc) whose measured bitrate
      // is a hair higher than the original's but whose `quality` is lower.
      // Sorting on bitrate promoted the squashed track over the real one; the
      // default sort's `quality` key already knows better.
      sortArg: 'acodec:aac',
    };
  }

  if (isHdQuality(quality)) {
    return hdFormatSelector(HD_PRESETS[String(quality)]);
  }

  const h = parseInt(quality, 10);
  if (!isNaN(h)) {
    return {
      // Exact rung first, then anything at or below it, then anything at all,
      // so a stripped or expired response still yields a file.
      formatArg: `bv*[height<=${h}]+ba/b[height<=${h}]/bv*[height<=${h}]/bv*+ba/b`,
      sortArg: `res:${h},vcodec:h264,acodec:aac`,
    };
  }

  // "Best" = highest resolution available, with H.264 preferred only among
  // formats that tie on resolution.
  return {
    formatArg: 'bv*+ba/b',
    sortArg: 'res,vcodec:h264,acodec:aac',
  };
}

// Audio codecs an MP4 can carry that editors and QuickTime actually accept.
const MP4_SAFE_AUDIO = new Set(['aac', 'mp3', 'alac', 'ac3', 'eac3']);

/**
 * Stream inventory for the HD-preset pass: what is actually inside the file,
 * so the remux only runs when it has something to fix.
 */
function probeMediaStreams(file) {
  return new Promise((resolve) => {
    execFile(ffprobePath, [
      '-v', 'error',
      '-show_entries', 'stream=codec_type,codec_name,channels,sample_rate,width,height:stream_tags=language,handler_name,title',
      '-of', 'json',
      file,
    ], (err, stdout) => {
      if (err) return resolve(null);
      try {
        const streams = (JSON.parse(stdout).streams) || [];
        const video = streams.find(st => st.codec_type === 'video') || null;
        const audios = streams.filter(st => st.codec_type === 'audio');
        const tags = audios[0]?.tags || {};
        resolve({
          video,
          audio: audios[0] || null,
          audioCount: audios.length,
          language: (tags.language || '').toLowerCase(),
          // MP4 keeps the track name in handler_name, MKV in title.
          trackName: String(tags.handler_name || tags.title || '').toLowerCase(),
        });
      } catch (e) {
        resolve(null);
      }
    });
  });
}

/**
 * Apply the audio half of the HD spec to a freshly downloaded file:
 *
 *   - keep only the FIRST audio track (`-map 0:a:0`)
 *   - copy it when it is already AAC-LC stereo, otherwise re-encode to
 *     AAC-LC 128 kbps / 44.1 kHz / 2 channels
 *   - tag that track English / eng (metadata only — nothing is translated)
 *   - copy the video stream untouched, so this is a remux, not a re-encode
 *
 * Returns true when the file was rewritten. Any failure is non-fatal: the
 * callback at the call site keeps the downloaded original.
 */
async function applyHdAudioSpec(filePath, workDir) {
  const info = await probeMediaStreams(filePath);
  if (!info || !info.audio) return false; // video-only download, nothing to do

  const audio = info.audio;
  const alreadyAacStereo = audio.codec_name === 'aac' && (audio.channels || 2) <= 2;
  const needsWork = !alreadyAacStereo || info.audioCount > 1
    || info.language !== 'eng' || info.trackName !== 'english';
  if (!needsWork) return false;

  const tempOutput = workDir
    ? path.join(workDir, `${path.basename(filePath)}.hd.mp4`)
    : `${filePath}.hd.mp4`;

  const audioArgs = alreadyAacStereo
    ? ['-c:a', 'copy']
    : ['-c:a', 'aac', '-b:a', '128k', '-ar', '44100', '-ac', '2'];

  const args = [
    '-y',
    '-i', filePath,
    '-map', '0:v:0',
    '-map', '0:a:0',
    '-c:v', 'copy',
    ...audioArgs,
    // MP4 players read the track name from handler_name; `title` covers the
    // containers that use it instead (MKV). Both are metadata only.
    '-metadata:s:a:0', 'language=eng',
    '-metadata:s:a:0', 'title=English',
    '-metadata:s:a:0', 'handler_name=English',
    '-movflags', '+faststart',
    tempOutput,
  ];

  console.log('HD preset: normalising audio track (', audio.codec_name,
    `/${audio.channels || '?'}ch ) →`, alreadyAacStereo ? 'copy + tags' : 'AAC-LC 128k 44.1kHz stereo');

  await new Promise((resolve, reject) => {
    execFile(ffmpegPath, args, { windowsHide: true, maxBuffer: 8 * 1024 * 1024 }, (err) => {
      if (err) return reject(err);
      resolve();
    });
  });

  fs.renameSync(tempOutput, filePath);
  return true;
}

/** Codec name of the first audio stream, or '' if it can't be determined. */
function probeAudioCodec(file) {
  return new Promise((resolve) => {
    execFile(ffprobePath, [
      '-v', 'error',
      '-select_streams', 'a:0',
      '-show_entries', 'stream=codec_name',
      '-of', 'default=nw=1:nk=1',
      file,
    ], (err, stdout) => {
      resolve(err ? '' : String(stdout).trim().split(/\r?\n/)[0] || '');
    });
  });
}

/**
 * Turn captured yt-dlp stderr into something worth showing the user.
 *
 * Prefers the last real ERROR line, strips yt-dlp's own prefixes, and falls
 * back to the exit code only when there is genuinely nothing better.
 */
function ytDlpFailureMessage(stderrLines, code) {
  const errors = stderrLines.filter(l => /^ERROR:/i.test(l));
  // Without an ERROR line, the last non-warning line is the best guess. A
  // warning is never the reason a download failed, so never report one as if
  // it were.
  const chosen = errors[errors.length - 1] ||
    [...stderrLines].reverse().find(l => !/^WARNING:/i.test(l));
  if (!chosen) return `yt-dlp exited with code ${code}`;

  let cleaned = chosen.replace(/^ERROR:\s*/i, '');

  // yt-dlp formats these as "[Extractor] <video id>: <message>". Only strip a
  // leading "<id>: " when the bracketed extractor tag proves one was there —
  // otherwise a message that merely happens to contain a colon loses its
  // first word.
  const tagged = /^\[[^\]]+\]\s*/.test(cleaned);
  cleaned = cleaned.replace(/^\[[^\]]+\]\s*/, '');
  if (tagged) cleaned = cleaned.replace(/^[^\s:]{1,40}:\s+/, '');

  cleaned = cleaned
    .replace(/\s*Use --list-formats.*$/i, '')
    .replace(/\s*Set --default-search.*$/i, '')
    .replace(/;\s*please report this issue.*$/i, '')
    .trim();

  return cleaned || `yt-dlp exited with code ${code}`;
}

/**
 * Deletes the final output file AND any yt-dlp intermediate temp files.
 */
function deletePartialDownloadFiles(filePath) {
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      console.log('Deleted partial file:', filePath);
    }
  } catch (err) {
    console.error('Failed to delete partial file:', filePath, err.message);
  }

  const dir = path.dirname(filePath);
  const base = path.basename(filePath, path.extname(filePath)); // e.g. "My Video"
  const tempPrefix = base + '.f'; // yt-dlp temp files: "My Video.f315.webm"
  try {
    const entries = fs.readdirSync(dir);
    for (const entry of entries) {
      if (entry.startsWith(tempPrefix) && entry !== path.basename(filePath)) {
        const tempPath = path.join(dir, entry);
        try {
          fs.unlinkSync(tempPath);
          console.log('Deleted yt-dlp temp file:', tempPath);
        } catch (e) {
          console.error('Failed to delete yt-dlp temp file:', tempPath, e.message);
        }
      }
    }
  } catch (e) {
    console.error('Failed to scan directory for temp files:', e.message);
  }
}

// ===========================================================================
// DOWNLOAD QUEUE
// The queue lives entirely in the main process so downloads survive any
// navigation in the renderer. Up to the configured parallel limit (2 / 4 / 8 / 16 / 32 (custom 1–64))
// run at once, FIFO. Every job is either a single video or a whole playlist.
// ===========================================================================
let downloadQueue = [];       // array of job objects
const activeJobs = new Map(); // jobId -> job currently downloading
const jobControls = new Map(); // controlKey -> { cancel, pause, resume, isPaused, pauseReason, stage, cleanupNow }
let jobSeq = 0;

const controlKey = (jobId, itemId) => `${jobId}::${itemId == null ? 'job' : itemId}`;
function forEachJobControl(jobId, fn) {
  const prefix = `${jobId}::`;
  for (const [key, ctl] of jobControls) {
    if (key.startsWith(prefix)) fn(ctl);
  }
}

function serializeJob(job) {
  const base = {
    id: job.id,
    kind: job.kind,
    status: job.status,
    title: job.title,
    thumbnailUrl: job.thumbnailUrl,
    url: job.url,
    createdAt: job.createdAt,
    sizeBytes: job.sizeBytes || 0,
    formatLabel: job.formatLabel || '',
    progress: job.progress || null,
    error: job.error || null,
    resume: !!job.resume,
  };
  if (job.kind === 'playlist') {
    base.uploader = job.uploader;
    base.targetDir = job.targetDir;
    base.currentIndex = job.currentIndex;
    base.items = job.items.map(it => ({
      id: it.id,
      title: it.title,
      playlistIndex: it.playlistIndex ?? null,
      url: it.url,
      thumbnail: it.thumbnail,
      duration: it.duration,
      status: it.status,
      quality: it.quality,
      qualityLabel: it.qualityLabel,
      type: it.type,
      convertToH264: it.convertToH264,
      sizeBytes: it.sizeBytes || 0,
      filePath: it.filePath || null,
    }));
  } else if (job.kind === 'file') {
    base.fileName = job.fileName;
    base.filePath = job.filePath;
    base.partPath = job.partPath || null;
    base.source = job.source || 'extension';
  } else {
    base.quality = job.quality;
    base.qualityLabel = job.qualityLabel;
    base.type = job.type;
    base.convertToH264 = job.convertToH264;
    base.filePath = job.filePath;
    base.meta = job.meta || null;
  }
  return base;
}

function broadcastQueue() {
  safeSend('queue-updated', downloadQueue.map(serializeJob));
  saveResumeQueue();
}

/** Plain snapshot of pending jobs, safe to write to electron-store. */
function serializeResumeJob(job) {
  const base = serializeJob(job);
  return {
    ...base,
    status: 'queued',
    cancelled: false,
    resume: !!job.resume || job.status === 'downloading',
    workDir: job.workDir || null,
    reservedCount: Number(job.reservedCount) || 1,
    allowDuplicates: job.allowDuplicates,
    targetDir: job.targetDir || null,
    subscriptionId: job.subscriptionId || null,
    videoId: job.videoId || null,
    partPath: job.partPath || null,
    fileName: job.fileName || null,
    source: job.source || null,
    items: job.kind === 'playlist'
      ? (job.items || []).map(it => ({
          id: it.id,
          title: it.title,
          playlistIndex: it.playlistIndex ?? null,
          url: it.url,
          thumbnail: it.thumbnail,
          duration: it.duration,
          status: it.status === 'downloading' ? 'queued' : it.status,
          quality: it.quality,
          qualityLabel: it.qualityLabel,
          type: it.type,
          convertToH264: it.convertToH264,
          sizeBytes: it.sizeBytes || 0,
          filePath: it.filePath || null,
          workDir: it.workDir || null,
          resume: !!it.resume || it.status === 'downloading',
        }))
      : undefined,
  };
}

function saveResumeQueue() {
  try {
    const pending = downloadQueue.filter(j => j.status === 'queued' || j.status === 'downloading');
    store.set(RESUME_QUEUE_KEY, pending.map(serializeResumeJob));
  } catch (e) {
    console.error('Failed to save resume queue:', e.message);
  }
}
function clearResumeQueue() {
  try { store.set(RESUME_QUEUE_KEY, []); } catch (e) {
    console.error('Failed to clear resume queue:', e.message);
  }
}
function restoreResumeQueue() {
  let saved = [];
  try { saved = store.get(RESUME_QUEUE_KEY, []) || []; } catch (e) { return 0; }
  if (!Array.isArray(saved) || !saved.length) return 0;
  let restored = 0;
  for (const raw of saved) {
    if (!raw || !raw.id || !raw.url) continue;
    const workDir = raw.workDir && fs.existsSync(raw.workDir) ? raw.workDir : null;
    const job = {
      ...raw,
      status: 'queued',
      cancelled: false,
      resume: !!raw.resume,
      workDir: (raw.kind === 'video' || raw.kind === 'file') ? workDir : null,
      progress: null,
      error: null,
      items: Array.isArray(raw.items) ? raw.items.map(it => ({
        ...it,
        status: it.status === 'downloading' ? 'queued' : it.status,
        workDir: it.workDir && fs.existsSync(it.workDir) ? it.workDir : null,
        resume: !!it.resume,
      })) : undefined,
    };
    downloadQueue.push(job);
    reserveVideos(Number(job.reservedCount) || 1);
    const m = String(job.id).match(/^job-(\d+)-/);
    if (m) jobSeq = Math.max(jobSeq, Number(m[1]) || 0);
    restored += 1;
  }
  jobSeq += 1;
  if (restored) {
    console.log(`Restored ${restored} download(s) from the previous session`);
    broadcastQueue();
  }
  return restored;
}

function removeJobFromQueue(jobId) {
  const job = downloadQueue.find(j => j.id === jobId);
  releaseJobReservation(job);
  downloadQueue = downloadQueue.filter(j => j.id !== jobId);
  broadcastQueue();
}

/**
 * Core downloader for ONE video (or audio extraction), including the optional
 * offline H.264 conversion. Sends progress via 'download-progress' events
 * tagged with jobId/itemId. Registers a per-job control handle so several
 * downloads can be paused, resumed or cancelled independently.
 *
 * Returns { success, path } | { success:false, error, cancelled?, keptOriginal? }
 */
function runVideoDownloadCore({ url, quality, type, convertToH264, filePath, jobId, itemId, job, resume = false, existingWorkDir = null }) {
  return new Promise(async (outerResolve) => {
    let isCancelled = false;
    let didConvert = false;
    let didHdPass = false;
    let isPaused = false;
    let pauseReason = null;
    let ytDlpProcess = null;
    let ffmpegProcess = null;
    let keepOriginalOnCancel = false;
    let downloadStage = 'starting';
    let workDir = null;
    // On app quit the partial files must SURVIVE so the next launch can
    // --continue from the same byte. Cancel All / normal cancellation do not
    // set this, so they still wipe partials as before.
    let preserveForResume = false;

    let downloadStartTime = Date.now();
    let totalPauseDuration = 0;
    let pauseStartTime = 0;
    let speedWindow = []; // Array of { t: number, b: number }
    let lastPayloadTime = 0;

    const sendProgress = (payload) => {
      const full = { jobId, itemId, ...payload };
      if (job) job.progress = full;
      safeSend('download-progress', full);
    };

    const ctl = {
      cancel: (keepOriginal = false, opts = {}) => {
        isCancelled = true;
        if (opts && opts.preserveForResume) preserveForResume = true;
        keepOriginalOnCancel = keepOriginal;
        if (ytDlpProcess) {
          if (isPaused && process.platform !== 'win32') {
            try { process.kill(-ytDlpProcess.pid, 'SIGCONT'); } catch (e) { }
          }
          if (process.platform === 'win32') {
            spawn('taskkill', ['/pid', String(ytDlpProcess.pid), '/f', '/t'], { windowsHide: true });
          } else {
            try { process.kill(-ytDlpProcess.pid, 'SIGTERM'); } catch (_) {
              ytDlpProcess.kill('SIGTERM');
            }
          }
        }
        if (ffmpegProcess) {
          if (isPaused && process.platform !== 'win32') {
            try { process.kill(-ffmpegProcess.pid, 'SIGCONT'); } catch (e) { }
          }
          if (process.platform === 'win32') {
            spawn('taskkill', ['/pid', String(ffmpegProcess.pid), '/f', '/t'], { windowsHide: true });
          } else {
            try { process.kill(-ffmpegProcess.pid, 'SIGTERM'); } catch (_) {
              ffmpegProcess.kill('SIGTERM');
            }
          }
        }
        isPaused = false;
        pauseReason = null;
        pauseStartTime = 0;
      },
      pause: (reason = 'user') => {
        if (isPaused || (!ytDlpProcess && !ffmpegProcess) || isCancelled) return;
        if (downloadStage === 'merging' || downloadStage === 'processing') return;
        if (process.platform === 'win32') return; // SIGSTOP unsupported on Windows
        isPaused = true;
        pauseReason = reason;
        pauseStartTime = Date.now();
        try {
          if (ytDlpProcess) process.kill(-ytDlpProcess.pid, 'SIGSTOP');
          if (ffmpegProcess) process.kill(-ffmpegProcess.pid, 'SIGSTOP');
        } catch (e) {
          console.error('SIGSTOP failed:', e.message);
          try { if (ytDlpProcess) ytDlpProcess.kill('SIGSTOP'); if (ffmpegProcess) ffmpegProcess.kill('SIGSTOP'); } catch (e2) { }
        }
        console.log(`Download paused (${reason})`);
        sendProgress({ paused: true, reason, stage: downloadStage });
      },
      resume: () => {
        if (!isPaused || (!ytDlpProcess && !ffmpegProcess) || isCancelled) return;
        isPaused = false;
        pauseReason = null;
        if (pauseStartTime) {
          totalPauseDuration += (Date.now() - pauseStartTime);
          pauseStartTime = 0;
        }
        if (process.platform !== 'win32') {
          try {
            if (ytDlpProcess) process.kill(-ytDlpProcess.pid, 'SIGCONT');
            if (ffmpegProcess) process.kill(-ffmpegProcess.pid, 'SIGCONT');
          } catch (e) {
            console.error('SIGCONT failed:', e.message);
            try { if (ytDlpProcess) ytDlpProcess.kill('SIGCONT'); if (ffmpegProcess) ffmpegProcess.kill('SIGCONT'); } catch (e2) { }
          }
        }
        console.log('Download resumed');
        sendProgress({ paused: false, reason: null, stage: downloadStage });
      },
      get isPaused() { return isPaused; },
      get pauseReason() { return pauseReason; },
      get stage() { return downloadStage; },
      // Synchronous best-effort cleanup for app quit. During conversion the
      // download itself is complete, so the original is kept — the same
      // choice the in-app cancel dialog defaults to offering.
      cleanupNow: () => {
        if (preserveForResume) return;
        removeWorkDir(workDir);
        workDir = null;
        if (downloadStage !== 'converting' && downloadStage !== 'done') {
          deletePartialDownloadFiles(filePath);
        }
      },
    };
    jobControls.set(controlKey(jobId, itemId), ctl);

    try {
      let { formatArg, sortArg } = buildFormatSelector(quality, type);

      // Delete any stale FINAL file before a fresh download. On resume we
      // leave it alone: the .part files live in the hidden work dir, not here.
      if (!resume && fs.existsSync(filePath)) {
        try { fs.unlinkSync(filePath); } catch (err) {
          console.error('Failed to delete existing file:', err);
        }
      }

      // Everything intermediate happens out of sight, then yt-dlp moves the
      // single finished file into place. `--paths` is silently ignored when
      // --output is absolute, so the destination has to be given as `home:`
      // and the output template reduced to a bare filename.
      workDir = createWorkDir(filePath, `${jobId || 'job'}-${itemId || 'single'}`, existingWorkDir);
      // Remember the scratch dir on the job/playlist item so a quit snapshot
      // can point --continue back at the exact same .part files.
      if (job) {
        if (itemId != null) {
          const item = (job.items || []).find(it => String(it.id) === String(itemId));
          if (item) item.workDir = workDir;
        } else {
          job.workDir = workDir;
        }
      }

      const args = [
        url,
        '--format', formatArg,
        '--format-sort', sortArg,
        ...(workDir
          ? ['--paths', `home:${path.dirname(filePath)}`,
             '--paths', `temp:${workDir}`,
             '--output', outputTemplate(path.basename(filePath))]
          : ['--output', outputTemplate(filePath)]),
        '--ffmpeg-location', ffmpegPath,
        '--newline',
        ...getAuthArgs(url),
        ...BASE_ARGS,
        ...downloadSpeedArgs(),
        ...(resume ? ['--continue'] : []),
      ];

      // NOTE: never override player_client for downloads *by default* — when
      // cookies are present yt-dlp skips the android client, and a reduced
      // client set can end up with no downloadable formats at all ("Only
      // images are available"). The height<= relaxation in the selector
      // handles stripped responses. The one exception is a video whose info
      // fetch only succeeded through a retry: the download must replay that
      // exact client set (and carry a PO token) or it hits the same wall the
      // first fetch did. Videos that fetched normally add nothing here.
      args.push(...await ytDownloadArgs(url));

      if (type === 'mp3') {
        args.push('--extract-audio', '--audio-format', 'mp3', '--audio-quality', '0');
      } else {
        args.push('--merge-output-format', 'mp4');
      }

      console.log('Starting yt-dlp download:', formatArg, '-S', sortArg, '->', filePath);

      // Spawn in its own process group (detached) so SIGSTOP/SIGCONT
      // can freeze/resume the entire group via negative PID
      ytDlpProcess = spawn(ytDlpBinaryPath, args, { env: getYtDlpEnv(), detached: true, windowsHide: true });

      sendProgress({ percent: 0, downloadedBytes: 0, totalBytes: 0, stage: 'starting' });

      let lastPercent = -1;
      let stdoutBuf = '';
      let stageCount = 0;
      // Per-stream: smoothed size estimate and the high-water mark of bytes
      // actually fetched. Both reset when a new "Destination:" line starts the
      // next stream, since its totals are unrelated to the previous one's.
      let smoothedTotal = 0;
      let maxDownloadedBytes = 0;
      let totalIsEstimate = false;

      ytDlpProcess.stdout.on('data', (chunk) => {
        stdoutBuf += chunk.toString();
        const lines = stdoutBuf.split(/\r?\n/);
        stdoutBuf = lines.pop();
        lines.forEach((line) => {
          if (!line.trim()) return;

          if (line.includes('[download] Destination:')) {
            stageCount++;
            if (type === 'mp3') {
              downloadStage = 'audio';
            } else {
              downloadStage = stageCount === 1 ? 'video' : 'audio';
            }
            lastPercent = -1;
            speedWindow = [];
            smoothedTotal = 0;
            maxDownloadedBytes = 0;
            totalIsEstimate = false;
          } else if (line.includes('[Merger]') || line.includes('[Mux]')) {
            downloadStage = 'merging';
            if (!isPaused) sendProgress({ percent: -1, downloadedBytes: 0, totalBytes: 0, stage: 'merging' });
          } else if (line.includes('[ExtractAudio]') || line.includes('[FFmpegMetadata]')) {
            downloadStage = 'processing';
            if (!isPaused) sendProgress({ percent: -1, downloadedBytes: 0, totalBytes: 0, stage: 'processing' });
          }

          if (isPaused) return;

          // [download]  12.3% of   54.23MiB at  3.10MiB/s ETA 00:15
          // [download]  12.3% of ~ 54.23MiB at ... (frag 25/59)
          //
          // The tilde marks a GUESS. On a fragmented download (HLS/DASH — most
          // of X, Dailymotion, PornHub) yt-dlp has no content length up front,
          // so it extrapolates the total from the fragments seen so far and
          // re-guesses on every line. Reported verbatim that total swings
          // wildly — 1.13 GB one second, 916 MB the next — and since
          // "downloaded" was derived from it, the bytes and the ETA lurched
          // backwards too.
          const downloadMatch = line.match(/\[download\]\s+([\d.]+)%\s+of\s+(~)?\s*([\d.]+)([KMGTi]+B)/i);
          let percentValue = null;
          let downloadedBytes = 0;
          let totalBytes = 0;

          if (downloadMatch) {
            percentValue = Math.min(100, parseFloat(downloadMatch[1]));
            const isEstimate = !!downloadMatch[2];
            const rawTotal = sizeToBytes(parseFloat(downloadMatch[3]), downloadMatch[4]);

            totalIsEstimate = isEstimate;

            if (!isEstimate) {
              totalBytes = rawTotal;
              smoothedTotal = rawTotal;
            } else if (smoothedTotal === 0) {
              totalBytes = smoothedTotal = rawTotal;
            } else {
              // Heavy exponential smoothing. Measured against 648 real progress
              // lines from a fragmented download: raw swung by up to 53%
              // between updates, 0.85 still left 29%, 0.995 leaves 2.3% — one
              // visible movement across the whole download. Tracking the guess
              // faster is counterproductive, because the noisiest estimates are
              // the earliest ones.
              smoothedTotal = Math.round(smoothedTotal * 0.995 + rawTotal * 0.005);
              totalBytes = smoothedTotal;
            }

            downloadedBytes = Math.round(totalBytes * (percentValue / 100));
            // Bytes already on disk cannot un-download themselves. Clamping
            // keeps the readout and the speed window monotonic even while the
            // total behind them is still settling.
            if (downloadedBytes < maxDownloadedBytes) {
              downloadedBytes = maxDownloadedBytes;
            } else {
              maxDownloadedBytes = downloadedBytes;
            }
            if (totalBytes < downloadedBytes) totalBytes = downloadedBytes;
          } else {
            const bare = line.match(/(?:^|\s)(\d{1,3}\.?\d*)%/);
            if (bare) percentValue = Math.min(100, parseFloat(bare[1]));
          }

          if (percentValue !== null && downloadedBytes > 0) {
            const now = Date.now();
            if (speedWindow.length === 0 || speedWindow[speedWindow.length - 1].t !== now) {
              speedWindow.push({ t: now, b: downloadedBytes });
            }
            while (speedWindow.length > 0 && now - speedWindow[0].t > 10000) {
              speedWindow.shift();
            }
          }

          const now = Date.now();
          if ((percentValue !== null && percentValue !== lastPercent) || (now - lastPayloadTime > 500)) {
            if (percentValue !== null) lastPercent = percentValue;

            let currentSpeed = 0;
            let currentEta = 0;

            if (speedWindow.length > 1) {
              const oldest = speedWindow[0];
              const newest = speedWindow[speedWindow.length - 1];
              const timeDiffSec = (newest.t - oldest.t) / 1000;
              const bytesDiff = newest.b - oldest.b;
              if (timeDiffSec > 0 && bytesDiff > 0) {
                currentSpeed = bytesDiff / timeDiffSec;
                if (totalBytes > downloadedBytes) {
                  currentEta = Math.round((totalBytes - downloadedBytes) / currentSpeed);
                }
              }
            }

            let elapsedSec = Math.floor((now - downloadStartTime - totalPauseDuration) / 1000);
            if (elapsedSec < 0) elapsedSec = 0;

            lastPayloadTime = now;
            sendProgress({
              percent: lastPercent !== -1 ? lastPercent : 0,
              downloadedBytes,
              totalBytes,
              stage: downloadStage,
              // Tells the UI to render the total as approximate. On fragmented
              // sources it is an extrapolation, not a content length.
              totalIsEstimate,
              speed: currentSpeed,
              eta: currentEta,
              elapsed: elapsedSec
            });
          }
        });
      });

      // Keep the tail of stderr so a failure can say what actually went wrong.
      // Across 1000+ extractors the useful part is nearly always yt-dlp's own
      // ERROR line ("Requested format is not available", "This video is
      // private", "geo restricted"), and "exited with code 1" tells the user
      // nothing they can act on.
      const stderrLines = [];
      ytDlpProcess.stderr.on('data', (data) => {
        const text = data.toString();
        console.error('yt-dlp stderr:', text);
        for (const line of text.split(/\r?\n/)) {
          if (line.trim()) stderrLines.push(line.trim());
        }
        if (stderrLines.length > 50) stderrLines.splice(0, stderrLines.length - 50);
      });

      await new Promise((resolve, reject) => {
        ytDlpProcess.on('close', (code) => {
          if (isCancelled) {
            reject(new Error('Download was canceled.'));
          } else if (code === 0) {
            resolve();
          } else {
            reject(new Error(ytDlpFailureMessage(stderrLines, code)));
          }
        });
        ytDlpProcess.on('error', (err) => reject(err));
      });

      if (isCancelled) throw new Error("Download was canceled.");

      // --- OFFLINE H.264 CONVERSION ---
      if (convertToH264 && type === 'mp4' && !isCancelled) {
        downloadStage = 'converting';
        speedWindow = [];
        // Keep the half-written re-encode beside the fragments rather than in
        // the user's folder, for the same reason.
        const tempOutput = workDir
          ? path.join(workDir, path.basename(filePath) + '.tmp.mp4')
          : filePath + '.tmp.mp4';
        sendProgress({ percent: 0, downloadedBytes: 0, totalBytes: 0, stage: 'converting' });

        // Copying the audio is free and lossless, but only when the stream is
        // already something MP4 can carry. VP9/AV1 downloads often arrive with
        // Opus, which most editors refuse to open inside MP4.
        const sourceAudio = await probeAudioCodec(filePath);
        const audioArgs = MP4_SAFE_AUDIO.has(sourceAudio)
          ? ['-c:a', 'copy']
          : ['-c:a', 'aac', '-b:a', '192k'];

        await new Promise((resolve, reject) => {
          const convArgs = [
            '-y',
            '-i', filePath,
            '-c:v', 'libx264',
            // The point of this conversion is a file that opens everywhere, so
            // it is worth real encoder effort rather than the fastest possible
            // pass. 'ultrafast' at CRF 23 produced visibly soft output that was
            // also larger than the VP9 source it replaced.
            '-preset', 'medium',
            '-crf', '18',
            // 10-bit VP9/AV1 would otherwise come out as H.264 High 10, which
            // QuickTime, Premiere and iMovie cannot open — the exact players
            // this conversion exists to satisfy.
            '-pix_fmt', 'yuv420p',
            ...audioArgs,
            '-movflags', '+faststart',
            tempOutput
          ];

          console.log('Starting offline FFmpeg conversion (source audio:', sourceAudio || 'unknown', ')');
          ffmpegProcess = spawn(ffmpegPath, convArgs, { detached: true, windowsHide: true });

          let totalDurationSec = 0;

          ffmpegProcess.stderr.on('data', (data) => {
            const out = data.toString();

            const dirMatch = out.match(/Duration:\s+(\d{2}):(\d{2}):(\d{2}\.\d{2})/);
            if (dirMatch && !totalDurationSec) {
              totalDurationSec = parseInt(dirMatch[1]) * 3600 + parseInt(dirMatch[2]) * 60 + parseFloat(dirMatch[3]);
            }

            const timeMatch = out.match(/time=(\d{2}):(\d{2}):(\d{2}\.\d{2})/);
            if (timeMatch && totalDurationSec > 0 && !isPaused) {
              const currentSec = parseInt(timeMatch[1]) * 3600 + parseInt(timeMatch[2]) * 60 + parseFloat(timeMatch[3]);
              let percentValue = (currentSec / totalDurationSec) * 100;
              if (percentValue > 100) percentValue = 100;

              const now = Date.now();

              if (speedWindow.length === 0 || speedWindow[speedWindow.length - 1].t !== now) {
                speedWindow.push({ t: now, b: currentSec });
              }
              while (speedWindow.length > 0 && now - speedWindow[0].t > 10000) {
                speedWindow.shift();
              }

              if (now - lastPayloadTime > 500) {
                lastPayloadTime = now;
                let elapsedSec = Math.floor((now - downloadStartTime - totalPauseDuration) / 1000);
                if (elapsedSec < 0) elapsedSec = 0;

                let currentSpeed = 0; // "x multiplier" while converting
                let currentEta = 0;

                if (speedWindow.length > 1) {
                  const oldest = speedWindow[0];
                  const newest = speedWindow[speedWindow.length - 1];
                  const timeDiffSec = (newest.t - oldest.t) / 1000;
                  const processedDiff = newest.b - oldest.b;
                  if (timeDiffSec > 0 && processedDiff > 0) {
                    currentSpeed = processedDiff / timeDiffSec;
                    const remainingVideoSec = totalDurationSec - currentSec;
                    if (remainingVideoSec > 0) {
                      currentEta = Math.round(remainingVideoSec / currentSpeed);
                    }
                  }
                }

                sendProgress({
                  percent: percentValue,
                  downloadedBytes: 0,
                  totalBytes: 0,
                  stage: 'converting',
                  speed: currentSpeed,
                  eta: currentEta,
                  elapsed: elapsedSec
                });
              }
            }
          });

          ffmpegProcess.on('close', (code) => {
            if (isCancelled) {
              if (keepOriginalOnCancel) {
                resolve(); // Resolve cleanly to return the original file
              } else {
                reject(new Error("Conversion was canceled."));
              }
            } else if (code === 0) {
              try {
                fs.renameSync(tempOutput, filePath);
                didConvert = true;
                console.log('Conversion successful. Overwrote original file.');
              } catch (e) { console.error('Rename failed after conversion', e); }
              resolve();
            } else {
              reject(new Error(`ffmpeg exited with code ${code}`));
            }
          });
          ffmpegProcess.on('error', (err) => reject(err));
        });

        if (isCancelled && !keepOriginalOnCancel) throw new Error("Conversion was canceled.");
      }

      // --- HD PRESET: audio spec + tags (video is always stream-copied) ---
      if (isHdQuality(quality) && type === 'mp4' && !isCancelled && fs.existsSync(filePath)) {
        downloadStage = 'processing';
        sendProgress({ percent: 0, downloadedBytes: 0, totalBytes: 0, stage: 'processing' });
        try {
          const rewritten = await applyHdAudioSpec(filePath, workDir);
          if (rewritten) didHdPass = true;
        } catch (hdErr) {
          // Never fail a finished download over the remux — the user keeps the
          // original, which is a complete, playable file.
          console.error('HD audio pass failed (non-critical):', hdErr.message);
        }
        downloadStage = 'done';
      }

      console.log('Download complete! File saved at:', filePath);

      const finalSize = fs.existsSync(filePath) ? fs.statSync(filePath).size : 0;
      sendProgress({
        percent: 100,
        downloadedBytes: finalSize,
        totalBytes: finalSize,
        stage: 'done',
      });

      outerResolve({ success: true, path: filePath, converted: didConvert, hdPass: didHdPass, keptOriginal: isCancelled && keepOriginalOnCancel });
    } catch (err) {
      outerResolve({
        success: false,
        error: err.message,
        cancelled: isCancelled,
      });
    } finally {
      // Defensive cleanup on cancel. On app quit we deliberately KEEP the
      // hidden work dir + .part files so the next launch can --continue.
      if (isCancelled && !preserveForResume) {
        if (keepOriginalOnCancel) {
          try { fs.unlinkSync(filePath + '.tmp.mp4'); } catch (e) { }
        } else {
          deletePartialDownloadFiles(filePath);
          try { fs.unlinkSync(filePath + '.tmp.mp4'); } catch (e) { }
        }
      }
      if (!preserveForResume) {
        removeWorkDir(workDir);
        workDir = null;
        if (job) {
          if (itemId != null) {
            const item = (job.items || []).find(it => String(it.id) === String(itemId));
            if (item) item.workDir = null;
          } else {
            job.workDir = null;
          }
        }
      }
      jobControls.delete(controlKey(jobId, itemId));
    }
  });
}

// Filesystems cap a single name at 255 *bytes*, not characters (APFS, ext4,
// NTFS all land there). Leave room for the extension and a " (12)" duplicate
// suffix.
const MAX_FILENAME_BYTES = 255;
const FILENAME_RESERVE_BYTES = 16;

/**
 * Sanitise a video title into a filename stem that the filesystem will accept.
 *
 * The byte budget is not paranoia. On YouTube a title is a title, but X, Reddit
 * and Mastodon use the whole post as one — a single 280-character tweet with a
 * couple of emoji is 400+ bytes, and writing it threw ENAMETOOLONG before the
 * download had a chance to start.
 */
/** "01 - Song" from yt-dlp's real 1-based playlist_index (gaps preserved). */
function numberedPlaylistTitle(title, playlistIndex) {
  const settings = { ...DEFAULT_VIDEO_SETTINGS, ...(store.get(VIDEO_SETTINGS_KEY, {}) || {}) };
  const n = Number(playlistIndex);
  if (!settings.playlistNumbering || !Number.isFinite(n) || n < 1) return String(title || 'video');
  const pad = String(Math.floor(n)).padStart(2, '0');
  return `${pad} - ${String(title || 'video')}`;
}

function safeFileStem(title, ext) {
  let stem = String(title || 'video')
    .replace(/[\\/:"*?<>|]/g, '')
    // Control characters and newlines are legal in some filesystems and awful
    // in all of them; post text routinely contains newlines.
    .replace(/[\x00-\x1f\x7f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const budget = MAX_FILENAME_BYTES - FILENAME_RESERVE_BYTES - Buffer.byteLength(`.${ext}`, 'utf8');
  if (Buffer.byteLength(stem, 'utf8') > budget) {
    // Cut on a UTF-8 boundary, then again on a whole code point, so a
    // multi-byte character or emoji never ends up half-written.
    const buf = Buffer.from(stem, 'utf8').subarray(0, budget);
    stem = buf.toString('utf8').replace(/\ufffd+$/, '').trimEnd();
  }

  // Windows rejects trailing dots and spaces, and reserves a handful of device
  // names; an empty stem would produce a bare ".mp4" dotfile.
  stem = stem.replace(/[. ]+$/, '');
  if (!stem || /^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$/i.test(stem)) stem = `video${stem ? '_' + stem : ''}`;
  return stem;
}

/** Resolve the output path inside a target directory, handling duplicates. */
function resolveOutputPath(targetDir, title, ext, allowDuplicates) {
  const safeTitle = safeFileStem(title, ext);
  let filePath = path.join(targetDir, `${safeTitle}.${ext}`);
  if (fs.existsSync(filePath) && allowDuplicates) {
    let counter = 1;
    while (fs.existsSync(filePath)) {
      filePath = path.join(targetDir, `${safeTitle} (${counter}).${ext}`);
      counter++;
    }
  }
  // When duplicates aren't allowed, the stale file is deleted right before
  // the download starts (inside runVideoDownloadCore).
  return filePath;
}

// Quality label for history entries. When the file was converted offline the
// codec tag shows source → final, e.g. "2160p60 (VP9 → H.264)", so converted
// files are distinguishable from native downloads.
function describeQuality(qualityLabel, converted) {
  if (!converted || !qualityLabel) return qualityLabel;
  return qualityLabel.replace(/\((VP9|AV1)\)/, '($1 → H.264)');
}

function addVideoHistoryItem() {
  // No history is written. Keep the daily-limit accounting and tell the
  // renderer to re-read the (always empty) history list.
  recordVideosDownloaded(1);
  safeSend('history-updated');
}

function addPlaylistHistoryItem(job) {
  const completed = job.items.filter(it => it.status === 'completed');
  if (completed.length === 0) return;
  // No history is written. Keep the daily-limit accounting and tell the
  // renderer to re-read the (always empty) history list.
  recordVideosDownloaded(completed.length);
  safeSend('history-updated');
}

/**
 * runVideoDownloadCore, plus the same second chance the info fetch gets: if
 * YouTube's default clients refuse the video (age gate, no formats) and no
 * client override is known for it yet, retry once with the gated client set
 * and a PO token. Needed because a download re-extracts from scratch — a
 * playlist item the prefetch never reached, or a re-download after a restart,
 * arrives here with no override even though the fetch path would have found
 * one. Cancels and non-YouTube failures pass straight through.
 */
async function runVideoDownload(opts) {
  const result = await runVideoDownloadCore(opts);
  if (result.success || result.keptOriginal || result.cancelled) return result;
  if (opts.job?.cancelled) return result;
  const videoId = youTubeVideoId(opts.url);
  if (!videoId || ytClientOverrides.has(videoId)) return result;
  if (!YT_RETRYABLE_KINDS.has(classifyYtDlpError(result.error || ''))) return result;

  console.log('Download refused by default clients, retrying with explicit client set:', videoId);
  rememberClientOverride(opts.url, YT_RETRY_CLIENTS);
  const retried = await runVideoDownloadCore(opts);
  // Don't pin a client set that didn't help — the next attempt should start clean.
  if (!retried.success && !retried.keptOriginal) ytClientOverrides.delete(videoId);
  return retried;
}

async function runVideoJob(job) {
  const result = await runVideoDownload({
    url: job.url,
    quality: job.quality,
    type: job.type,
    convertToH264: job.convertToH264,
    filePath: job.filePath,
    jobId: job.id,
    itemId: null,
    job,
    resume: !!job.resume,
    existingWorkDir: job.workDir || null,
  });
  job.resume = false;

  if (result.success || result.keptOriginal) {
    job.status = 'completed';
    addVideoHistoryItem(job, result.path || job.filePath, result.converted);
    safeSend('job-finished', { jobId: job.id, kind: 'video', success: true, path: result.path || job.filePath });
  } else if (result.cancelled) {
    job.status = 'cancelled';
    safeSend('job-finished', { jobId: job.id, kind: 'video', success: false, cancelled: true });
  } else {
    job.status = 'error';
    job.error = result.error;
    safeSend('job-finished', { jobId: job.id, kind: 'video', success: false, error: result.error });
  }

  // Apply the result to the subscription: only a verified success moves the
  // saved last-video id, and only that starts the next video in the batch.
  if (job.subscriptionId) {
    await handleSubscriptionJobResult(job, {
      success: !!(result.success || result.keptOriginal),
      cancelled: !!result.cancelled,
      path: result.path || job.filePath,
    });
  }
}

async function runPlaylistJob(job) {
  for (let i = 0; i < job.items.length; i++) {
    if (job.cancelled) break;
    const item = job.items[i];
    job.currentIndex = i;
    item.status = 'downloading';
    broadcastQueue();

    const ext = item.type === 'mp3' ? 'mp3' : 'mp4';
    const numberedTitle = numberedPlaylistTitle(item.title, item.playlistIndex);
    const filePath = resolveOutputPath(job.targetDir, numberedTitle, ext, job.allowDuplicates);

    const result = await runVideoDownload({
      url: item.url,
      quality: item.quality,
      type: item.type,
      convertToH264: item.convertToH264,
      filePath,
      jobId: job.id,
      itemId: item.id,
      job,
      resume: !!item.resume,
      existingWorkDir: item.workDir || null,
    });
    item.resume = false;

    if (job.cancelled) {
      item.status = result.success ? 'completed' : 'cancelled';
      if (result.success) {
        item.filePath = result.path;
        item.converted = !!result.converted;
      }
      break;
    }
    if (job.skipCurrent) {
      job.skipCurrent = false;
      item.status = 'skipped';
      broadcastQueue();
      continue;
    }
    if (result.success) {
      item.status = 'completed';
      item.filePath = result.path;
      item.converted = !!result.converted;
    } else {
      item.status = 'error';
      item.error = result.error;
    }
    broadcastQueue();
  }

  const completedCount = job.items.filter(it => it.status === 'completed').length;
  const errorCount = job.items.filter(it => it.status === 'error').length;

  // Even if cancelled midway, keep a history record of the videos that finished
  addPlaylistHistoryItem(job);

  if (job.cancelled) {
    job.status = 'cancelled';
    safeSend('job-finished', { jobId: job.id, kind: 'playlist', success: false, cancelled: true, completedCount, errorCount, path: job.targetDir });
  } else {
    job.status = completedCount > 0 || errorCount === 0 ? 'completed' : 'error';
    safeSend('job-finished', { jobId: job.id, kind: 'playlist', success: job.status === 'completed', completedCount, errorCount, path: job.targetDir });
  }
}

// ===========================================================================
// GENERIC FILE DOWNLOADS (browser extension → ukdownloader:// protocol)
// No local HTTP server: the extension opens a custom protocol URL, and the
// app queues a plain http(s) download with the same hidden-temp / resume /
// quota / parallel / no-history rules as every other job.
// ===========================================================================
const MIME_EXT = {
  'application/zip': 'zip', 'application/x-7z-compressed': '7z',
  'application/x-rar-compressed': 'rar', 'application/pdf': 'pdf',
  'application/octet-stream': 'bin', 'application/msword': 'doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
  'application/vnd.ms-excel': 'xls',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
  'application/json': 'json', 'text/plain': 'txt', 'text/csv': 'csv',
  'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp',
  'image/gif': 'gif', 'audio/mpeg': 'mp3', 'video/mp4': 'mp4',
  'application/x-msdownload': 'exe', 'application/x-apple-diskimage': 'dmg',
  'application/vnd.android.package-archive': 'apk',
};

function contentDispositionName(cd) {
  if (!cd) return '';
  let m = cd.match(/filename\*\s*=\s*UTF-8''([^;]+)/i);
  if (m) { try { return decodeURIComponent(m[1].replace(/["']/g, '').trim()); } catch (e) {} }
  m = cd.match(/filename\s*=\s*"?([^";]+)"?/i);
  return m ? m[1].trim() : '';
}

function genericNameParts(hint, url, mime) {
  let raw = String(hint || '');
  if (!raw) {
    try { raw = decodeURIComponent(new URL(url).pathname.split('/').pop() || ''); } catch (e) { raw = ''; }
  }
  raw = raw.split(/[\\/]/).pop() || 'download';
  raw = raw.replace(/[\\/:*?"<>|\x00-\x1f\x7f]/g, '_').replace(/\s+/g, ' ').trim();
  let stem = raw, ext = '';
  const m = raw.match(/^(.*)\.([a-z0-9]{1,8})$/i);
  if (m) { stem = m[1]; ext = m[2].toLowerCase(); }
  if (!ext) {
    const ct = String(mime || '').split(';')[0].trim().toLowerCase();
    ext = MIME_EXT[ct] || 'bin';
  }
  stem = safeFileStem(stem, ext);
  return { stem, ext, fileName: `${stem}.${ext}` };
}

function enqueueGenericFileDownload(rawUrl, hintName, source = 'extension') {
  let u;
  try { u = new URL(rawUrl); } catch (e) { return { success: false, error: 'Invalid download URL.' }; }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') {
    return { success: false, error: 'Only http(s) links can be sent to UK Downloader.' };
  }
  const gate = canQueueDownloads(1);
  if (!gate.ok) return { success: false, error: gate.error, limitReached: true };
  reserveVideos(1);

  const settings = { ...DEFAULT_VIDEO_SETTINGS, ...(store.get(VIDEO_SETTINGS_KEY, {}) || {}) };
  const targetDir = settings.directSaveDir || app.getPath('downloads');
  try { fs.mkdirSync(targetDir, { recursive: true }); }
  catch (e) { releaseVideos(1); return { success: false, error: e.message }; }

  const { stem, ext, fileName } = genericNameParts(hintName, rawUrl, '');
  const filePath = resolveOutputPath(targetDir, stem, ext, true);
  const workDir = createWorkDir(filePath, `file-${Date.now()}`);
  const partPath = workDir ? path.join(workDir, `${fileName}.part`) : `${filePath}.part`;
  const job = {
    id: `job-${++jobSeq}-${Date.now()}`,
    kind: 'file',
    status: 'queued',
    createdAt: Date.now(),
    reservedCount: 1,
    url: rawUrl,
    title: fileName,
    fileName,
    thumbnailUrl: '',
    filePath,
    workDir,
    partPath,
    sizeBytes: 0,
    formatLabel: 'FILE',
    source,
    progress: null,
  };
  downloadQueue.push(job);
  broadcastQueue();
  processQueue();
  return { success: true, jobId: job.id };
}

/** Stream one http(s) file into a hidden .part file, then rename on success. */
function runGenericFileJob(job) {
  return new Promise((resolve) => {
    const https = require('https');
    const http = require('http');
    let cancelled = false;
    let preserveForResume = false;
    let req = null;
    let stream = null;
    let redirects = 0;
    let received = 0;
    let total = 0;
    let startedAt = Date.now();
    let lastAt = startedAt;
    let lastBytes = 0;

    const ctl = {
      cancel: (_keep, opts = {}) => {
        cancelled = true;
        if (opts && opts.preserveForResume) preserveForResume = true;
        try { req && req.destroy(); } catch (e) {}
        try { stream && stream.destroy(); } catch (e) {}
      },
      cleanupNow: () => {
        if (preserveForResume) return;
        try { job.partPath && fs.existsSync(job.partPath) && fs.unlinkSync(job.partPath); } catch (e) {}
        removeWorkDir(job.workDir);
        job.workDir = null;
      },
      get isPaused() { return false; },
      get pauseReason() { return null; },
      get stage() { return 'downloading'; },
      pause() {}, resume() {},
    };
    jobControls.set(controlKey(job.id, null), ctl);

    const sendProgress = (extra) => safeSend('download-progress', {
      jobId: job.id, itemId: null, stage: 'downloading', ...extra,
    });

    const finish = (result) => {
      if (!result || result.success === false) {
        job.status = result?.cancelled ? 'cancelled' : 'error';
        job.error = result?.error || (result?.cancelled ? 'Cancelled' : 'Download failed');
        if (!result?.cancelled && !preserveForResume) {
          try { job.partPath && fs.existsSync(job.partPath) && fs.unlinkSync(job.partPath); } catch (e) {}
        }
        safeSend('job-finished', {
          jobId: job.id, kind: 'file', success: false,
          cancelled: !!result?.cancelled, error: job.error,
        });
      }
      if (!preserveForResume) {
        removeWorkDir(job.workDir);
        job.workDir = null;
      }
      jobControls.delete(controlKey(job.id, null));
      resolve(result);
    };

    const request = (urlStr, useRange) => {
      if (cancelled) return finish({ success: false, cancelled: true });
      if (redirects++ > 6) return finish({ success: false, error: 'Too many redirects.' });
      let u;
      try { u = new URL(urlStr); } catch (e) { return finish({ success: false, error: 'Bad URL.' }); }
      const mod = u.protocol === 'https:' ? https : http;
      const headers = { 'User-Agent': 'UK-Downloader/2.0.1', 'Accept': '*/*' };
      if (useRange && fs.existsSync(job.partPath)) {
        const off = fs.statSync(job.partPath).size;
        if (off > 0) headers.Range = `bytes=${off}-`;
        received = off;
      }
      req = mod.get(u, { headers }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          res.resume();
          request(new URL(res.headers.location, urlStr).toString(), useRange);
          return;
        }
        if (res.statusCode >= 400) {
          res.resume();
          return finish({ success: false, error: `HTTP ${res.statusCode}` });
        }
        const cd = res.headers['content-disposition'] || '';
        const ct = res.headers['content-type'] || '';
        const cdName = contentDispositionName(cd);
        if (cdName) {
          const parts = genericNameParts(cdName, urlStr, ct);
          if (parts.fileName !== job.fileName) {
            job.fileName = parts.fileName;
            job.title = parts.fileName;
            job.filePath = path.join(path.dirname(job.filePath), parts.fileName);
            job.partPath = job.workDir ? path.join(job.workDir, `${parts.fileName}.part`) : `${job.filePath}.part`;
          }
        }
        const len = Number(res.headers['content-length']) || 0;
        const partial = res.statusCode === 206;
        total = partial ? received + len : len;
        job.sizeBytes = total;
        if (partial) job.resume = true;
        const mode = partial ? 'a' : 'w';
        try {
          stream = fs.createWriteStream(job.partPath, { flags: mode });
        } catch (e) { res.resume(); return finish({ success: false, error: e.message }); }

        res.on('data', (chunk) => {
          if (cancelled) return;
          received += chunk.length;
          const now = Date.now();
          if (now - lastAt > 350 || received === total) {
            const dt = Math.max(0.1, (now - lastAt) / 1000);
            const speed = Math.max(0, (received - lastBytes) / dt);
            lastAt = now; lastBytes = received;
            const percent = total > 0 ? Math.min(100, (received / total) * 100) : 0;
            const p = { percent, downloadedBytes: received, totalBytes: total, speed };
            job.progress = p; sendProgress(p);
            broadcastQueue();
          }
        });
        res.on('error', (err) => finish({ success: false, error: err.message }));
        stream.on('error', (err) => finish({ success: false, error: err.message }));
        stream.on('finish', () => {
          if (cancelled) return finish({ success: false, cancelled: true });
          try {
            fs.mkdirSync(path.dirname(job.filePath), { recursive: true });
            fs.renameSync(job.partPath, job.filePath);
          } catch (e) { return finish({ success: false, error: e.message }); }
          job.status = 'completed';
          sendProgress({ percent: 100, downloadedBytes: received, totalBytes: received, speed: 0, stage: 'done' });
          safeSend('job-finished', { jobId: job.id, kind: 'file', success: true, path: job.filePath });
          finish({ success: true, path: job.filePath });
        });
        res.pipe(stream);
      });
      req.on('error', (err) => finish({ success: false, error: err.message }));
    };

    request(job.url, !!job.resume);
  });
}

function processQueue() {
  // Jobs can be queued while yt-dlp is self-updating — hold them until the
  // binary is stable again (updateYtDlp re-kicks the queue when done).
  if (isUpdatingYtDlp) return;
  const limit = getParallelLimit();

  // Dispatch synchronously up to the limit; each job then runs in its own
  // async task. The map makes the slot count visible to re-entrant calls.
  while (activeJobs.size < limit) {
    const next = downloadQueue.find(j => j.status === 'queued');
    if (!next) break;

    activeJobs.set(next.id, next);
    next.status = 'downloading';
    broadcastQueue();

    (async () => {
      try {
        if (next.kind === 'video') {
          await runVideoJob(next);
        } else if (next.kind === 'file') {
          await runGenericFileJob(next);
        } else {
          await runPlaylistJob(next);
        }
      } catch (err) {
        console.error('Job processing error:', err);
        next.status = 'error';
        next.error = err.message;
        safeSend('job-finished', { jobId: next.id, kind: next.kind, success: false, error: err.message });
      } finally {
        activeJobs.delete(next.id);
        // Finished jobs leave the list immediately. There is no persistent
        // history in this build — the files on disk are the only record.
        removeJobFromQueue(next.id);
        processQueue();
      }
    })();
  }
}

// --- Queue IPC -------------------------------------------------------------

ipcMain.handle('get-queue', () => downloadQueue.map(serializeJob));

ipcMain.handle('queue-video', async (event, options) => {
  const { videoId, url, quality, qualityLabel, type, title, thumbnailUrl, convertToH264, sizeBytes, meta, playlistIndex } = options;
  const ext = type === 'mp4' ? 'mp4' : 'mp3';
  const numberedTitle = numberedPlaylistTitle(title, playlistIndex);
  // Same byte budget as resolveOutputPath: the dialog's default name becomes
  // the real filename, so an over-long one fails at write time, not here.
  const safeTitle = safeFileStem(numberedTitle, ext);

  // “Direct save”: single videos go straight into the configured folder with
  // no Save dialog — that is what makes one click enough on the details page.
  let directPath = null;
  if (options.direct && options.targetDir) {
    try {
      fs.mkdirSync(options.targetDir, { recursive: true });
      directPath = resolveOutputPath(options.targetDir, numberedTitle, ext, true);
    } catch (e) {
      console.error('Direct save path failed, falling back to the dialog:', e.message);
      directPath = null;
    }
  }

  let chosenPath = directPath;
  if (!chosenPath) {
    const dialogResult = await dialog.showSaveDialog(mainWindow, {
      title: `Save ${type.toUpperCase()}`,
      defaultPath: `${safeTitle}.${ext}`,
      buttonLabel: "Save",
      filters: type === 'mp4' ? [{ name: "MPEG-4 Video", extensions: ["mp4"] }] : [{ name: "MP3 Audio", extensions: ["mp3"] }],
    });
    if (dialogResult.canceled || !dialogResult.filePath) {
      return { success: false, canceled: true, error: "Save dialog was canceled." };
    }
    chosenPath = dialogResult.filePath;
  }

  // Gate after the dialog so a cancelled Save does not consume today's quota.
  const gate = canQueueDownloads(1);
  if (!gate.ok) return { success: false, error: gate.error, limitReached: true };
  reserveVideos(1);

  const job = {
    id: `job-${++jobSeq}-${Date.now()}`,
    kind: 'video',
    status: 'queued',
    createdAt: Date.now(),
    reservedCount: 1,
    videoId,
    url,
    title,
    thumbnailUrl,
    quality,
    qualityLabel,
    type,
    convertToH264: !!convertToH264,
    filePath: chosenPath,
    sizeBytes: sizeBytes || 0,
    formatLabel: type === 'mp3'
      ? 'AUDIO (MP3)'
      : `${qualityLabel || (isHdQuality(quality) ? HD_PRESETS[String(quality)].label : 'MP4')} (MP4)`,
    meta: meta || null,
    progress: null,
  };

  downloadQueue.push(job);
  broadcastQueue();
  processQueue();
  return { success: true, jobId: job.id };
});

/**
 * Drag & drop / bulk direct download. Every link becomes its own video job, so
 * the 2 / 4 / 8 / 16 / 32 (custom 1–64) parallel limit applies to them. Free users still get only the
 * first N that fit the 10/day quota; Pro users get the whole drop.
 */
ipcMain.handle('queue-video-batch', async (event, options = {}) => {
  let items = Array.isArray(options.items) ? options.items : [];
  if (items.length === 0) return { success: false, error: 'No videos to download.' };

  const keyword = safeKeyword(options.keyword);
  const settings = { ...DEFAULT_VIDEO_SETTINGS, ...(store.get(VIDEO_SETTINGS_KEY, {}) || {}) };
  const targetDir = options.targetDir || settings.directSaveDir || app.getPath('downloads');
  try {
    fs.mkdirSync(targetDir, { recursive: true });
  } catch (e) {
    return { success: false, error: `Could not create the download folder: ${e.message}` };
  }

  let partial = null;
  const state = getLicenseState();
  if (!state.isPro) {
    const remaining = Math.max(0, state.dailyLimit - state.dailyCount - reservedVideoCount);
    if (remaining === 0) {
      safeSend('daily-limit-reached', state);
      return {
        success: false, limitReached: true,
        error: `Daily limit reached (${state.dailyCount}/${state.dailyLimit} videos today). Enter a Pro key to continue.`,
      };
    }
    if (items.length > remaining) {
      const total = items.length;
      const skipped = total - remaining;
      items = items.slice(0, remaining);
      partial = { queued: items.length, skipped, total };
      safeSend('app-notice', {
        kind: 'warning',
        text: `Daily limit: ${items.length} of ${total} videos queued; ${skipped} skipped. Activate a Pro key for the whole drop.`,
      });
    }
  }

  const gate = canQueueDownloads(items.length);
  if (!gate.ok) return { success: false, error: gate.error, limitReached: true };
  reserveVideos(items.length);

  // A keyword search gets one Windows-safe folder named after the term. A
  // folder or picture failure must never stop the videos themselves.
  let jobTargetDir = targetDir;
  if (keyword) {
    try {
      jobTargetDir = ensureKeywordFolder(targetDir, keyword);
    } catch (error) {
      console.log('Keyword folder unavailable (non-critical):', error?.message || error);
    }
  }

  const jobIds = [];
  for (const item of items) {
    const type = item.type === 'mp3' ? 'mp3' : 'mp4';
    const quality = item.quality || (type === 'mp3' ? 'best' : 'hd720');
    const qualityLabel = item.qualityLabel || (type === 'mp3' ? 'MP3' : (isHdQuality(quality) ? HD_PRESETS[String(quality)].label : 'MP4'));
    const ext = type === 'mp3' ? 'mp3' : 'mp4';
    const numberedTitle = numberedPlaylistTitle(item.title || 'video', item.playlistIndex);
    const filePath = resolveOutputPath(jobTargetDir, numberedTitle, ext, true);
    const job = {
      id: `job-${++jobSeq}-${Date.now()}`,
      kind: 'video',
      status: 'queued',
      createdAt: Date.now(),
      reservedCount: 1,
      videoId: item.videoId || null,
      url: item.url,
      title: item.title || 'Untitled video',
      thumbnailUrl: item.thumbnailUrl || '',
      quality,
      qualityLabel,
      type,
      convertToH264: !!item.convertToH264,
      filePath,
      sizeBytes: Number(item.sizeBytes) || 0,
      formatLabel: type === 'mp3' ? 'AUDIO (MP3)' : `${qualityLabel} (MP4)`,
      meta: item.meta || null,
      progress: null,
    };
    downloadQueue.push(job);
    jobIds.push(job.id);
  }

  if (keyword && jobTargetDir !== targetDir && items.length) {
    queueKeywordThumbnailUpdate(jobTargetDir,
      keywordThumbnailCandidates(items[0].thumbnailUrl, items[0].videoId));
  }

  broadcastQueue();
  processQueue();
  return partial
    ? { success: true, queued: items.length, jobIds, partial: true, ...partial }
    : { success: true, queued: items.length, jobIds };
});

/**
 * Keyword / song search. A plain-text query becomes ytsearchN:<query>; the
 * first N results are queued as direct downloads using the global quality,
 * parallel and daily-limit rules.
 */
ipcMain.handle('queue-keyword-search', async (event, options = {}) => {
  if (isUpdatingYtDlp) {
    return { success: false, error: 'yt-dlp is updating. Try again shortly.' };
  }

  if (!options || typeof options !== 'object' || typeof options.query !== 'string') {
    return { success: false, error: 'Invalid keyword. Type a song name or keyword first.' };
  }
  const query = options.query.trim().replace(/\s+/g, ' ').slice(0, 200);
  if (!query || /^\[object .+\]$/i.test(query)) {
    return { success: false, error: 'Invalid keyword. Type a song name or keyword first.' };
  }
  if (/^https?:\/\//i.test(query)) return { success: false, error: 'That looks like a link. Paste it normally instead.' };

  const settings = { ...DEFAULT_VIDEO_SETTINGS, ...(store.get(VIDEO_SETTINGS_KEY, {}) || {}) };
  const requested = Math.round(Number(options.limit) || Number(settings.keywordLimit) || DEFAULT_VIDEO_SETTINGS.keywordLimit);
  const limit = Math.min(KEYWORD_LIMIT_MAX, Math.max(KEYWORD_LIMIT_MIN, Number.isFinite(requested) ? requested : 1));

  const targetDir = options.targetDir || settings.directSaveDir || app.getPath('downloads');
  try {
    fs.mkdirSync(targetDir, { recursive: true });
  } catch (e) {
    return { success: false, error: `Could not create the download folder: ${e.message}` };
  }

  let info;
  try {
    // --yes-playlist overrides BASE_ARGS' --no-playlist so ytsearchN returns
    // every requested hit instead of being collapsed to one video.
    info = await runYtDlpJson(`ytsearch${limit}:${query}`, [
      '--flat-playlist',
      '--ignore-errors',
      '--yes-playlist',
    ], true);
  } catch (error) {
    return { success: false, error: error.message || 'YouTube search failed.' };
  }

  const rawEntries = Array.isArray(info.entries) ? info.entries : (info.id ? [info] : []);
  const seen = new Set();
  let items = rawEntries
    .filter(e => e && e.id && e.title && e.title !== '[Private video]' && e.title !== '[Deleted video]')
    .map(e => {
      const id = String(e.id);
      const raw = e.url || e.webpage_url || '';
      let url;
      if (/^https?:\/\//i.test(raw)) url = raw;
      else if (raw.startsWith('/')) url = `https://www.youtube.com${raw}`;
      else url = `https://www.youtube.com/watch?v=${id}`;
      const thumbnailUrl = e.thumbnails?.length
        ? e.thumbnails[e.thumbnails.length - 1].url
        : `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;
      return { videoId: id, url, title: e.title, thumbnailUrl, duration: e.duration || 0 };
    })
    .filter(item => {
      if (seen.has(item.videoId)) return false;
      seen.add(item.videoId);
      return true;
    })
    .slice(0, limit);

  if (items.length === 0) {
    return { success: false, error: `No YouTube results found for "${query}".` };
  }

  let partial = null;
  const state = getLicenseState();
  if (!state.isPro) {
    const remaining = Math.max(0, state.dailyLimit - state.dailyCount - reservedVideoCount);
    if (remaining === 0) {
      safeSend('daily-limit-reached', state);
      return {
        success: false, limitReached: true,
        error: `Daily limit reached (${state.dailyCount}/${state.dailyLimit} videos today). Enter a Pro key to continue.`,
      };
    }
    if (items.length > remaining) {
      const total = items.length;
      const skipped = total - remaining;
      items = items.slice(0, remaining);
      partial = { queued: items.length, skipped, total };
      safeSend('app-notice', {
        kind: 'warning',
        text: `Daily limit: ${items.length} of ${total} keyword results queued; ${skipped} skipped. Activate a Pro key for the full limit.`,
      });
    }
  }

  const gate = canQueueDownloads(items.length);
  if (!gate.ok) return { success: false, error: gate.error, limitReached: true };
  reserveVideos(items.length);

  const preset = settings.defaultQuality || 'hd720';
  const wantsMp3 = preset === 'mp3';
  const quality = (preset === 'ask' || wantsMp3) ? 'hd720' : preset;
  const qualityLabel = wantsMp3 ? 'MP3' : quality === 'hd720' ? '720p HD' : quality === 'hd480' ? '480p HD' : 'Best';
  const type = wantsMp3 ? 'mp3' : 'mp4';
  const ext = wantsMp3 ? 'mp3' : 'mp4';
  const jobIds = [];
  for (const item of items) {
    const filePath = resolveOutputPath(targetDir, item.title || 'video', ext, true);
    const job = {
      id: `job-${++jobSeq}-${Date.now()}`,
      kind: 'video',
      status: 'queued',
      createdAt: Date.now(),
      reservedCount: 1,
      videoId: item.videoId,
      url: item.url,
      title: item.title,
      thumbnailUrl: item.thumbnailUrl || '',
      quality,
      qualityLabel,
      type,
      convertToH264: false,
      filePath,
      sizeBytes: 0,
      formatLabel: type === 'mp3' ? 'AUDIO (MP3)' : `${qualityLabel} (MP4)`,
      meta: { source: 'keyword', query },
      progress: null,
    };
    downloadQueue.push(job);
    jobIds.push(job.id);
  }

  broadcastQueue();
  processQueue();
  return partial
    ? { success: true, query, limit, queued: items.length, jobIds, partial: true, ...partial }
    : { success: true, query, limit, queued: items.length, jobIds };
});

ipcMain.handle('keyword-page:scan', async (event, options = {}) => {
  if (isUpdatingYtDlp) {
    return { success: false, error: 'yt-dlp is updating. Try again shortly.' };
  }

  let opts;
  try {
    opts = normalizeKeywordScanOptions(options, Date.now());
  } catch (error) {
    return { success: false, error: error.message || 'Invalid keyword scan.' };
  }

  const args = [
    '--flat-playlist',
    '--ignore-errors',
    '--yes-playlist',
    '--playlist-end', String(opts.limit),
    // Flat search entries normally lack upload_date; approximate_date lets the
    // strict local time cutoff work without fetching every video one by one.
    '--extractor-args', 'youtubetab:approximate_date',
  ];
  if (opts.dateAfter) args.push('--dateafter', opts.dateAfter);

  let info;
  try {
    info = await runYtDlpJson(opts.searchUrl, args, true);
  } catch (error) {
    // YouTube sometimes changes/ignores an `sp` upload-date token. Retry the
    // ordinary search URL; the helper's local cutoff still enforces the date.
    if (opts.timeFilter === 'any') {
      return { success: false, error: error.message || 'YouTube search failed.' };
    }
    try {
      info = await runYtDlpJson(buildKeywordSearchUrl(opts.query, 'any'), args, true);
    } catch (fallbackError) {
      return { success: false, error: fallbackError.message || 'YouTube search failed.' };
    }
  }

  const summary = summarizeKeywordEntries(info, opts, opts.now);
  return {
    success: true,
    query: opts.query,
    pages: opts.pages,
    timeFilter: opts.timeFilter,
    timeLabel: opts.timeLabel,
    resultsPerPage: 20,
    ...summary,
  };
});

ipcMain.handle('queue-playlist', async (event, options) => {
  const { title, uploader, url, targetDir, allowDuplicates, formatLabel, thumbnailUrl } = options;
  let items = options.items;
  if (!targetDir) return { success: false, error: 'No destination folder selected.' };
  if (!Array.isArray(items) || items.length === 0) return { success: false, error: 'No videos selected.' };

  // A big playlist must still download: free users get the first N videos
  // that fit today's quota, the rest are skipped with a clear GUI notice.
  // Pro users always get the whole playlist.
  let partial = null;
  const state = getLicenseState();
  if (!state.isPro) {
    const remaining = Math.max(0, state.dailyLimit - state.dailyCount - reservedVideoCount);
    if (remaining === 0) {
      safeSend('daily-limit-reached', state);
      return {
        success: false, limitReached: true,
        error: `Daily limit reached (${state.dailyCount}/${state.dailyLimit} videos today). Enter a Pro key to continue.`,
      };
    }
    if (items.length > remaining) {
      const total = items.length;
      const skipped = total - remaining;
      items = items.slice(0, remaining);
      partial = { queued: items.length, skipped, total };
      safeSend('app-notice', {
        kind: 'warning',
        text: `Daily limit: ${items.length} of ${total} videos queued; ${skipped} skipped. Activate a Pro key for the whole playlist.`,
      });
    }
  }

  const gate = canQueueDownloads(items.length);
  if (!gate.ok) return { success: false, error: gate.error, limitReached: true };
  reserveVideos(items.length);

  const job = {
    id: `job-${++jobSeq}-${Date.now()}`,
    kind: 'playlist',
    status: 'queued',
    createdAt: Date.now(),
    reservedCount: items.length,
    title,
    uploader,
    url: url || '',
    thumbnailUrl: thumbnailUrl || items[0]?.thumbnail || '',
    targetDir,
    allowDuplicates: !!allowDuplicates,
    formatLabel: formatLabel || 'MP4',
    sizeBytes: items.reduce((acc, it) => acc + (it.sizeBytes || 0), 0),
    currentIndex: -1,
    cancelled: false,
    skipCurrent: false,
    items: items.map(it => ({
      id: it.id,
      url: it.url,
      title: it.title,
      playlistIndex: it.playlistIndex ?? null,
      thumbnail: it.thumbnail,
      duration: it.duration || 0,
      quality: it.quality,
      qualityLabel: it.qualityLabel,
      type: it.type || 'mp4',
      convertToH264: !!it.convertToH264,
      sizeBytes: it.sizeBytes || 0,
      status: 'queued',
      filePath: null,
    })),
    progress: null,
  };

  downloadQueue.push(job);
  broadcastQueue();
  processQueue();
  return partial
    ? { success: true, jobId: job.id, partial: true, ...partial }
    : { success: true, jobId: job.id };
});

ipcMain.on('cancel-job', (event, { jobId, keepOriginal } = {}) => {
  const job = downloadQueue.find(j => j.id === jobId);
  if (!job) return;
  if (job.status === 'queued') {
    removeJobFromQueue(jobId);
    safeSend('job-finished', { jobId, kind: job.kind, success: false, cancelled: true });
    return;
  }
  if (activeJobs.has(jobId)) {
    job.cancelled = true;
    forEachJobControl(jobId, ctl => ctl.cancel(!!keepOriginal));
  }
});

// Skip only the currently-downloading video of a playlist job
ipcMain.on('skip-playlist-item', (event, { jobId } = {}) => {
  const job = downloadQueue.find(j => j.id === jobId);
  if (!job || !activeJobs.has(jobId) || job.kind !== 'playlist') return;
  job.skipCurrent = true;
  forEachJobControl(jobId, ctl => ctl.cancel(false));
});

ipcMain.handle('cancel-all-jobs', () => {
  const all = [...downloadQueue];
  for (const job of all) {
    job.cancelled = true;
    if (activeJobs.has(job.id)) {
      forEachJobControl(job.id, ctl => {
        ctl.cancel(false);
        ctl.cleanupNow();
      });
    }
    releaseJobReservation(job);
  }
  downloadQueue = [];
  activeJobs.clear();
  jobControls.clear();
  clearResumeQueue();
  broadcastQueue();
  for (const job of all) {
    safeSend('job-finished', { jobId: job.id, kind: job.kind, success: false, cancelled: true });
  }
  return { success: true, cancelled: all.length };
});

// Auto-subscribe toggle shown on the Playlist page (default ON).
ipcMain.handle('get-auto-subscribe-dropped', () => !!store.get(AUTO_SUBSCRIBE_KEY, true));
ipcMain.handle('set-auto-subscribe-dropped', (event, enabled) => {
  const next = !!enabled;
  store.set(AUTO_SUBSCRIBE_KEY, next);
  return next;
});

ipcMain.on("pause-download", () => {
  for (const ctl of jobControls.values()) ctl.pause('user');
});

ipcMain.on("resume-download", () => {
  for (const ctl of jobControls.values()) ctl.resume();
});

// ===========================================================================
// SUBSCRIPTIONS
// Follow a playlist (or a channel's uploads feed) and let UK Downloader grab the
// videos that show up in it afterwards — automatically, into a folder you pick,
// at a quality you pick.
//
// Model
//   ONE anchor per playlist: `last_video_id`. A scan reads the newest 50 flat
//   entries (metadata only — never a video file), finds the anchor by id and
//   treats everything above it as new. That list is then downloaded OLDEST
//   FIRST, one video at a time, and the anchor moves to a video only once that
//   video has downloaded and ffprobe verified it. A failed download or a failed
//   scan leaves the anchor exactly where it was, so nothing can be skipped.
//   No id history is stored anywhere: the JSON file is
//     { "subscriptions": [ { name, url, last_video_id, enabled, … } ] }
//
// Scheduling
//   A 15s tick drives the scan engine while it is running. Each subscription is
//   scanned when its own interval has elapsed; scans run one at a time (yt-dlp
//   start-up is the expensive part and downloads share the same queue). The
//   engine pauses while yt-dlp is self-updating.
// ===========================================================================
const SUBS_FILE = 'subscriptions.json';
const SUBS_KEY_LEGACY = 'subscriptions';
const SUBSCAN_KEY = 'subscriptionScanV1';
const SUB_TICK_MS = 15 * 1000;   // engine granularity
const SCAN_DEPTH = 50;           // newest N flat entries read per scan
const ANCHOR_MISSING_MAX = 10;   // fallback batch when the anchor vanished
const MAX_AUTO_ATTEMPTS = 3;     // retries before a bad video stops the batch
const SUB_NEW_KEEP = 30;         // detected (not downloaded) rows kept for the UI
const SUB_INTERVAL_CHOICES = [5, 15, 30, 60, 180];
const SUB_QUALITIES = ['best', 'hd720', 'hd480', '2160', '1440', '1080', '720', '480', '360'];

let subTimer = null;
let subChecking = false;              // one sweep at a time
const subBusyIds = new Set();         // per-subscription re-entrancy guard
const subPumpBusy = new Set();        // one enqueue in flight per subscription
const folderThumbLocks = new Map();   // one FOLDER.JPG refresh per folder at a time
let subsCache = null;                 // in-memory copy of the JSON file

// ---------------------------------------------------------------------------
// Storage — one JSON document, replaced atomically
// ---------------------------------------------------------------------------

function subscriptionsFile() {
  return path.join(app.getPath('userData'), SUBS_FILE);
}

function getSubscriptions() {
  if (subsCache) return subsCache;
  try {
    subsCache = readSubscriptionsFile(subscriptionsFile());
  } catch (error) {
    console.log('Could not read subscriptions.json (starting empty):', error.message);
    subsCache = [];
  }
  return subsCache;
}

/** Persist the whole list by atomic replacement and tell the GUI. */
function saveSubscriptions(list, { emit = true } = {}) {
  subsCache = Array.isArray(list) ? list : [];
  try {
    saveSubscriptionsFile(subscriptionsFile(), subsCache);
  } catch (error) {
    console.log('Could not write subscriptions.json:', error.message);
  }
  if (emit) safeSend('subscriptions-updated', subsCache);
  return subsCache;
}

/** Read-modify-write helper: `mutator(list)` may edit the array in place. */
function mutateSubscriptions(mutator, { emit = true } = {}) {
  const list = getSubscriptions();
  const result = mutator(list);
  saveSubscriptions(list, { emit });
  return result;
}

function updateSubscription(id, patch, { silent = false } = {}) {
  const list = getSubscriptions();
  const idx = list.findIndex(s => s.id === id);
  if (idx === -1) return null;
  const previousTargetDir = list[idx].targetDir;
  list[idx] = { ...list[idx], ...patch, updatedAt: Date.now() };
  if (patch.targetDir && patch.targetDir !== previousTargetDir) {
    list[idx].targetDir = patch.targetDir;
    list[idx].folderPath = null;
    try {
      syncSubscriptionFolder(list[idx], { create: true, others: list });
    } catch (error) {
      console.log('Could not create the new subscription folder:', error.message);
    }
  }
  saveSubscriptions(list, { emit: !silent });
  return list[idx];
}

/**
 * One-time move from the old storage (electron-store key `subscriptions`, with
 * `knownIds` arrays) to the anchor file. The newest known id becomes the
 * anchor; the id list itself is dropped for good.
 */
function migrateSubscriptions() {
  const file = subscriptionsFile();
  const fromFile = fs.existsSync(file);
  let list = getSubscriptions();

  if (!fromFile) {
    const legacy = store.get(SUBS_KEY_LEGACY, []);
    if (Array.isArray(legacy) && legacy.length) list = legacy.map(normalizeRecord);
  }

  let changed = !fromFile;
  for (const sub of list) {
    if (!sub.id) {
      sub.id = `sub-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
      changed = true;
    }
    if (!sub.lastVideoId && Array.isArray(sub.knownIds) && sub.knownIds.length) {
      sub.lastVideoId = String(sub.knownIds[0] || '');
      changed = true;
    }
    const carry = Array.isArray(sub.newVideos) ? sub.newVideos.filter(v => v && v.id && v.status !== 'downloaded') : [];
    if (carry.length !== (sub.newVideos || []).length) {
      sub.newVideos = carry;
      changed = true;
    }
    for (const key of ['knownIds', 'knownIdsComplete', 'knownCount', 'pendingCount']) {
      if (key in sub) {
        delete sub[key];
        changed = true;
      }
    }
    if (!Array.isArray(sub.newVideos)) {
      sub.newVideos = [];
      changed = true;
    }
  }

  if (changed) {
    saveSubscriptions(list, { emit: false });
    // The old key must never be read again.
    try { store.delete(SUBS_KEY_LEGACY); } catch (e) { /* already gone */ }
    console.log(`Subscriptions: migrated ${list.length} playlist(s) to last-video-id storage`);
  }
  return changed;
}

// ---------------------------------------------------------------------------
// Folders + folder picture (unchanged behaviour)
// ---------------------------------------------------------------------------

/** Parent directory for a subscription's own named subfolder. */
function subscriptionParentDir(sub) {
  return sub?.targetDir || store.get('lastSubscriptionDir', '') || app.getPath('downloads');
}

/**
 * Make sure `sub.folderName` / `sub.folderPath` exist, are unique among the
 * other subscriptions and point at a real directory. A changed targetDir moves
 * future output to a newly created subfolder; a changed TITLE does not rename
 * an existing folder (its downloaded videos must stay put).
 */
function syncSubscriptionFolder(sub, { create = true, others = null } = {}) {
  const parent = subscriptionParentDir(sub);
  if (sub.targetDir !== parent) sub.targetDir = parent;
  const list = Array.isArray(others) ? others : getSubscriptions();
  const name = sub.folderName || safeFolderName(sub.title || sub.uploader || 'Playlist');
  const taken = list
    .filter(s => s && s.id !== sub.id && s.folderPath)
    .map(s => s.folderPath);
  const currentParent = sub.folderPath ? path.dirname(sub.folderPath) : '';
  const sameParent = currentParent &&
    path.resolve(currentParent).toLowerCase() === path.resolve(parent).toLowerCase();
  const folderPath = sameParent ? sub.folderPath : uniqueFolderPath(parent, name, taken);
  sub.folderName = name;
  sub.folderPath = folderPath;
  if (create) ensureFolder(folderPath);
  return folderPath;
}

/** Backfill folders for subscriptions created by older builds / imports. */
function ensureAllSubscriptionFolders({ emit = false, persist = true, sourceList = null } = {}) {
  const list = Array.isArray(sourceList) ? sourceList : getSubscriptions();
  let changed = false;
  for (const sub of list) {
    if (!sub || typeof sub !== 'object') continue;
    if (!sub.id) {
      sub.id = `sub-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
      changed = true;
    }
    const before = [sub.targetDir, sub.folderName, sub.folderPath].join('|');
    try {
      syncSubscriptionFolder(sub, { create: true, others: list });
    } catch (error) {
      console.log('Subscription folder setup failed (non-critical):', sub.id, error.message);
    }
    if (before !== [sub.targetDir, sub.folderName, sub.folderPath].join('|')) changed = true;
  }
  if (changed && persist) saveSubscriptions(list, { emit });
  return list;
}

/** Ordered thumbnail URLs, with a YouTube video-id fallback. */
function subscriptionThumbnailCandidates(video, sub) {
  const raw = video?.thumbnail || video?.thumbnailUrl || sub?.thumbnail || '';
  const out = [];
  const push = (items) => {
    for (const item of items) if (item && !out.includes(item)) out.push(item);
  };
  if (raw) push(thumbnailCandidates(raw));
  const videoUrl = video?.url || sub?.url || '';
  const id = String(video?.id || '');
  if (isYouTubeUrl(videoUrl) && /^[A-Za-z0-9_-]{11}$/.test(id)) {
    push(thumbnailCandidates(`https://i.ytimg.com/vi/${id}/hqdefault.jpg`));
  }
  return out;
}

/** Download the newest video's thumbnail and replace FOLDER.JPG. */
async function updateSubscriptionFolderThumbnail(folderPath, video, sub) {
  const candidates = subscriptionThumbnailCandidates(video, sub);
  if (!candidates.length) throw new Error('No thumbnail URL for this video.');
  return replaceFolderThumbnail({
    folderPath,
    candidates,
    fetchImage: (url) => fetchImageBuffer(url, 8000),
    writeJpeg,
  });
}

/** Non-blocking, serialised per folder; a picture failure must not break a scan. */
function queueFolderThumbnailUpdate(folderPath, video, sub) {
  const key = path.resolve(String(folderPath || app.getPath('downloads'))).toLowerCase();
  const previous = folderThumbLocks.get(key) || Promise.resolve();
  const run = previous
    .catch(() => { })
    .then(() => updateSubscriptionFolderThumbnail(folderPath, video, sub));
  const settled = run.catch((error) => {
    console.log(`${FOLDER_THUMBNAIL_NAME} refresh failed (non-critical):`, error?.message || error);
  });
  folderThumbLocks.set(key, settled);
  settled.finally(() => {
    if (folderThumbLocks.get(key) === settled) folderThumbLocks.delete(key);
  });
  return settled;
}

/** One folder.jpg per keyword folder, serialised; never blocks a download. */
function queueKeywordThumbnailUpdate(folderPath, candidates) {
  if (!Array.isArray(candidates) || !candidates.length) return Promise.resolve();
  const key = path.resolve(String(folderPath || app.getPath('downloads'))).toLowerCase();
  const previous = folderThumbLocks.get(key) || Promise.resolve();
  const run = previous
    .catch(() => { })
    .then(() => replaceFolderThumbnail({
      folderPath,
      candidates,
      fileName: KEYWORD_THUMBNAIL_NAME,
      fetchImage: (url) => fetchImageBuffer(url, 8000),
      writeJpeg,
    }));
  const settled = run.catch((error) => {
    console.log(`${KEYWORD_THUMBNAIL_NAME} refresh failed (non-critical):`, error?.message || error);
  });
  folderThumbLocks.set(key, settled);
  settled.finally(() => {
    if (folderThumbLocks.get(key) === key) folderThumbLocks.delete(key);
  });
  return settled;
}

// ---------------------------------------------------------------------------
// Feed scanning (flat-playlist only)
// ---------------------------------------------------------------------------

/**
 * Turn whatever the user pasted into a *feed* URL: something yt-dlp can list
 * with --flat-playlist.
 *
 *   youtube.com/playlist?list=…      → the playlist itself
 *   youtube.com/watch?v=…&list=…     → the playlist the video belongs to
 *   youtube.com/@handle  (or /c/, /user/, /channel/)  → that channel's /videos
 *
 * Everything that is not YouTube is passed through untouched and treated as a
 * playlist, which is what yt-dlp does with an album/set/collection link.
 */
function normalizeFeedUrl(rawUrl) {
  const input = String(rawUrl || '').trim();
  if (!input) throw new Error('Paste a playlist or channel link first.');

  let u;
  try {
    u = new URL(/^https?:\/\//i.test(input) ? input : `https://${input}`);
  } catch (e) {
    throw new Error('That does not look like a link.');
  }

  if (!isYouTubeUrl(u.href)) {
    return { url: u.href, kind: 'playlist' };
  }

  const listId = u.searchParams.get('list');
  const path_ = u.pathname.replace(/\/+$/, '');

  // A bare video link is not a feed — say so instead of subscribing to nothing.
  if (!listId && (u.searchParams.has('v') || path_.startsWith('/shorts/') || u.hostname === 'youtu.be')) {
    throw new Error('That is a single video link. Subscribe to a playlist or a channel instead.');
  }

  if (listId) {
    return { url: `https://www.youtube.com/playlist?list=${listId}`, kind: 'playlist' };
  }

  // Channel root, channel tab (videos/shorts/streams), handle, custom or user URL.
  if (/^\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)(\/(videos|shorts|streams))?$/.test(path_)) {
    const base = path_.replace(/\/(videos|shorts|streams)$/, '');
    return { url: `https://www.youtube.com${base}/videos`, kind: 'channel' };
  }

  // Anything else on youtube.com (a feed page, a search result) is left alone;
  // yt-dlp will either list it or return a clean error.
  return { url: u.href, kind: 'playlist' };
}

/** Best URL to hand to a downloader for one flat-playlist entry. */
function feedEntryUrl(entry, isYouTubeFeed) {
  const raw = entry.url || entry.webpage_url || '';
  if (/^https?:\/\//i.test(raw)) return raw;
  if (raw.startsWith('/') && isYouTubeFeed) return `https://www.youtube.com${raw}`;
  if (isYouTubeFeed && entry.id) return `https://www.youtube.com/watch?v=${entry.id}`;
  return raw || null;
}

/**
 * Read the NEWEST `--playlist-end` entries of a feed with yt-dlp in flat mode.
 * Flat mode is metadata only, so scanning a playlist never downloads a byte of
 * video and never extracts the full info dict of the older entries.
 *
 * Private / deleted / unavailable rows are kept in the list (so the anchor can
 * still be located if the anchor itself became private) but flagged, and they
 * are never queued for download.
 */
async function fetchFeedWindow(feedUrl, kind, depth = SCAN_DEPTH) {
  const args = [
    '--flat-playlist',
    '--ignore-errors',
    '--playlist-end', String(Math.max(1, depth)),
  ];
  if (kind === 'playlist') args.push('--yes-playlist');

  const info = await runYtDlpJson(feedUrl, args, true);
  const isYouTubeFeed = isYouTubeUrl(feedUrl);
  const rawEntries = Array.isArray(info.entries) ? info.entries : (info.id && !info._type ? [info] : []);

  const entries = [];
  for (let i = 0; i < rawEntries.length; i++) {
    const e = rawEntries[i];
    if (!e) continue;
    const id = String(e.id || '').trim();
    if (!id) continue;
    const unavailable = isUnavailableEntry(e);
    const url = unavailable ? null : feedEntryUrl(e, isYouTubeFeed);
    entries.push({
      id,
      unavailable: unavailable || !url,
      url,
      title: unavailable ? String(e.title || 'Unavailable') : String(e.title || 'Untitled'),
      playlistIndex: Number.isFinite(Number(e.playlist_index)) && Number(e.playlist_index) > 0
        ? Number(e.playlist_index)
        : (Number.isFinite(Number(e.playlist_autonumber)) && Number(e.playlist_autonumber) > 0
            ? Number(e.playlist_autonumber)
            : i + 1),
      duration: e.duration || 0,
      uploader: e.uploader || e.channel || info.uploader || info.channel || '',
      thumbnail: e.thumbnails?.length
        ? e.thumbnails[e.thumbnails.length - 1].url
        : (isYouTubeFeed ? `https://i.ytimg.com/vi/${id}/hqdefault.jpg` : ''),
    });
  }

  const title = kind === 'channel'
    ? (info.channel || info.uploader || info.title || '')
    : (info.title || info.channel || info.uploader || '');

  return {
    title,
    uploader: info.channel || info.uploader || '',
    thumbnail: info.thumbnail || entries.find(e => !e.unavailable)?.thumbnail || '',
    entries,
    available: entries.filter(e => !e.unavailable),
  };
}

// ---------------------------------------------------------------------------
// Queueing — one video at a time per subscription
// ---------------------------------------------------------------------------

/** Queue one auto-download job for a detected video. */
function enqueueSubscriptionDownload(sub, video, { auto = true } = {}) {
  const gate = canQueueDownloads(1);
  if (!gate.ok) return null;
  reserveVideos(1);
  const ext = sub.type === 'mp3' ? 'mp3' : 'mp4';
  const quality = sub.type === 'mp3' ? 'best' : (sub.quality || 'best');
  const numberedTitle = numberedPlaylistTitle(video.title, video.playlistIndex);
  const outDir = sub.folderPath || sub.targetDir || app.getPath('downloads');
  ensureFolder(outDir);
  const filePath = resolveOutputPath(outDir, numberedTitle, ext, true);

  const job = {
    id: `job-${++jobSeq}-${Date.now()}`,
    kind: 'video',
    status: 'queued',
    createdAt: Date.now(),
    reservedCount: 1,
    auto,
    subscriptionId: sub.id,
    subscriptionTitle: sub.title,
    videoId: video.id,
    url: video.url,
    title: video.title,
    thumbnailUrl: video.thumbnail || sub.thumbnail || '',
    quality,
    qualityLabel: sub.type === 'mp3'
      ? 'MP3'
      : (quality === 'best' ? 'Best' : (isHdQuality(quality) ? HD_PRESETS[String(quality)].label : `${quality}p`)),
    type: sub.type === 'mp3' ? 'mp3' : 'mp4',
    convertToH264: !!sub.convertToH264,
    filePath,
    sizeBytes: 0,
    formatLabel: sub.type === 'mp3'
      ? 'AUDIO (MP3)'
      : `${quality === 'best' ? 'Best' : (isHdQuality(quality) ? HD_PRESETS[String(quality)].label : `${quality}p`)} (MP4)`,
    meta: { source: 'subscription', subscriptionId: sub.id },
    progress: null,
  };

  downloadQueue.push(job);
  broadcastQueue();
  processQueue();
  return job.id;
}

/** Is a job for this subscription already queued or running? */
function subscriptionHasActiveJob(subId) {
  return downloadQueue.some(j => j.subscriptionId === subId &&
    (j.status === 'queued' || j.status === 'downloading'));
}

/**
 * Oldest detected video that still needs downloading. Rows queued by a scan
 * carry `auto: true` (they move the saved id); rows added by "also grab
 * existing videos" or a manual click do not, and never move it.
 */
function nextPendingVideo(sub) {
  return (sub.newVideos || []).find(v => v && (v.status === 'found' || v.status === 'queued'));
}

/**
 * Start the next download for a subscription — never two at once, and never
 * one while the previous is still in the queue. Called after a scan and after
 * every finished job, which is what makes "advance the anchor only after a
 * successful download" hold across restarts.
 */
function pumpSubscriptionDownloads(subId) {
  if (!subId || subPumpBusy.has(subId)) return;
  subPumpBusy.add(subId);
  try {
    const sub = getSubscriptions().find(s => s.id === subId);
    if (!sub || sub.enabled === false || sub.autoDownload === false) return;
    if (subscriptionHasActiveJob(subId)) return;
    const video = nextPendingVideo(sub);
    if (!video) return;

    const jobId = enqueueSubscriptionDownload(sub, video, { auto: true });
    if (!jobId) return; // daily limit / queue gate — retried on the next scan

    mutateSubscriptions((list) => {
      const target = list.find(s => s.id === subId);
      if (!target) return;
      target.newVideos = (target.newVideos || []).map(v => (
        v.id === video.id ? { ...v, status: 'queued', jobId, queuedAt: Date.now() } : v
      ));
      target.lastStatus = 'downloading';
      target.lastError = null;
    });
  } catch (error) {
    console.log('Subscription pump failed (non-critical):', error.message);
  } finally {
    subPumpBusy.delete(subId);
  }
}

/** Re-arm every subscription that still has a detected video waiting. */
function resumeSubscriptionPumps() {
  for (const sub of getSubscriptions()) {
    if (nextPendingVideo(sub) && !subscriptionHasActiveJob(sub.id)) {
      setTimeout(() => pumpSubscriptionDownloads(sub.id), 1500);
    }
  }
}

/** ffprobe check: a finished file must hold real, playable media. */
function verifyMediaFile(filePath, type = 'mp4') {
  return new Promise((resolve) => {
    if (!filePath || !fs.existsSync(filePath)) {
      return resolve({ ok: false, error: 'File missing after download.' });
    }
    const size = fs.statSync(filePath).size;
    if (size < 1024) return resolve({ ok: false, error: 'File is empty.' });

    execFile(ffprobePath, [
      '-v', 'error',
      '-show_entries', 'format=duration:stream=codec_type',
      '-of', 'json',
      filePath,
    ], (err, stdout) => {
      if (err) return resolve({ ok: false, error: 'ffprobe could not read the file.' });
      try {
        const probe = JSON.parse(stdout);
        const streams = Array.isArray(probe.streams) ? probe.streams : [];
        const duration = Number(probe.format?.duration || 0);
        const hasAudio = streams.some(s => s.codec_type === 'audio');
        const hasVideo = streams.some(s => s.codec_type === 'video');
        const ok = duration > 0.5 && (type === 'mp3' ? hasAudio : (hasVideo || hasAudio));
        resolve(ok
          ? { ok: true, duration }
          : { ok: false, error: 'Downloaded file did not pass the ffprobe check.' });
      } catch (e) {
        resolve({ ok: false, error: 'ffprobe output could not be parsed.' });
      }
    });
  });
}

/**
 * Result of an auto-download, applied to the subscription:
 *   success   → drop the row, move the anchor forward, start the next video
 *   failure   → keep the row + anchor, stop the batch (retried next scan)
 *   cancelled → same as failure, but the user asked for it
 */
async function handleSubscriptionJobResult(job, { success = false, cancelled = false, path: savedPath = null } = {}) {
  const subId = job?.subscriptionId;
  if (!subId) return;

  let ok = success;
  let failureReason = null;
  if (success) {
    const target = savedPath || job.filePath;
    const check = await verifyMediaFile(target, job.type === 'mp3' ? 'mp3' : 'mp4');
    if (!check.ok) {
      ok = false;
      failureReason = check.error;
      console.log(`Subscription download failed verification (${job.videoId}):`, check.error);
    }
  }

  const list = getSubscriptions();
  const idx = list.findIndex(s => s.id === subId);
  if (idx === -1) return;
  const sub = list[idx];
  const videoId = String(job.videoId || '');
  const entry = (sub.newVideos || []).find(v => v.id === videoId);

  if (ok) {
    sub.newVideos = (sub.newVideos || []).filter(v => v.id !== videoId);
    sub.videosDownloaded = (sub.videosDownloaded || 0) + 1;
    sub.lastDownloadAt = Date.now();
    sub.failedAttempts = 0;
    // The ONLY place the anchor moves: a verified, finished download.
    if (entry?.auto) {
      sub.lastVideoId = advanceAnchor(sub.lastVideoId, { id: videoId });
      sub.lastVideoTitle = entry?.title || sub.lastVideoTitle || '';
      sub.lastVideoIndex = entry?.playlistIndex ?? sub.lastVideoIndex ?? null;
    }
    sub.lastStatus = 'downloaded';
    sub.lastError = null;
  } else {
    const attempts = (Number(entry?.attempts) || 0) + 1;
    sub.newVideos = (sub.newVideos || []).map(v => (
      v.id === videoId
        ? { ...v, status: cancelled ? 'cancelled' : 'failed', attempts, error: failureReason || job.error || null, finishedAt: Date.now() }
        : v
    ));
    // Anchor deliberately untouched.
    sub.videosFailed = (sub.videosFailed || 0) + 1;
    sub.lastStatus = cancelled ? 'cancelled' : 'failed';
    sub.lastError = cancelled ? null : (failureReason || job.error || 'Download failed');
    if (!cancelled && attempts >= MAX_AUTO_ATTEMPTS) {
      sub.lastError = `Stopped after ${attempts} attempts: ${sub.lastError}`;
    }
  }

  saveSubscriptions(list);
  if (ok) setTimeout(() => pumpSubscriptionDownloads(subId), 250);
}

/**
 * One-time tidy for stores written by an older build, where finished videos
 * stayed in `newVideos` forever: move them to the counter and out of the list.
 */
function pruneFinishedSubscriptionVideos() {
  const list = getSubscriptions();
  let changed = false;
  for (const sub of list) {
    const done = (sub.newVideos || []).filter(v => v.status === 'downloaded');
    if (!done.length) continue;
    sub.newVideos = (sub.newVideos || []).filter(v => v.status !== 'downloaded');
    sub.videosDownloaded = (sub.videosDownloaded || 0) + done.length;
    changed = true;
  }
  if (changed) saveSubscriptions(list, { emit: false });
  return changed;
}

function notifyNewVideos(sub, videos) {
  if (!Notification.isSupported()) return;
  try {
    const n = new Notification({
      title: sub.title || 'Subscription',
      body: videos.length === 1
        ? `New video: ${videos[0].title}${sub.autoDownload ? ' — downloading now' : ''}`
        : `${videos.length} new videos${sub.autoDownload ? ' — downloading now' : ''}`,
      silent: false,
    });
    n.on('click', () => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        if (mainWindow.isMinimized()) mainWindow.restore();
        mainWindow.focus();
      }
    });
    n.show();
  } catch (e) {
    // A notification failing must never break the scan
    console.log('Notification failed (non-critical):', e.message);
  }
}

// ---------------------------------------------------------------------------
// One scan
// ---------------------------------------------------------------------------

/**
 * Scan one subscription: read the newest flat entries, diff against the saved
 * anchor, record what is new and start downloading it oldest-first.
 * Mutates and persists `sub`.
 */
async function checkSubscription(sub, { manual = false } = {}) {
  if (subBusyIds.has(sub.id)) return { skipped: true };

  subBusyIds.add(sub.id);
  try {
    syncSubscriptionFolder(sub, { create: true, others: getSubscriptions() });
    if (!sub.targetDir) throw new Error('No download folder set for this subscription.');

    const feed = await fetchFeedWindow(sub.url, sub.kind);
    if (!feed.entries.length) throw new Error('No videos found in this playlist.');

    // Refresh card metadata as a side effect — titles/avatars change.
    if (feed.title) sub.title = sub.title || feed.title;
    if (feed.uploader) sub.uploader = feed.uploader;
    if (feed.thumbnail) sub.thumbnail = feed.thumbnail;

    const plan = findNewVideos(feed.entries, sub.lastVideoId, { anchorMissingMax: ANCHOR_MISSING_MAX });

    if (plan.baseline) {
      // First sight: remember the newest id and download nothing.
      sub.lastVideoId = plan.latestId;
      sub.lastVideoTitle = feed.entries[0]?.title || '';
      sub.lastCheckedAt = Date.now();
      sub.lastStatus = 'baseline';
      sub.lastError = null;
      notifySafe({ kind: 'success', text: `Following “${sub.title}”. Only new uploads will download.` });
      return { ok: true, baseline: true, found: 0, queued: 0 };
    }

    if (plan.unchanged) {
      sub.lastCheckedAt = Date.now();
      sub.lastStatus = 'ok';
      sub.lastError = null;
      return { ok: true, found: 0, queued: 0, unchanged: true };
    }

    const skippedUnavailable = plan.skipped;
    const detected = plan.newVideos.map(v => ({
      id: v.id,
      title: v.title,
      playlistIndex: v.playlistIndex ?? null,
      thumbnail: v.thumbnail,
      thumbnailUrl: v.thumbnail,
      duration: v.duration || 0,
      url: v.url,
      detectedAt: Date.now(),
      status: 'found',
      auto: true,
      attempts: 0,
    }));

    // Oldest first, de-duplicated against rows still waiting from an earlier
    // scan, and re-armed so a retry starts from "found" again.
    const merged = mergeDetected(
      (sub.newVideos || []).map(v => (v.status === 'queued' || v.status === 'failed' || v.status === 'cancelled'
        ? { ...v, status: 'found' }
        : v)),
      detected,
      SUB_NEW_KEEP,
    );
    sub.newVideos = merged;
    sub.videosFound = (sub.videosFound || 0) + detected.length;
    sub.skippedUnavailable = skippedUnavailable;
    sub.lastCheckedAt = Date.now();
    sub.lastStatus = detected.length ? 'updated' : 'ok';
    sub.lastError = null;
    sub.lastNewAt = Date.now();

    if (plan.anchorMissing) {
      notifySafe({
        kind: 'warning',
        text: `“${sub.title}”: saved video is gone from the playlist — taking the newest ${detected.length}.`,
      });
    }

    if (detected.length) {
      notifyNewVideos(sub, detected);
      safeSend('subscription-new-videos', {
        subscriptionId: sub.id,
        title: sub.title,
        videos: sub.newVideos,
        count: detected.length,
      });
      const newestVideo = detected[detected.length - 1];
      if (newestVideo) void queueFolderThumbnailUpdate(sub.folderPath, newestVideo, sub);
    }

    return {
      ok: true,
      found: detected.length,
      queued: 0,
      anchorMissing: plan.anchorMissing,
      skipped: skippedUnavailable,
    };
  } catch (error) {
    // A failed scan keeps the saved id exactly as it was.
    sub.lastCheckedAt = Date.now();
    sub.lastStatus = 'error';
    sub.lastError = error.message || 'Scan failed';
    throw error;
  } finally {
    subBusyIds.delete(sub.id);
    const list = getSubscriptions();
    const idx = list.findIndex(s => s.id === sub.id);
    if (idx !== -1) {
      list[idx] = sub;
      saveSubscriptions(list);
    }
    // Downloads are started AFTER the scan is saved, so a crash mid-pump still
    // has the detected rows on disk.
    if (sub.newVideos?.some(v => v.auto && v.status === 'found')) {
      setTimeout(() => pumpSubscriptionDownloads(sub.id), 200);
    }
  }
}

function notifySafe(notice) {
  try { safeSend('app-notice', notice); } catch (e) { /* renderer gone */ }
}

/** One sweep: scan everything that is due, sequentially. */
async function runSubscriptionSweep({ manual = false, onlyId = null } = {}) {
  if (subChecking) return { skipped: true };
  if (isUpdatingYtDlp && !manual) return { skipped: true };

  subChecking = true;
  const results = [];
  try {
    const list = getSubscriptions();
    const now = Date.now();
    const engine = getScanState();

    // Build the due list FIRST, then scan ONE playlist at a time with await.
    // No Promise.all: a sweep must never hit every feed simultaneously.
    const due = [];
    for (const sub of list) {
      if (onlyId && sub.id !== onlyId) continue;
      if (!onlyId && !engine.running) continue;
      if (!sub.enabled && !onlyId) continue;
      if (!onlyId && !isScanDue(sub, now, engine.intervalMinutes)) continue;
      due.push(sub);
    }

    const total = due.length;
    for (let i = 0; i < total; i++) {
      const sub = due[i];
      // Only a manual sweep drives the GUI progress banner; the background
      // engine stays silent.
      if (manual) {
        safeSend('subscription-check-progress', {
          phase: 'checking', id: sub.id, title: sub.title || 'Untitled playlist', index: i + 1, total,
        });
      }
      try {
        const res = await checkSubscription(sub, { manual });
        results.push({ id: sub.id, ...res });
      } catch (error) {
        results.push({ id: sub.id, ok: false, error: error.message });
      }
      if (manual) {
        safeSend('subscription-check-progress', {
          phase: 'done', id: sub.id, title: sub.title || 'Untitled playlist', index: i + 1, total,
        });
      }
    }
    if (manual) safeSend('subscription-check-progress', { phase: 'finished', index: total, total });

    setScanState({ lastSweepAt: Date.now(), lastSweepStatus: total ? 'ok' : 'idle' });
  } finally {
    subChecking = false;
  }
  return { results };
}

// ---------------------------------------------------------------------------
// Scan engine — Start Scan / Stop Scan / Scan Interval
// ---------------------------------------------------------------------------

const DEFAULT_SCAN_STATE = { running: true, intervalMinutes: 15, lastSweepAt: 0, lastSweepStatus: 'idle' };

function getScanState() {
  const stored = store.get(SUBSCAN_KEY, {}) || {};
  return {
    ...DEFAULT_SCAN_STATE,
    ...stored,
    running: stored.running !== false,
    intervalMinutes: SUB_INTERVAL_CHOICES.includes(Number(stored.intervalMinutes))
      ? Number(stored.intervalMinutes)
      : DEFAULT_SCAN_STATE.intervalMinutes,
  };
}

function setScanState(patch = {}) {
  const next = { ...getScanState(), ...patch };
  if (!SUB_INTERVAL_CHOICES.includes(Number(next.intervalMinutes))) {
    next.intervalMinutes = DEFAULT_SCAN_STATE.intervalMinutes;
  }
  store.set(SUBSCAN_KEY, next);
  safeSend('subscription-scan-state', next);
  return next;
}

/** Start the engine: scan now, then keep scanning on the shared cadence. */
async function startScanEngine({ intervalMinutes = null, immediate = true } = {}) {
  const patch = { running: true };
  if (intervalMinutes != null) patch.intervalMinutes = Number(intervalMinutes);
  const state = setScanState(patch);
  ensureScanTimer();
  if (immediate) {
    runSubscriptionSweep().catch(e => console.log('Subscription sweep failed:', e.message));
  }
  return state;
}

function stopScanEngine() {
  const state = setScanState({ running: false });
  return state;
}

function ensureScanTimer() {
  if (subTimer) return;
  subTimer = setInterval(() => {
    const state = getScanState();
    if (!state.running) return;
    const due = Date.now() - (Number(state.lastSweepAt) || 0) >= Math.max(1, state.intervalMinutes) * 60 * 1000;
    if (!due) return;
    runSubscriptionSweep().catch(e => console.log('Subscription sweep failed:', e.message));
  }, SUB_TICK_MS);
}

/** Started once at boot; honours the persisted running/interval state. */
function startSubscriptionScheduler() {
  ensureScanTimer();
  // Give the app (and yt-dlp's self-update) a head start before the first sweep.
  const state = getScanState();
  if (state.running) {
    setTimeout(() => {
      runSubscriptionSweep().catch(e => console.log('Subscription sweep failed:', e.message));
    }, 20 * 1000);
  }
}

// --- Subscriptions IPC ------------------------------------------------------

ipcMain.handle('subscriptions:list', () => getSubscriptions());

ipcMain.handle('subscriptions:scan-state', () => getScanState());
ipcMain.handle('subscriptions:scan-start', async (event, intervalMinutes = null) => {
  const state = await startScanEngine({ intervalMinutes });
  return { success: true, state };
});
ipcMain.handle('subscriptions:scan-stop', () => ({ success: true, state: stopScanEngine() }));
ipcMain.handle('subscriptions:scan-interval', (event, minutes) => {
  const next = Number(minutes);
  if (!SUB_INTERVAL_CHOICES.includes(next)) {
    return { success: false, error: 'Pick a valid interval.', state: getScanState() };
  }
  return { success: true, state: setScanState({ intervalMinutes: next }) };
});

/** Export every followed playlist/channel to a portable JSON / .jsn file. */
ipcMain.handle('subscriptions:export', async () => {
  const list = getSubscriptions();
  const payload = {
    app: 'UK Downloader',
    type: 'subscriptions',
    version: 2,
    exportedAt: new Date().toISOString(),
    ...toStorageDocument(list),
  };
  const res = await dialog.showSaveDialog(mainWindow, {
    title: 'Export subscriptions',
    defaultPath: path.join(app.getPath('documents'), 'uk-downloader-subscriptions.json'),
    buttonLabel: 'Export',
    filters: [{ name: 'Subscription JSON', extensions: ['json', 'jsn'] }],
  });
  if (res.canceled || !res.filePath) return { success: false, canceled: true };
  try {
    writeJsonAtomic(res.filePath, payload);
  } catch (err) {
    return { success: false, error: err.message || 'Could not write the file.' };
  }
  const text = `Exported ${list.length} subscription${list.length === 1 ? '' : 's'} to ${path.basename(res.filePath)}`;
  notifySafe({ kind: 'success', text });
  return { success: true, path: res.filePath, count: list.length, message: text };
});

/** Import a previously exported JSON / .jsn file, merging by subscription id. */
ipcMain.handle('subscriptions:import', async () => {
  const res = await dialog.showOpenDialog(mainWindow, {
    title: 'Import subscriptions',
    buttonLabel: 'Import',
    properties: ['openFile'],
    filters: [{ name: 'Subscription JSON', extensions: ['json', 'jsn'] }],
  });
  const filePath = res?.filePaths?.[0];
  if (res?.canceled || !filePath) return { success: false, canceled: true };

  let parsed;
  try {
    parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return { success: false, error: 'That file is not valid JSON.' };
  }
  const incoming = Array.isArray(parsed) ? parsed : parsed?.subscriptions;
  if (!Array.isArray(incoming)) {
    return { success: false, error: 'No subscriptions found in that file.' };
  }
  const clean = incoming
    .filter(s => s && typeof s === 'object' && (s.id || s.url))
    .map(normalizeRecord);
  if (!clean.length) return { success: false, error: 'No usable subscriptions found.' };

  const current = getSubscriptions();
  const byKey = new Map(current.map(s => [String(s.id || s.url), s]));
  const byUrl = new Map(current.map(s => [String(s.url), s]));
  let added = 0;
  let updated = 0;
  for (const raw of clean) {
    const id = String(raw.id || `sub-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);
    const existing = byKey.get(id) || byUrl.get(String(raw.url || ''));
    if (existing) {
      Object.assign(existing, raw, { id: existing.id || id });
      updated += 1;
    } else {
      const record = { ...raw, id };
      byKey.set(id, record);
      if (record.url) byUrl.set(record.url, record);
      added += 1;
    }
  }
  const merged = ensureAllSubscriptionFolders({
    emit: false, persist: false, sourceList: Array.from(byKey.values()),
  });
  saveSubscriptions(merged);
  const text = `Imported ${added} new, updated ${updated} existing subscription${added + updated === 1 ? '' : 's'}.`;
  notifySafe({ kind: 'success', text });
  return { success: true, added, updated, total: merged.length, message: text };
});

ipcMain.handle('get-last-subscription-dir', () => store.get('lastSubscriptionDir', '') || '');

ipcMain.handle('playlist-hub:list', () => {
  const list = store.get(PLAYLIST_HUB_KEY, []) || [];
  return Array.isArray(list) ? list : [];
});
ipcMain.handle('playlist-hub:add', (event, entry = {}) => {
  const url = String(entry.url || '').trim();
  if (!url) return { success: false, error: 'No playlist link given.' };
  const now = Date.now();
  const clean = {
    url,
    title: String(entry.title || 'Untitled playlist').slice(0, 200),
    uploader: String(entry.uploader || '').slice(0, 120),
    videoCount: Number(entry.videoCount) || 0,
    thumbnail: String(entry.thumbnail || ''),
    addedAt: now,
    lastOpenedAt: now,
  };
  const list = (store.get(PLAYLIST_HUB_KEY, []) || []).filter(p => p && p.url !== url);
  const next = [clean, ...list].slice(0, 12);
  store.set(PLAYLIST_HUB_KEY, next);
  return { success: true, list: next };
});
ipcMain.handle('playlist-hub:remove', (event, url) => {
  const list = (store.get(PLAYLIST_HUB_KEY, []) || []).filter(p => p && p.url !== url);
  store.set(PLAYLIST_HUB_KEY, list);
  return { success: true, list };
});

ipcMain.handle('subscriptions:options', () => ({
  intervals: SUB_INTERVAL_CHOICES,
  qualities: SUB_QUALITIES,
  scanInterval: getScanState().intervalMinutes,
}));

ipcMain.handle('subscriptions:pick-folder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Choose a folder for this subscription',
    properties: ['openDirectory', 'createDirectory'],
  });
  if (result.canceled || !result.filePaths.length) return null;
  return result.filePaths[0];
});

ipcMain.handle('subscriptions:add', async (event, payload = {}) => {
  try {
    const { url: feedUrl, kind } = normalizeFeedUrl(payload.url);

    const existing = getSubscriptions().find(s => s.url === feedUrl);
    if (existing) {
      return { success: false, error: 'You are already following this one.', subscriptionId: existing.id };
    }

    const feed = await fetchFeedWindow(feedUrl, kind);
    if (!feed.available.length) {
      return { success: false, error: 'No videos found.' };
    }

    const now = Date.now();
    const parentDir = payload.targetDir || store.get('lastSubscriptionDir', '') || app.getPath('downloads');
    const newest = feed.available[0];
    const engine = getScanState();

    const sub = {
      id: `sub-${now}-${Math.random().toString(36).slice(2, 7)}`,
      url: feedUrl,
      kind,
      title: payload.title || feed.title || feed.uploader || 'Untitled playlist',
      uploader: feed.uploader || '',
      thumbnail: feed.thumbnail || newest?.thumbnail || '',
      targetDir: parentDir,
      quality: SUB_QUALITIES.includes(String(payload.quality)) ? String(payload.quality) : 'best',
      type: payload.type === 'mp3' ? 'mp3' : 'mp4',
      convertToH264: !!payload.convertToH264,
      autoDownload: payload.autoDownload !== false,
      downloadExisting: !!payload.downloadExisting,
      intervalMinutes: SUB_INTERVAL_CHOICES.includes(Number(payload.intervalMinutes))
        ? Number(payload.intervalMinutes)
        : engine.intervalMinutes,
      enabled: true,
      // THE anchor. Scanning from here on compares against this single id.
      lastVideoId: newest?.id || '',
      lastVideoTitle: newest?.title || '',
      lastVideoIndex: newest?.playlistIndex ?? null,
      newVideos: [],
      videosFound: 0,
      videosDownloaded: 0,
      videosFailed: 0,
      skippedUnavailable: 0,
      lastCheckedAt: now,
      lastStatus: 'baseline',
      lastError: null,
      createdAt: now,
      updatedAt: now,
    };

    // One named folder per subscription, created NOW. Videos and FOLDER.JPG
    // both live here; FOLDER.JPG itself waits for the first download.
    const folderName = safeFolderName(sub.title || feed.title || feed.uploader || 'Playlist');
    const takenFolderPaths = getSubscriptions().map(s => s.folderPath).filter(Boolean);
    const folderPath = uniqueFolderPath(parentDir, folderName, takenFolderPaths);
    sub.folderName = folderName;
    sub.folderPath = folderPath;
    try {
      ensureFolder(folderPath);
    } catch (error) {
      return { success: false, error: `Could not create the playlist folder: ${error.message}` };
    }

    // "Also grab existing videos" queues the newest few as manual rows, so the
    // anchor never has to move backwards to make them download.
    if (payload.downloadExisting) {
      const wanted = feed.available.slice(0, 10).reverse();
      sub.newVideos = wanted.map(v => ({
        id: v.id,
        title: v.title,
        playlistIndex: v.playlistIndex ?? null,
        thumbnail: v.thumbnail,
        thumbnailUrl: v.thumbnail,
        duration: v.duration || 0,
        url: v.url,
        detectedAt: now,
        status: 'found',
        auto: false,
        attempts: 0,
      }));
      sub.videosFound = sub.newVideos.length;
      sub.lastStatus = 'updated';
    }

    const list = [sub, ...getSubscriptions()];
    saveSubscriptions(list);
    // Remember the folder so the next subscription is one click, not two.
    if (sub.targetDir) store.set('lastSubscriptionDir', sub.targetDir);

    return { success: true, subscription: sub };
  } catch (error) {
    return { success: false, error: error.message || 'Could not subscribe to that link.' };
  }
});

ipcMain.handle('subscriptions:update', (event, { id, patch } = {}) => {
  const allowed = ['autoDownload', 'quality', 'type', 'convertToH264', 'intervalMinutes',
    'targetDir', 'enabled', 'title'];
  const clean = {};
  for (const key of allowed) {
    if (patch && Object.prototype.hasOwnProperty.call(patch, key)) clean[key] = patch[key];
  }
  if (clean.intervalMinutes !== undefined && !SUB_INTERVAL_CHOICES.includes(Number(clean.intervalMinutes))) {
    delete clean.intervalMinutes;
  }
  if (clean.quality !== undefined && !SUB_QUALITIES.includes(String(clean.quality))) {
    delete clean.quality;
  }
  if (clean.targetDir !== undefined && !clean.targetDir) {
    return { success: false, error: 'Pick a folder first.' };
  }
  const sub = updateSubscription(id, clean);
  if (sub && clean.enabled === true) setTimeout(() => pumpSubscriptionDownloads(id), 100);
  return sub ? { success: true, subscription: sub } : { success: false, error: 'Subscription not found.' };
});

ipcMain.handle('subscriptions:remove', (event, id) => {
  saveSubscriptions(getSubscriptions().filter(s => s.id !== id));
  return { success: true };
});

ipcMain.handle('subscriptions:check', async (event, id = null) => {
  // Manual scans run even while the engine is stopped or a playlist is paused.
  const list = getSubscriptions();
  if (!id) {
    if (!list.length) return { success: true, results: [] };
    const res = await runSubscriptionSweep({ manual: true });
    return { success: true, results: res.results || [] };
  }
  const sub = list.find(s => s.id === id);
  if (!sub) return { success: false, error: 'Subscription not found.' };
  try {
    safeSend('subscription-check-progress', {
      phase: 'checking', id: sub.id, title: sub.title || 'Untitled playlist', index: 1, total: 1,
    });
    const res = await checkSubscription(sub, { manual: true });
    safeSend('subscription-check-progress', {
      phase: 'finished', id: sub.id, title: sub.title || 'Untitled playlist', index: 1, total: 1,
    });
    return { success: true, results: [{ id, ...res }] };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

/**
 * Re-baseline: forget the anchor and adopt whatever is newest right now,
 * WITHOUT downloading anything. Used after a playlist has been reordered or
 * when a stuck video needs to be skipped on purpose.
 */
ipcMain.handle('subscriptions:rebaseline', async (event, id) => {
  const sub = getSubscriptions().find(s => s.id === id);
  if (!sub) return { success: false, error: 'Subscription not found.' };
  try {
    const feed = await fetchFeedWindow(sub.url, sub.kind);
    const newest = feed.available[0];
    if (!newest) return { success: false, error: 'No videos found.' };
    mutateSubscriptions((list) => {
      const target = list.find(s => s.id === id);
      if (!target) return;
      target.lastVideoId = newest.id;
      target.lastVideoTitle = newest.title;
      target.lastVideoIndex = newest.playlistIndex ?? null;
      target.newVideos = [];
      target.lastStatus = 'baseline';
      target.lastError = null;
      target.lastCheckedAt = Date.now();
    });
    return { success: true, lastVideoId: newest.id };
  } catch (error) {
    return { success: false, error: error.message || 'Could not re-baseline this playlist.' };
  }
});

ipcMain.handle('subscriptions:mark-seen', () => {
  mutateSubscriptions((list) => {
    for (const sub of list) sub.lastSeenAt = Date.now();
  });
  return { success: true };
});

ipcMain.handle('subscriptions:download-video', async (event, { subscriptionId, videoId } = {}) => {
  const all = getSubscriptions();
  const sub = all.find(s => s.id === subscriptionId);
  if (!sub) return { success: false, error: 'Subscription not found.' };
  const video = (sub.newVideos || []).find(v => v.id === videoId);
  if (!video) return { success: false, error: 'Video not found.' };
  try {
    syncSubscriptionFolder(sub, { create: true, others: all });
  } catch (error) {
    return { success: false, error: `Could not create the playlist folder: ${error.message}` };
  }
  const jobId = enqueueSubscriptionDownload(sub, video, { auto: !!video.auto });
  if (!jobId) return { success: false, error: 'Daily limit reached. Enter a Pro key to continue.', limitReached: true };
  mutateSubscriptions((list) => {
    const target = list.find(s => s.id === subscriptionId);
    if (!target) return;
    target.newVideos = (target.newVideos || []).map(v => (
      v.id === videoId ? { ...v, status: 'queued', jobId } : v
    ));
  });
  void queueFolderThumbnailUpdate(sub.folderPath, video, sub);
  return { success: true };
});

ipcMain.handle('subscriptions:open-folder', (event, id) => {
  const sub = getSubscriptions().find(s => s.id === id);
  const folderPath = sub?.folderPath || sub?.targetDir;
  if (!folderPath) return { success: false };
  try { ensureFolder(folderPath); } catch (error) {
    console.log('Could not recreate the subscription folder:', error.message);
  }
  shell.openPath(folderPath);
  return { success: true };
});
app.whenReady().then(() => {
  try { migrateSubscriptions(); } catch (e) {
    console.log('Subscription migration failed (non-critical):', e.message);
  }
  try { pruneFinishedSubscriptionVideos(); } catch (e) {
    console.log('Subscription prune failed (non-critical):', e.message);
  }
  try { ensureAllSubscriptionFolders({ emit: false, persist: true }); } catch (e) {
    console.log('Subscription folder setup failed (non-critical):', e.message);
  }
  // Anything detected but not finished before the app closed is re-queued.
  try { resumeSubscriptionPumps(); } catch (e) {
    console.log('Subscription resume failed (non-critical):', e.message);
  }
  startSubscriptionScheduler();
});

app.on('before-quit', () => {
  if (subTimer) {
    clearInterval(subTimer);
    subTimer = null;
  }
});
