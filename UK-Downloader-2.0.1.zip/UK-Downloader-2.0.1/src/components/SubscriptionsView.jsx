import React, { useState, useMemo } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import {
  ArrowLeft, Bell, BellRing, RefreshCw, Loader2, FolderOpen, Trash2,
  Plus, CheckCircle2, AlertCircle, Download, Upload, Rss, Clock, X, ListVideo,
  ChevronDown, ChevronUp, Play, Pause, Database,
} from 'lucide-react';

const QUALITY_OPTIONS = [
  { value: 'hd720', label: '720p HD · H.264 only' },
  { value: 'hd480', label: '480p HD · H.264 only' },
  { value: 'best', label: 'Best available' },
  { value: '2160', label: '4K (2160p)' },
  { value: '1440', label: '2K (1440p)' },
  { value: '1080', label: '1080p' },
  { value: '720', label: '720p' },
  { value: '480', label: '480p' },
  { value: '360', label: '360p' },
];

const INTERVAL_OPTIONS = [
  { value: 5, label: 'Every 5 minutes' },
  { value: 15, label: 'Every 15 minutes' },
  { value: 30, label: 'Every 30 minutes' },
  { value: 60, label: 'Every hour' },
  { value: 180, label: 'Every 3 hours' },
];

const thumbFallback = (e) => {
  const src = e.target.src || '';
  if (src.includes('maxresdefault')) {
    e.target.src = src.replace(/maxresdefault\.(jpg|webp)/, 'hqdefault.jpg');
  } else if (src.includes('sd2.jpg') || src.includes('sddefault.jpg')) {
    e.target.src = src.replace(/sd2\.jpg|sddefault\.jpg/, 'hqdefault.jpg');
  } else {
    e.target.style.opacity = 0;
  }
};

const timeAgo = (ts) => {
  if (!ts) return 'never';
  const s = Math.max(0, Math.floor((Date.now() - ts) / 1000));
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
};

const formatDuration = (seconds) => {
  if (!seconds) return '';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  return `${m}:${s.toString().padStart(2, '0')}`;
};

const folderName = (p) => {
  if (!p) return 'No folder';
  const parts = String(p).split(/[\\/]/).filter(Boolean);
  return parts[parts.length - 1] || p;
};

/** Live queue state for a video a subscription found. */
const useVideoState = (jobs, jobProgress) => (subId, videoId) => {
  const job = jobs.find(j => j.videoId === videoId && j.subscriptionId === subId);
  if (!job) return null;
  return { status: job.status, percent: jobProgress[job.id]?.percent || 0 };
};

const ScanBadge = ({ running }) => (
  <span className={`inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded ${
    running ? 'bg-emerald-500/12 text-emerald-600 dark:text-emerald-400' : 'bg-secondary text-muted-foreground'
  }`}>
    <span className={`h-1.5 w-1.5 rounded-full ${running ? 'bg-emerald-500' : 'bg-muted-soft'}`} />
    {running ? 'Scanning' : 'Stopped'}
  </span>
);

const StatusChip = ({ status, percent }) => {
  const base = 'inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded';
  if (status === 'downloading') {
    return (
      <span className={`${base} bg-primary/10 text-primary`}>
        <Loader2 className="h-2.5 w-2.5 animate-spin" />
        {Math.round(percent || 0)}%
      </span>
    );
  }
  if (status === 'queued') {
    return <span className={`${base} bg-secondary text-muted-foreground`}>Queued</span>;
  }
  if (status === 'downloaded') {
    return (
      <span className={`${base} bg-emerald-500/10 text-emerald-600 dark:text-emerald-400`}>
        <CheckCircle2 className="h-2.5 w-2.5" /> Saved
      </span>
    );
  }
  if (status === 'failed') {
    return (
      <span className={`${base} bg-destructive/10 text-destructive`}>
        <AlertCircle className="h-2.5 w-2.5" /> Failed
      </span>
    );
  }
  if (status === 'cancelled') {
    return <span className={`${base} bg-secondary text-muted-foreground`}>Stopped</span>;
  }
  return <span className={`${base} bg-secondary text-muted-foreground`}>New</span>;
};

const SubscriptionCard = ({ sub }) => {
  const {
    jobs, jobProgress, subsBusyId, subsCheckProgress, updateSubscription, removeSubscription,
    checkSubscription, rebaselineSubscription, downloadSubscriptionVideo,
    changeSubscriptionFolder,
  } = useAppContext();

  const [expanded, setExpanded] = useState(false);
  const videoState = useVideoState(jobs, jobProgress);

  const checking = subsBusyId === sub.id || (subsBusyId === 'all' && !subsCheckProgress);
  const isAudio = sub.type === 'mp3';
  // Finished videos are removed from the list (the main process drops them as
  // soon as the job completes) — filter as well so an entry that completes
  // while this page is open disappears immediately.
  const videos = (sub.newVideos || []).filter(v => v.status !== 'downloaded');
  const visible = expanded ? videos : videos.slice(0, 3);
  const unseen = videos.filter(v => (v.detectedAt || 0) > (sub.lastSeenAt || 0)).length;

  const activeDownload = videos
    .map(v => videoState(sub.id, v.id))
    .find(s => s && (s.status === 'downloading' || s.status === 'queued'));

  // One saved id per playlist: the newest video that finished downloading.
  const savedId = sub.lastVideoId || '';
  const waiting = videos.filter(v => v.status === 'found' || v.status === 'queued').length;

  return (
    <div className="rounded-xl border border-border/40 bg-secondary/[0.12] overflow-hidden">
      {/* ── Header row ─────────────────────────────────────────────────── */}
      <div className="flex items-start gap-3 p-3.5">
        <div className="relative w-24 aspect-video rounded-lg overflow-hidden shrink-0 bg-secondary/40 border border-border/30">
          {sub.thumbnail ? (
            <img src={sub.thumbnail} alt="" className="w-full h-full object-cover" onError={thumbFallback} />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <ListVideo className="h-5 w-5 text-muted-soft" />
            </div>
          )}
          <div className="absolute bottom-1 left-1 bg-black/70 text-white text-[9px] px-1.5 py-0.5 rounded font-semibold">
            {sub.kind === 'channel' ? 'CHANNEL' : 'PLAYLIST'}
          </div>
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 min-w-0">
            <h3 className="text-[13.5px] font-semibold text-foreground truncate" title={sub.title}>
              {sub.title}
            </h3>
            {unseen > 0 && (
              <span className="shrink-0 text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-primary text-primary-foreground">
                {unseen} new
              </span>
            )}
          </div>
          <p className="text-[11.5px] text-muted-foreground truncate mt-0.5">
            {sub.uploader || 'Unknown'} · {sub.autoDownload ? 'Auto' : 'Manual'}
          </p>
          <div className="flex items-center flex-wrap gap-x-3 gap-y-1 mt-1.5 text-[11px] text-muted-soft">
            <span className="inline-flex items-center gap-1">
              <Clock className="h-3 w-3" />
              checked {timeAgo(sub.lastCheckedAt)}
            </span>
            <span className="inline-flex items-center gap-1">
              <RefreshCw className="h-3 w-3" />
              every {sub.intervalMinutes >= 60 ? `${sub.intervalMinutes / 60}h` : `${sub.intervalMinutes}m`}
            </span>
            <span className="inline-flex items-center gap-1">
              <Download className="h-3 w-3" />
              {sub.videosFound || 0} found
            </span>
            {savedId && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <span className="inline-flex items-center gap-1 font-mono text-[10.5px] text-sky-600/90 dark:text-sky-400/80">
                    <Database className="h-3 w-3" />
                    {savedId}
                  </span>
                </TooltipTrigger>
                <TooltipContent side="bottom" className="text-xs">
                  Last video ID
                </TooltipContent>
              </Tooltip>
            )}
            {waiting > 0 && (
              <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400/80">
                <Clock className="h-3 w-3" />
                {waiting} waiting
              </span>
            )}
            {(sub.videosDownloaded || 0) > 0 && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <span className="inline-flex items-center gap-1 text-emerald-600/90 dark:text-emerald-400/80">
                    <CheckCircle2 className="h-3 w-3" />
                    {sub.videosDownloaded} downloaded
                  </span>
                </TooltipTrigger>
                <TooltipContent side="bottom" className="text-xs">
                  Downloaded
                </TooltipContent>
              </Tooltip>
            )}
            {sub.lastStatus === 'error' && (
              <span className="inline-flex items-center gap-1 text-destructive">
                <AlertCircle className="h-3 w-3" />
                {sub.lastError || 'Scan failed — saved ID kept'}
              </span>
            )}
            {sub.lastStatus === 'failed' && (
              <span className="inline-flex items-center gap-1 text-destructive">
                <AlertCircle className="h-3 w-3" />
                {sub.lastError || 'Download failed — saved ID kept'}
              </span>
            )}
            {(sub.skippedUnavailable || 0) > 0 && (
              <span className="inline-flex items-center gap-1 text-muted-soft">
                {sub.skippedUnavailable} unavailable
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost" size="icon"
                className="h-8 w-8 text-muted-foreground hover:text-foreground"
                onClick={() => checkSubscription(sub.id)}
                disabled={checking}
                aria-label="Check now"
              >
                {checking ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">Check</TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost" size="icon"
                className="h-8 w-8 text-muted-foreground hover:text-foreground"
                onClick={() => rebaselineSubscription(sub.id)}
                disabled={checking}
                aria-label="Re-baseline playlist"
              >
                <Database className="h-3.5 w-3.5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">Re-baseline</TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost" size="icon"
                className="h-8 w-8 text-muted-foreground hover:text-foreground"
                onClick={() => window.electronAPI.openSubscriptionFolder(sub.id)}
                aria-label="Open folder"
              >
                <FolderOpen className="h-3.5 w-3.5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">{sub.folderPath || sub.targetDir || 'No folder set'}</TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost" size="icon"
                className="h-8 w-8 text-muted-foreground hover:text-destructive"
                aria-label="Unsubscribe now"
                onClick={() => removeSubscription(sub.id)}
              >
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">
              Unsubscribe
            </TooltipContent>
          </Tooltip>
        </div>
      </div>

      {/* ── Settings row ────────────────────────────────────────────────── */}
      <div className="flex flex-wrap items-center gap-2 px-3.5 pb-3">
        <label className="flex items-center gap-2 h-8 px-2.5 rounded-md border border-border/40 bg-background/40 cursor-pointer select-none">
          <Switch
            checked={!!sub.autoDownload}
            onCheckedChange={(checked) => updateSubscription(sub.id, { autoDownload: checked })}
            className="scale-[0.8]"
          />
          <span className="text-[11px] font-medium text-foreground/80 whitespace-nowrap">Auto-download</span>
        </label>

        <Select
          value={isAudio ? 'audio' : sub.quality}
          onValueChange={(value) => {
            if (value === 'audio') updateSubscription(sub.id, { type: 'mp3' });
            else updateSubscription(sub.id, { type: 'mp4', quality: value });
          }}
        >
          <SelectTrigger className="w-40 h-8 text-[11px] bg-background/40 border-border/40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {QUALITY_OPTIONS.map(o => (
              <SelectItem key={o.value} value={o.value} className="text-xs">{o.label}</SelectItem>
            ))}
            <SelectItem value="audio" className="text-xs">Audio only (MP3)</SelectItem>
          </SelectContent>
        </Select>

        <Select
          value={String(sub.intervalMinutes)}
          onValueChange={(value) => updateSubscription(sub.id, { intervalMinutes: Number(value) })}
        >
          <SelectTrigger className="w-44 h-8 text-[11px] bg-background/40 border-border/40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {INTERVAL_OPTIONS.map(o => (
              <SelectItem key={o.value} value={String(o.value)} className="text-xs">{o.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <button
          onClick={() => changeSubscriptionFolder(sub.id)}
          className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md border border-border/40 bg-background/40 text-[11px] text-muted-foreground hover:text-foreground hover:bg-secondary/40 transition-colors cursor-pointer max-w-56"
          title={sub.folderPath || sub.targetDir}
        >
          <FolderOpen className="h-3 w-3 shrink-0" />
          <span className="truncate">{folderName(sub.folderPath || sub.targetDir)}</span>
        </button>

        {activeDownload && (
          <span className="inline-flex items-center gap-2 ml-auto text-[11px] text-muted-foreground">
            <Progress value={activeDownload.percent} className="h-1 w-24" />
            {activeDownload.status === 'queued' ? 'Queued' : `${Math.round(activeDownload.percent)}%`}
          </span>
        )}
      </div>

      {/* ── Nothing pending: say so instead of leaving a blank strip ────── */}
      {videos.length === 0 && (
        <div className="border-t border-border/30 bg-background/20 flex items-center gap-2 px-3.5 py-2 text-[11px] text-muted-soft">
          <CheckCircle2 className="h-3 w-3 text-emerald-500/70 shrink-0" />
          <span>All caught up</span>
        </div>
      )}

      {/* ── Found videos ────────────────────────────────────────────────── */}
      {videos.length > 0 && (
        <div className="border-t border-border/30 bg-background/20">
          <button
            onClick={() => setExpanded(v => !v)}
            className="w-full flex items-center gap-2 px-3.5 py-2 text-[11px] text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
          >
            <Rss className="h-3 w-3" />
            <span className="font-medium">{videos.length} detected {videos.length === 1 ? 'video' : 'videos'}</span>
            <span className="ml-auto inline-flex items-center gap-1">
              {expanded ? 'Hide' : 'Show'}
              {expanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
            </span>
          </button>

          <div className="px-2.5 pb-2.5 flex flex-col gap-1">
            {visible.map(video => {
              const live = videoState(sub.id, video.id);
              const status = live?.status || video.status;
              return (
                <div
                  key={video.id}
                  className="flex items-center gap-2.5 rounded-lg px-2 py-1.5 hover:bg-secondary/30 transition-colors group"
                >
                  <div className="relative w-16 aspect-video rounded overflow-hidden shrink-0 bg-secondary/40 border border-border/30">
                    {video.thumbnail && (
                      <img src={video.thumbnail} alt="" className="w-full h-full object-cover" onError={thumbFallback} />
                    )}
                    {video.duration > 0 && (
                      <span className="absolute bottom-0.5 right-0.5 bg-black/75 text-white text-[8px] px-1 rounded font-semibold">
                        {formatDuration(video.duration)}
                      </span>
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[12px] text-foreground/90 truncate" title={video.title}>{video.title}</p>
                    <p className="text-[10px] text-muted-soft mt-0.5">found {timeAgo(video.detectedAt)}</p>
                  </div>
                  <StatusChip status={status} percent={live?.percent} />
                  {(status === 'found' || status === 'failed' || status === 'cancelled') && (
                    <Button
                      variant="ghost" size="sm"
                      className="h-7 px-2 text-[11px] gap-1 text-muted-foreground hover:text-foreground opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => downloadSubscriptionVideo(sub.id, video.id)}
                    >
                      <Download className="h-3 w-3" /> Download
                    </Button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

const EmptyState = ({ onOpen }) => (
  <div className="flex flex-col items-center justify-center h-full gap-5 text-center px-6">
    <div className="flex items-center justify-center w-14 h-14 rounded-2xl bg-secondary/40 border border-border/40">
      <BellRing className="h-6 w-6 text-muted-foreground" strokeWidth={1.6} />
    </div>
    <div className="max-w-sm space-y-1.5">
      <h3 className="text-[15px] font-semibold text-foreground">No subscriptions yet</h3>
    </div>
    <Button onClick={onOpen} className="h-9 px-4 text-xs gap-1.5">
      <Plus className="h-3.5 w-3.5" /> Add
    </Button>
  </div>
);

const SubscriptionsView = () => {
  const {
    subscriptions, subsNotice, setSubsNotice, subsBusyId, subsCheckProgress,
    addSubscription, checkSubscription, closeSubscriptions,
    exportSubscriptions, importSubscriptions,
    scanState, startSubscriptionScan, stopSubscriptionScan, setSubscriptionScanInterval,
    videoSettings,
  } = useAppContext();

  const [addOpen, setAddOpen] = useState(false);
  const [newUrl, setNewUrl] = useState('');
  const initialSubscriptionQuality = (videoSettings?.defaultQuality === 'hd720' || videoSettings?.defaultQuality === 'hd480')
    ? videoSettings.defaultQuality
    : 'best';
  const [newQuality, setNewQuality] = useState(initialSubscriptionQuality);
  const [newType, setNewType] = useState(videoSettings?.defaultQuality === 'mp3' ? 'mp3' : 'mp4');
  const [newAuto, setNewAuto] = useState(true);
  const [newExisting, setNewExisting] = useState(false);
  const [newInterval, setNewInterval] = useState(15);
  const [newDir, setNewDir] = useState('');

  React.useEffect(() => {
    window.electronAPI.getLastSubscriptionDir?.().then(dir => { if (dir) setNewDir(dir); }).catch(() => {});
  }, []);

  const adding = subsBusyId === 'add';
  const scanning = !!scanState?.running;
  const checkingAll = subsBusyId === 'all' || !!subsCheckProgress;
  const [ioBusy, setIoBusy] = useState(false);

  const handleExport = async () => {
    if (ioBusy) return;
    setIoBusy(true);
    try {
      const res = await exportSubscriptions();
      if (res?.success) {
        setSubsNotice({ kind: 'ok', text: `Exported ${res.count} subscription(s) to ${res.path}` });
      } else if (!res?.canceled) {
        setSubsNotice({ kind: 'error', text: res?.error || 'Export failed.' });
      }
    } catch (err) {
      setSubsNotice({ kind: 'error', text: err?.message || 'Export failed.' });
    } finally {
      setIoBusy(false);
    }
  };

  const handleImport = async () => {
    if (ioBusy) return;
    setIoBusy(true);
    try {
      const res = await importSubscriptions();
      if (res?.success) {
        setSubsNotice({ kind: 'ok', text: res.message || `Imported ${res.added} subscription(s).` });
      } else if (!res?.canceled) {
        setSubsNotice({ kind: 'error', text: res?.error || 'Import failed.' });
      }
    } catch (err) {
      setSubsNotice({ kind: 'error', text: err?.message || 'Import failed.' });
    } finally {
      setIoBusy(false);
    }
  };

  const queuedCount = useMemo(
    () => subscriptions.reduce(
      (acc, s) => acc + (s.newVideos || []).filter(v => v.status === 'queued').length, 0
    ),
    [subscriptions]
  );

  const pickFolder = async () => {
    const dir = await window.electronAPI.pickSubscriptionFolder();
    if (dir) setNewDir(dir);
  };

  const handleAdd = async () => {
    if (!newUrl.trim()) return;
    const res = await addSubscription({
      url: newUrl.trim(),
      quality: newQuality,
      type: newType,
      autoDownload: newAuto,
      downloadExisting: newExisting,
      intervalMinutes: newInterval,
      targetDir: newDir || undefined,
    });
    if (res?.success) {
      setNewUrl('');
      setNewExisting(false);
      setAddOpen(false);
    }
  };

  return (
    <div className="flex flex-col h-full min-h-0">
      {/* Header */}
      <div className="flex-none border-b border-border/40 pb-3.5 space-y-3">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost" size="icon"
            aria-label="Back"
            onClick={closeSubscriptions}
            className="shrink-0 h-8 w-8 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1 min-w-0">
            <h2 className="text-lg font-semibold truncate tracking-tight text-foreground leading-tight flex items-center gap-2">
              <Bell className="h-4 w-4 text-muted-foreground shrink-0" />
              Subscriptions
            </h2>
            <ScanBadge running={scanning} />
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost" size="icon"
                  aria-label="Export subscriptions"
                  className="h-8 w-8 text-muted-foreground hover:text-foreground"
                  disabled={ioBusy || subscriptions.length === 0}
                  onClick={handleExport}
                >
                  {ioBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="text-xs">Export</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost" size="icon"
                  aria-label="Import subscriptions"
                  className="h-8 w-8 text-muted-foreground hover:text-foreground"
                  disabled={ioBusy}
                  onClick={handleImport}
                >
                  <Upload className="h-3.5 w-3.5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="text-xs">Import</TooltipContent>
            </Tooltip>
            <Select
              value={String(scanState?.intervalMinutes || 15)}
              onValueChange={(v) => setSubscriptionScanInterval(Number(v))}
            >
              <SelectTrigger className="w-44 h-8 text-[11px] bg-background/40 border-border/40 whitespace-nowrap">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {INTERVAL_OPTIONS.map(o => (
                  <SelectItem key={o.value} value={String(o.value)} className="text-xs">{o.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant={scanning ? 'secondary' : 'default'}
              size="sm"
              className="h-8 text-xs gap-1.5"
              onClick={() => (scanning ? stopSubscriptionScan() : startSubscriptionScan())}
              aria-pressed={scanning}
            >
              {scanning
                ? <><Pause className="h-3.5 w-3.5" /> Stop Scan</>
                : <><Play className="h-3.5 w-3.5" /> Start Scan</>}
            </Button>
            {subscriptions.length > 0 && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost" size="icon"
                    className="h-8 w-8 text-muted-foreground hover:text-foreground"
                    onClick={() => checkSubscription(null)}
                    disabled={checkingAll}
                    aria-label="Scan all now"
                  >
                    {checkingAll ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="bottom" className="text-xs">Scan all now</TooltipContent>
              </Tooltip>
            )}
            <Button
              size="sm"
              className="h-8 text-xs gap-1.5"
              onClick={() => setAddOpen(v => !v)}
            >
              {addOpen ? <X className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
              {addOpen ? 'Cancel' : 'Follow'}
            </Button>
          </div>
        </div>

        {/* Add panel */}
        {addOpen && (
          <div className="ml-11 flex flex-col gap-2.5 animate-in fade-in slide-in-from-top-1 duration-150">
            <div className="flex items-center gap-2">
              <Input
                autoFocus
                value={newUrl}
                onChange={(e) => setNewUrl(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') handleAdd(); }}
                placeholder="Playlist or channel link"
                className="h-9 bg-card border-border/50 text-xs flex-1"
              />
              <Button size="sm" className="h-9 px-4 text-xs gap-1.5" onClick={handleAdd} disabled={!newUrl.trim() || adding}>
                {adding ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Rss className="h-3.5 w-3.5" />}
                {adding ? 'Reading feed…' : 'Subscribe'}
              </Button>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Select value={newType === 'mp3' ? 'audio' : newQuality} onValueChange={(v) => {
                if (v === 'audio') { setNewType('mp3'); }
                else { setNewType('mp4'); setNewQuality(v); }
              }}>
                <SelectTrigger className="w-40 h-8 text-[11px] bg-background/40 border-border/40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {QUALITY_OPTIONS.map(o => (
                    <SelectItem key={o.value} value={o.value} className="text-xs">{o.label}</SelectItem>
                  ))}
                  <SelectItem value="audio" className="text-xs">Audio only (MP3)</SelectItem>
                </SelectContent>
              </Select>

              <Select value={String(newInterval)} onValueChange={(v) => setNewInterval(Number(v))}>
                <SelectTrigger className="w-44 h-8 text-[11px] bg-background/40 border-border/40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {INTERVAL_OPTIONS.map(o => (
                    <SelectItem key={o.value} value={String(o.value)} className="text-xs">{o.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <label className="flex items-center gap-2 h-8 px-2.5 rounded-md border border-border/40 bg-background/40 cursor-pointer select-none">
                <Switch checked={newAuto} onCheckedChange={setNewAuto} className="scale-[0.8]" />
                <span className="text-[11px] font-medium text-foreground/80 whitespace-nowrap">Auto-download</span>
              </label>

              <label className="flex items-center gap-2 h-8 px-2.5 rounded-md border border-border/40 bg-background/40 cursor-pointer select-none">
                <Switch checked={newExisting} onCheckedChange={setNewExisting} className="scale-[0.8]" />
                <span className="text-[11px] font-medium text-foreground/80 whitespace-nowrap">Also grab existing videos</span>
              </label>

              <button
                onClick={pickFolder}
                className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md border border-border/40 bg-background/40 text-[11px] text-muted-foreground hover:text-foreground hover:bg-secondary/40 transition-colors cursor-pointer max-w-56"
                title={newDir || 'Choose a download folder'}
              >
                <FolderOpen className="h-3 w-3 shrink-0" />
                <span className="truncate">{newDir ? folderName(newDir) : 'Choose folder…'}</span>
              </button>
            </div>
          </div>
        )}

        {/* Sequential Check all progress — one playlist at a time */}
        {subsCheckProgress && subsCheckProgress.phase !== 'finished' && (
          <div className="ml-11 flex items-center gap-2 rounded-lg border border-primary/25 bg-primary/[0.05] px-3 py-2">
            <Loader2 className="h-3.5 w-3.5 text-primary shrink-0 animate-spin" />
            <span className="text-[11.5px] text-muted-foreground flex-1">
              {subsCheckProgress.phase === 'starting'
                ? 'Preparing playlists…'
                : `Checking ${subsCheckProgress.index} of ${subsCheckProgress.total}: ${subsCheckProgress.title}…`}
            </span>
            {subsCheckProgress.total > 0 && (
              <span className="text-[10px] font-semibold tabular-nums text-primary/70 shrink-0">
                {subsCheckProgress.index}/{subsCheckProgress.total}
              </span>
            )}
          </div>
        )}

        {/* Notice */}
        {subsNotice && (
          <div className="ml-11 flex items-center gap-2 rounded-lg border border-border/40 bg-secondary/20 px-3 py-2">
            {subsNotice.kind === 'error'
              ? <AlertCircle className="h-3.5 w-3.5 text-destructive shrink-0" />
              : <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 shrink-0" />}
            <span className="text-[11.5px] text-muted-foreground flex-1">{subsNotice.text}</span>
            <button
              onClick={() => setSubsNotice(null)}
              className="text-muted-foreground/60 hover:text-foreground transition-colors cursor-pointer"
              aria-label="Dismiss"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* List */}
      <ScrollArea className="flex-1 -mx-2 px-2">
        {subscriptions.length === 0 ? (
          <EmptyState onOpen={() => setAddOpen(true)} />
        ) : (
          <div className="flex flex-col gap-2.5 py-3.5 pb-6">
            {subscriptions.map(sub => <SubscriptionCard key={sub.id} sub={sub} />)}
          </div>
        )}
      </ScrollArea>
    </div>
  );
};

export default SubscriptionsView;
