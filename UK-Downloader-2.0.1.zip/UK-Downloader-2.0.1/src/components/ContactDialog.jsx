import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { KeyRound, AlertTriangle } from 'lucide-react';
import { BY_USMAN_QR } from '../assets/by-usman-qr';

const ContactDialog = ({ open, onOpenChange, limitReached = false, onEnterKey }) => (
  <Dialog open={open} onOpenChange={onOpenChange}>
    <DialogContent className="sm:max-w-[420px] p-0 overflow-hidden gap-0">
      <DialogHeader className="px-5 pt-5 pb-3 text-left">
        <DialogTitle className="text-base">By Usman</DialogTitle>
        <DialogDescription className="text-xs">
          WhatsApp · 0319-0199369
        </DialogDescription>
      </DialogHeader>

      {limitReached && (
        <div className="mx-5 mb-3 flex items-start gap-2.5 rounded-xl border border-amber-500/30 bg-amber-500/10 px-3.5 py-2.5">
          <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0 text-amber-500" />
          <div className="min-w-0">
            <p className="text-xs font-semibold text-amber-600 dark:text-amber-400">
              Daily limit reached — 10/10 videos
            </p>
          </div>
        </div>
      )}

      <div className="px-5 pb-5">
        <div className="max-h-[58vh] overflow-y-auto rounded-xl border border-border/40 bg-white">
          <img
            src={BY_USMAN_QR}
            alt="WhatsApp contact QR card for Usman"
            className="block w-full h-auto"
          />
        </div>

        {limitReached && onEnterKey && (
          <Button
            variant="default"
            size="sm"
            className="w-full mt-3 h-9 text-xs gap-1.5"
            onClick={onEnterKey}
          >
            <KeyRound className="h-3.5 w-3.5" />
            Enter Pro key
          </Button>
        )}

      </div>
    </DialogContent>
  </Dialog>
);

export default ContactDialog;
