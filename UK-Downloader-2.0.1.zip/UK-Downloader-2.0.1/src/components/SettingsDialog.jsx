import React, { useEffect, useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { useTheme } from '../contexts/ThemeContext';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { PARALLEL_PRESETS, PARALLEL_MIN, PARALLEL_MAX, PARALLEL_DEFAULT, clampParallel } from '../lib/parallel.mjs';
import {
  CheckCircle2, LogOut, Loader2,
  AlertTriangle, Check, FolderOpen,
  RefreshCw, DownloadCloud, Layers, Music2,
} from 'lucide-react';

const GoogleIcon = (props) => (
  <svg viewBox="0 0 24 24" {...props}>
    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
  </svg>
);

const SettingsDialog = () => {
  const {
    isSettingsOpen,
    settingsTab,
    openSettings,
    closeSettings,
    isAuthenticated,
    authExpired,
    loginYoutube,
    logoutYoutube,
    refreshAuth,
    videoSettings,
    updateVideoSettings,
    ytDlpEngine,
    checkYtDlpUpdate,
    downloadYtDlp,
  } = useAppContext();

  const { preference, theme, resolved, setPreference } = useTheme();
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [customParallel, setCustomParallel] = useState('');

  // Clear the custom box when a preset (or another window) changes the value.
  useEffect(() => { setCustomParallel(''); }, [videoSettings?.parallel]);

  const applyCustomParallel = () => {
    const n = clampParallel(customParallel, Number(videoSettings?.parallel) || PARALLEL_DEFAULT);
    updateVideoSettings({ parallel: n });
    setCustomParallel('');
  };

  // yt-dlp engine panel — live phase, version and timestamps from main.js.
  const engine = ytDlpEngine || {};
  const enginePhase = engine.phase || 'idle';
  const engineBusy = ['checking', 'downloading', 'installing'].includes(enginePhase);
  const engineBadge = {
    idle: 'Idle',
    checking: 'Checking…',
    downloading: 'Downloading…',
    installing: 'Installing…',
    updated: 'Updated',
    'up-to-date': 'Up to date',
    postponed: 'Postponed',
    error: 'Failed',
  }[enginePhase] || enginePhase;
  const engineTone = enginePhase === 'updated' || enginePhase === 'up-to-date'
    ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
    : enginePhase === 'error'
      ? 'border-destructive/30 bg-destructive/10 text-destructive'
      : 'border-primary/25 bg-primary/10 text-primary';
  const fmtTime = (iso) => {
    if (!iso) return '';
    try { return new Date(iso).toLocaleString(); } catch { return ''; }
  };

  const handleLogin = async () => {
    setIsLoggingIn(true);
    await loginYoutube();
    setIsLoggingIn(false);
  };

  return (
    <AlertDialog open={isSettingsOpen} onOpenChange={(open) => { 
      if (open) {
        refreshAuth();
      } else {
        closeSettings();
      }
    }}>
      <AlertDialogContent className="sm:max-w-md bg-background border border-border/30 shadow-2xl p-0 overflow-hidden outline-none rounded-xl gap-0 flex flex-col h-[510px]">
        
        {/* Radix requires a title for screen readers; the visible header is the
            tab row, so this names the dialog without changing the layout. */}
        <AlertDialogTitle className="sr-only">Settings</AlertDialogTitle>

        {/* Header Tabs */}
        <div className="flex items-center px-4 pt-4 pb-0 border-b border-border/30 shrink-0">
          <button
            onClick={() => openSettings('general')}
            className={`px-4 py-2 text-sm font-medium border-b-2 cursor-pointer transition-colors ${
              settingsTab === 'general'
                ? 'border-primary text-foreground'
                : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border/60'
            }`}
          >
            General
          </button>
          <button
            onClick={() => openSettings('video')}
            className={`px-4 py-2 text-sm font-medium border-b-2 cursor-pointer transition-colors ${
              settingsTab === 'video'
                ? 'border-primary text-foreground'
                : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border/60'
            }`}
          >
            Video
          </button>
          <button
            onClick={() => openSettings('account')}
            className={`px-4 py-2 text-sm font-medium border-b-2 cursor-pointer transition-colors ${
              settingsTab === 'account'
                ? 'border-primary text-foreground'
                : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border/60'
            }`}
          >
            Account
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto px-5 py-5">
          {settingsTab === 'general' ? (
            <div className="space-y-5 animate-in fade-in zoom-in-95 duration-200">
              
              {/* yt-dlp engine — auto-download / auto-update, visible here */}
              <section className="space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-soft">yt-dlp engine</h3>
                <div className="rounded-xl px-4 py-3.5 border border-border/40 bg-secondary/25 space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-medium text-foreground">Auto-download &amp; update</span>
                        <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold shrink-0 ${engineTone}`}>
                          {engineBusy && <Loader2 className="h-3 w-3 animate-spin" />}
                          {engineBadge}
                        </span>
                      </div>
                      {engine.message && (
                        <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                          {engine.message}
                        </p>
                      )}
                      <p className="text-[11px] text-muted-foreground/80 mt-1">
                        Version {engine.version || '—'}
                        {engine.previousVersion && engine.previousVersion !== engine.version
                          ? ` · was ${engine.previousVersion}` : ''}
                      </p>
                      <p className="text-[11px] text-muted-foreground/80">
                        {engine.lastChecked ? `Checked ${fmtTime(engine.lastChecked)}` : 'Not checked yet'}
                        {engine.lastUpdated ? ` · updated ${fmtTime(engine.lastUpdated)}` : ''}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Button
                      size="sm"
                      variant="secondary"
                      className="h-8 text-xs px-3 shrink-0 gap-1.5 bg-background hover:bg-secondary/80 border border-border/40 transition-colors"
                      disabled={engineBusy}
                      onClick={checkYtDlpUpdate}
                    >
                      <RefreshCw className="h-3.5 w-3.5" />
                      Check for updates
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-8 text-xs px-3 shrink-0 gap-1.5 text-muted-foreground hover:text-foreground"
                      disabled={engineBusy}
                      onClick={downloadYtDlp}
                    >
                      <DownloadCloud className="h-3.5 w-3.5" />
                      Re-download engine
                    </Button>
                  </div>
                </div>
              </section>

              {/* Appearance */}
              <section className="space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-soft">Appearance</h3>
                <div className="flex items-center justify-between rounded-xl px-4 py-3.5 border border-border/40 bg-secondary/25">
                  <div className="flex flex-col gap-0.5 min-w-0 flex-1 pr-4">
                    <span className="text-sm font-medium text-foreground">Theme</span>
                  </div>
                  
                  {/* Segmented Control — the resolved theme is what the buttons
                      compare against, so "system" lights up whichever it picked. */}
                  <div className="flex items-center bg-background/60 border border-border/40 rounded-lg p-0.5 shrink-0">
                    {[
                      { key: 'light', label: 'Light' },
                      { key: 'forest', label: 'Forest' },
                      { key: 'dark', label: 'Dark' },
                    ].map(({ key, label }) => {
                      const active = resolved === key ||
                        (preference === 'system' && theme === key);
                      return (
                        <button
                          key={key}
                          onClick={() => setPreference(key)}
                          className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer transition-all ${
                            active
                              ? 'bg-secondary text-foreground shadow-sm border border-border/50'
                              : 'text-muted-foreground hover:text-foreground border border-transparent'
                          }`}
                        >
                          {label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </section>

            </div>
          ) : settingsTab === 'video' ? (
            <div className="space-y-5 animate-in fade-in zoom-in-95 duration-200">

              {/* Default format / quality preset */}
              <section className="space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-soft flex items-center gap-1.5">
                  <Music2 className="h-3.5 w-3.5" /> Default format &amp; quality
                </h3>
                <div className="rounded-xl border border-border/40 bg-secondary/25 divide-y divide-border/30 overflow-hidden">
                  {[
                    { value: 'hd720', title: '720p HD' },
                    { value: 'hd480', title: '480p HD' },
                    { value: 'mp3', title: 'MP3 audio' },
                    { value: 'ask', title: 'Ask me every time' },
                  ].map((opt) => {
                    const active = (videoSettings?.defaultQuality || 'hd720') === opt.value;
                    return (
                      <button
                        key={opt.value}
                        onClick={() => updateVideoSettings({ defaultQuality: opt.value })}
                        className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-secondary/40 transition-colors cursor-pointer"
                      >
                        <span className={`flex items-center justify-center w-4 h-4 rounded-full border shrink-0 ${
                          active ? 'border-primary bg-primary text-primary-foreground' : 'border-border/60 bg-background'
                        }`}>
                          {active && <Check className="w-2.5 h-2.5" strokeWidth={3} />}
                        </span>
                        <span className="flex-1 min-w-0">
                          <span className="block text-sm font-medium text-foreground">{opt.title}</span>
                        </span>
                      </button>
                    );
                  })}
                </div>
              </section>

              {/* Parallel downloads + per-video fragment connections */}
              <section className="space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-soft flex items-center gap-1.5">
                  <Layers className="h-3.5 w-3.5" /> Connections
                </h3>
                <div className="rounded-xl border border-border/40 bg-secondary/25 p-3.5">
                  <div className="flex items-center gap-2">
                    {PARALLEL_PRESETS.map((n) => {
                      const active = Number(videoSettings?.parallel || PARALLEL_DEFAULT) === n;
                      return (
                        <button
                          key={n}
                          onClick={() => updateVideoSettings({ parallel: n })}
                          className={`flex-1 h-9 rounded-md border text-sm font-medium transition-colors cursor-pointer ${
                            active
                              ? 'border-primary bg-primary text-primary-foreground'
                              : 'border-border/50 bg-background/50 text-muted-foreground hover:text-foreground hover:bg-secondary/60'
                          }`}
                        >
                          {n}
                        </button>
                      );
                    })}
                  </div>

                  <div className="mt-2.5 flex items-center gap-2">
                    <span className="text-[11px] text-muted-foreground whitespace-nowrap">Custom {PARALLEL_MIN}–{PARALLEL_MAX}</span>
                    <Input
                      type="number"
                      min={PARALLEL_MIN}
                      max={PARALLEL_MAX}
                      step="1"
                      inputMode="numeric"
                      value={customParallel}
                      onChange={(e) => setCustomParallel(e.target.value)}
                      onKeyDown={(e) => { if (e.key === 'Enter') applyCustomParallel(); }}
                      placeholder={String(PARALLEL_DEFAULT)}
                      className="h-9 w-20 bg-background/50 border-border/50 px-2 text-center text-sm tabular-nums"
                      aria-label="Custom connection count"
                    />
                    <button
                      onClick={applyCustomParallel}
                      className="h-9 px-3 rounded-md border border-border/50 bg-background/50 text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-secondary/60 transition-colors cursor-pointer"
                    >
                      Apply
                    </button>
                  </div>

                </div>
              </section>

              {/* Keyword / song search */}
              <section className="space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-soft flex items-center gap-1.5">
                  <Music2 className="h-3.5 w-3.5" /> Search
                </h3>
                <div className="rounded-xl border border-border/40 bg-secondary/25 p-3.5 space-y-2.5">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex flex-col gap-0.5 min-w-0">
                      <span className="text-sm font-medium text-foreground">Results to download</span>
                    </div>
                    <input
                      type="number"
                      min="1"
                      max="50"
                      value={Number(videoSettings?.keywordLimit || 1)}
                      onChange={(e) => {
                        const raw = e.target.value;
                        if (raw === '') return;
                        const n = Math.round(Number(raw));
                        if (Number.isFinite(n)) updateVideoSettings({ keywordLimit: Math.min(50, Math.max(1, n)) });
                      }}
                      className="w-16 h-9 shrink-0 rounded-md border border-border/50 bg-background/50 px-2 text-center text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                      aria-label="Keyword search result limit"
                    />
                  </div>
                </div>
              </section>

              {/* Playlist file numbering — filename only, OFF by default */}
              <section className="space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-soft flex items-center gap-1.5">
                  <Music2 className="h-3.5 w-3.5" /> Playlist file numbering
                </h3>
                <div className="rounded-xl border border-border/40 bg-secondary/25 p-3.5 flex items-center justify-between gap-3">
                  <div className="flex flex-col gap-0.5 min-w-0">
                    <span className="text-sm font-medium text-foreground">Number playlist downloads</span>
                  </div>
                  <Switch
                    checked={!!videoSettings?.playlistNumbering}
                    onCheckedChange={(c) => updateVideoSettings({ playlistNumbering: !!c })}
                    className="shrink-0"
                  />
                </div>
              </section>

              {/* Direct save */}
              <section className="space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-soft">Single videos</h3>
                <div className="rounded-xl border border-border/40 bg-secondary/25 overflow-hidden">
                  <div className="flex items-center justify-between gap-3.5 px-4 py-3.5">
                    <div className="flex flex-col gap-0.5 min-w-0 flex-1">
                      <span className="text-sm font-medium text-foreground">Download in one click</span>
                    </div>
                    <Switch
                      checked={!!videoSettings?.directSave}
                      onCheckedChange={(checked) => updateVideoSettings({ directSave: checked })}
                    />
                  </div>
                  <div className="flex items-center gap-2 px-4 py-3 border-t border-border/30">
                    <button
                      onClick={async () => {
                        const dir = await window.electronAPI.chooseDirectory();
                        if (dir) updateVideoSettings({ directSaveDir: dir });
                      }}
                      className="inline-flex items-center gap-2 h-8 px-3 rounded-md border border-border/40 bg-background/50 hover:bg-secondary/50 transition-colors cursor-pointer min-w-0 max-w-[300px]"
                    >
                      <FolderOpen className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                      <span className="text-xs text-foreground/80 truncate">
                        {videoSettings?.directSaveDir || 'Choose a folder…'}
                      </span>
                    </button>
                  </div>
                </div>
              </section>

            </div>
          ) : (
            <div className="space-y-5 animate-in fade-in zoom-in-95 duration-200">
              
              {/* YouTube Account */}
              <section className="space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-soft">YouTube Account</h3>
                {isAuthenticated ? (
                  <div className="rounded-xl border border-border/40 bg-secondary/25 px-4 py-3.5 flex items-center gap-3.5">
                    <div className="flex items-center justify-center w-9 h-9 rounded-full bg-background border border-border/50 shrink-0">
                      <GoogleIcon className="w-4.5 h-4.5" />
                    </div>
                    <div className="flex flex-col gap-0.5 min-w-0 flex-1">
                      <span className="text-sm font-medium text-foreground flex items-center gap-1.5">
                        Signed in
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500/80" />
                      </span>
                      <span className="text-xs text-muted-foreground">Age-restricted downloads enabled</span>
                    </div>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 text-xs gap-1.5 px-2.5 text-muted-foreground hover:text-foreground shrink-0">
                          <LogOut className="w-3.5 h-3.5" />
                          Sign out
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Sign out of YouTube?</AlertDialogTitle>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={logoutYoutube} className="bg-destructive text-white hover:bg-destructive/90">
                            Sign Out
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                ) : (
                  <div className="rounded-xl border border-border/40 bg-secondary/25 p-4 space-y-3.5">
                    {authExpired ? (
                      <div className="flex items-start gap-2.5">
                        <AlertTriangle className="w-4 h-4 text-amber-500/80 mt-0.5 shrink-0" />
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Your session has expired. Sign in again.
                        </p>
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        Sign in to download age-restricted videos.
                      </p>
                    )}
                    <Button
                      variant="default"
                      size="sm"
                      onClick={handleLogin}
                      disabled={isLoggingIn}
                      className="w-full h-9 bg-white text-neutral-900 border border-black/10 hover:bg-neutral-50 dark:border-transparent dark:hover:bg-white/90 shadow-sm transition-all"
                    >
                      {isLoggingIn ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : (
                        <GoogleIcon className="w-4 h-4 mr-2" />
                      )}
                      <span className="font-medium text-sm">Sign in with Google</span>
                    </Button>
                  </div>
                )}
              </section>

            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-4 bg-muted/20 border-t border-border/30 flex items-center justify-between gap-2 shrink-0">
          {/* No native `title` alongside this: the OS tooltip would surface a
              second copy a beat after the styled one. aria-label still carries
              the accessible name. */}
          <span className="text-[11px] text-muted-foreground">
            UK Downloader
          </span>
          
          <Button variant="outline" size="sm" className="h-8 px-4 text-xs font-medium m-0 bg-background" onClick={closeSettings}>
            Close
          </Button>
        </div>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default SettingsDialog;
