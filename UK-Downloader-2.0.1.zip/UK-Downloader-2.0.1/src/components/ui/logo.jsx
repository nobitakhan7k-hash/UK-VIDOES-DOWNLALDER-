import React from 'react';
import { UK_LOGO } from '../../assets/uk-logo';

/** Usman's real UK Vidoes Downloader badge (transparent PNG, data URI). */
const Logo = (props) => (
  <img src={UK_LOGO} alt="UK Downloader" draggable={false} {...props} />
);

export { Logo };
