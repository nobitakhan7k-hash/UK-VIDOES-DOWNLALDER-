import React, { useState, useEffect, useCallback } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import {
  ListVideo, ArrowLeft, Download, Loader2, Trash2, Music2, ExternalLink,
} from 'lucide-react';

const PlaylistsView = () => {
  const {
    openUrl, closePlaylists, showAppNotice, videoSettings,
    autoSubscribeDropped, updateAutoSubscribeDropped,
  } = useAppContext();

  const [url, setUrl] = useState('');
  const [recent, setRecent] = useState([]);
  const [loaded, setLoaded] = useState(null);
  const [busyUrl, setBusyUrl] = useState('');

  useEffect(() => {
    window.electronAPI.playlistHubList()
      .then(list => setRecent(Array.isArray(list) ? list : []))
      .catch(() => {});
  }, []);

  const loadPlaylist = useCallback(async (rawUrl) => {
    const link = String(rawUrl || '').trim();
    if (!link) {
      showAppNotice('error', 'Paste a playlist link first.');
      return null;
    }
    setBusyUrl(link);
    try {
      const res = await window.electronAPI.getPlaylistInfo(link).catch(err => ({ success: false, error: err?.message || 'Could not read that playlist.' }));
      if (!res?.success) {
        showAppNotice('error', res?.error || 'Could not read that playlist.');
        return null;
      }
      const data = { url: link, ...res };
      setLoaded(data);
      const hub = await window.electronAPI.playlistHubAdd({
        url: link,
        title: data.title,
        uploader: data.uploader,
        videoCount: (data.videos || []).length,
        thumbnail: data.videos?.[0]?.thumbnail || '',
      }).catch(() => null);
      if (hub?.list) setRecent(hub.list);
      return data;
    } finally {
      setBusyUrl('');
    }
  }, [showAppNotice]);

  const downloadWhole = useCallback(async (rawUrl, known = null) => {
    const link = String(rawUrl || '').trim();
    if (!link) return;
    setBusyUrl(link);
    try {
      const data = known || await loadPlaylist(link);
      if (!data) return;

      const settings = await window.electronAPI.getVideoSettings().catch(() => ({
        defaultQuality: 'hd720', directSave: true, directSaveDir: '',
      }));
      const targetDir = settings.directSaveDir || await window.electronAPI.getDefaultDownloadDir().catch(() => '');
      if (!targetDir) {
        showAppNotice('error', 'Choose a download folder in Settings → Video.');
        return;
      }

      const preset = settings.defaultQuality || 'hd720';
      const wantsMp3 = preset === 'mp3';
      const quality = (preset === 'ask' || wantsMp3) ? 'hd720' : preset;
      const qualityLabel = wantsMp3 ? 'MP3' : quality === 'hd720' ? '720p HD' : quality === 'hd480' ? '480p HD' : 'Best';
      const defaultType = wantsMp3 ? 'mp3' : 'mp4';

      const items = (data.videos || []).map(v => ({
        videoId: v.id,
        url: v.url,
        title: v.title,
        // REAL yt-dlp playlist_index (1-based, gaps preserved). Only the
        // filename is affected, and only when the Settings switch is ON.
        playlistIndex: v.playlistIndex ?? null,
        thumbnailUrl: v.thumbnail || '',
        quality,
        qualityLabel,
        type: defaultType,
        convertToH264: false,
        sizeBytes: 0,
      }));
      if (!items.length) {
        showAppNotice('error', 'No downloadable videos were found in that playlist.');
        return;
      }

      const result = await window.electronAPI.queueVideoBatch({ items, targetDir })
        .catch(err => ({ success: false, error: err?.message || 'Could not start downloads.' }));
      if (!result?.success) {
        showAppNotice('error', result?.error || 'Could not start downloads.');
        return;
      }
      if (result.partial) {
        showAppNotice('warning', `Daily limit: ${result.queued} of ${result.total} videos queued; ${result.skipped} skipped. Activate a Pro key for the whole playlist.`);
      } else {
        showAppNotice('success', `Whole playlist queued: ${result.queued || items.length} videos.`);
      }
    } finally {
      setBusyUrl('');
    }
  }, [loadPlaylist, showAppNotice]);

  const openSelection = (link) => {
    if (!link) return;
    openUrl(link);
  };

  const removeRecent = async (link) => {
    const res = await window.electronAPI.playlistHubRemove(link).catch(() => null);
    if (res?.list) setRecent(res.list);
    if (loaded?.url === link) setLoaded(null);
  };

  const numberingOn = !!videoSettings?.playlistNumbering;

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex-none flex items-center gap-3 border-b border-border/40 pb-3.5">
        <Button variant="ghost" size="icon" aria-label="Back" onClick={closePlaylists} className="shrink-0 h-8 w-8 text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex-1 min-w-0">
          <h2 className="text-lg font-semibold tracking-tight text-foreground leading-tight flex items-center gap-2">
            <ListVideo className="h-4.5 w-4.5 text-muted-foreground shrink-0" />
            Playlists
          </h2>
        </div>
      </div>

      {/* Paste + load */}
      <div className="flex-none flex items-center gap-2 py-3">
        <Input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') loadPlaylist(url); }}
          placeholder="Playlist link"
          aria-label="Playlist link"
          className="h-9 text-xs"
        />
        <Button size="sm" className="h-9 text-xs gap-1.5 shrink-0" onClick={() => loadPlaylist(url)} disabled={!!busyUrl}>
          {busyUrl ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ExternalLink className="h-3.5 w-3.5" />}
          Load
        </Button>
      </div>

      {/* Loaded playlist */}
      {loaded && (
        <div className="flex-none rounded-xl border border-border/40 bg-secondary/20 p-3.5 mb-3">
          <div className="flex items-start gap-3">
            {loaded.videos?.[0]?.thumbnail ? (
              <img src={loaded.videos[0].thumbnail} alt="" className="w-24 aspect-video rounded-md object-cover shrink-0" />
            ) : (
              <div className="w-24 aspect-video rounded-md bg-secondary/40 flex items-center justify-center shrink-0">
                <ListVideo className="h-5 w-5 text-muted-foreground" />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-foreground truncate">{loaded.title}</p>
              <p className="text-[11px] text-muted-foreground truncate mt-0.5">
                {loaded.videos?.length || 0} videos • {loaded.uploader || 'Unknown'}
              </p>
              <p className="text-[11px] text-muted-soft mt-1 truncate">{loaded.url}</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2 mt-3">
            <Button size="sm" className="h-8 text-xs gap-1.5" onClick={() => downloadWhole(loaded.url, loaded)} disabled={!!busyUrl}>
              {busyUrl ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
              Download all
            </Button>
            <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={() => openSelection(loaded.url)}>
              <ListVideo className="h-3.5 w-3.5" />
              Select
            </Button>
          </div>
        </div>
      )}

      {/* Settings / rule strip */}
      <div className="flex-none flex flex-wrap items-center gap-2 rounded-xl border border-border/40 bg-secondary/15 px-3.5 py-2.5 mb-3">
        <label className="flex items-center gap-2 cursor-pointer select-none">
          <Switch checked={!!autoSubscribeDropped} onCheckedChange={(c) => updateAutoSubscribeDropped(!!c)} className="h-3.5 w-7" />
          <span className="text-[11px] font-medium text-foreground/80">Auto-subscribe drops</span>
        </label>
        <div className="h-3.5 w-px bg-border/60" />
        <span className="text-[11px] text-muted-foreground flex items-center gap-1.5">
          <Music2 className="h-3 w-3" />
          Global {videoSettings?.defaultQuality === 'mp3' ? 'MP3' : videoSettings?.defaultQuality === 'hd480' ? '480p HD' : '720p HD'}
        </span>
        <div className="h-3.5 w-px bg-border/60" />
        <span className="text-[11px] text-muted-soft flex items-center gap-1.5">
          Numbering {numberingOn ? 'ON' : 'OFF'}
        </span>
      </div>

      {/* Recent playlists */}
      <div className="flex-1 min-h-0 overflow-y-auto">
        <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-soft mb-2">Recent</p>
        {recent.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border/50 py-10 text-center">
            <ListVideo className="h-6 w-6 text-muted-foreground/50 mx-auto mb-2" />
            <p className="text-xs text-muted-foreground">No playlists yet.</p>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {recent.map((p) => (
              <div key={p.url} className="flex items-center gap-3 rounded-xl border border-border/40 bg-secondary/10 p-2.5">
                {p.thumbnail ? (
                  <img src={p.thumbnail} alt="" className="w-20 aspect-video rounded-md object-cover shrink-0" />
                ) : (
                  <div className="w-20 aspect-video rounded-md bg-secondary/40 flex items-center justify-center shrink-0">
                    <ListVideo className="h-4 w-4 text-muted-foreground" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-foreground truncate">{p.title}</p>
                  <p className="text-[10.5px] text-muted-foreground truncate mt-0.5">
                    {p.videoCount || 0} videos • {p.uploader || 'Unknown'}
                  </p>
                  <p className="text-[10px] text-muted-soft truncate mt-0.5">{p.url}</p>
                </div>
                <div className="flex items-center gap-0.5 shrink-0">
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openSelection(p.url)} aria-label="Open playlist">
                        <ListVideo className="h-3.5 w-3.5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="top" className="text-xs">Select</TooltipContent>
                  </Tooltip>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => downloadWhole(p.url)} disabled={!!busyUrl} aria-label="Download whole playlist">
                        {busyUrl === p.url ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="top" className="text-xs">Download all</TooltipContent>
                  </Tooltip>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => removeRecent(p.url)} aria-label="Remove from recent">
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="top" className="text-xs">Remove</TooltipContent>
                  </Tooltip>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default PlaylistsView;
