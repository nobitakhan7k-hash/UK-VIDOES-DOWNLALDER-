import React from 'react';
import { useAppContext } from '../contexts/AppContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Loader2, ArrowDownToLine, Bell, KeyRound, ListVideo, Globe, Download, Search } from 'lucide-react';

const Header = () => {
  const {
    url, urlInputRef, handleUrlChange, handleFetchDetails, isLoading,
    activeJobs, isDownloading, goBackToHistory,
    openSubscriptions, openPlaylists, openKeyword, openBrowser, activePage, subscriptions, subscriptionUnseen,
    license, openQr, openLicense,
  } = useAppContext();

  // px-[21px] matches the card's inner inset below (20px padding + 1px border),
  // so this row shares a column with Downloads / Settings / Clear.
  return (
    <header className="flex items-center gap-3">
      <div className="relative flex-1">
        <Input
          ref={urlInputRef}
          type="text"
          placeholder="Paste a link or song name"
          value={url}
          onChange={(e) => handleUrlChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") handleFetchDetails();
            // Escape hands focus back to the app so the global shortcuts apply
            // again. The URL stays — losing a pasted link to a stray keypress
            // would be worse than the extra keystroke to clear it.
            else if (e.key === "Escape") e.currentTarget.blur();
          }}
          className="h-10 bg-card border-border/50 text-sm placeholder:text-muted-soft"
        />
      </div>
      <Button
        onClick={() => handleFetchDetails()}
        disabled={!url || isLoading}
        className="h-10 px-5 min-w-32.5 font-semibold"
      >
        {isLoading ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <>
            <Download className="h-4 w-4" />
            DOWNLOAD
          </>
        )}
      </Button>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="relative h-10 w-10 shrink-0 text-muted-foreground hover:text-foreground transition-colors"
            onClick={goBackToHistory}
          >
            <ArrowDownToLine className="h-4 w-4" />
            {activeJobs.length > 0 && (
              <span className="absolute top-1.5 right-1.5 flex h-2 w-2">
                {isDownloading && (
                  <span className="absolute inline-flex h-full w-full rounded-full bg-primary opacity-75 animate-ping" />
                )}
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
              </span>
            )}
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="text-xs">
          {activeJobs.length > 0
            ? `Downloads (${activeJobs.length})`
            : 'Downloads'}
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Browse YouTube"
            className="h-10 w-10 shrink-0 text-muted-foreground hover:text-foreground transition-colors"
            onClick={openBrowser}
          >
            <Globe className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="text-xs">
          Browse
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Playlists"
            className={`relative h-10 w-10 shrink-0 transition-colors ${
              activePage === 'playlists'
                ? 'text-foreground bg-secondary/60'
                : 'text-muted-foreground hover:text-foreground'
            }`}
            onClick={openPlaylists}
          >
            <ListVideo className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="text-xs">
          Playlists
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Search"
            className={`h-10 w-10 shrink-0 text-muted-foreground hover:text-foreground transition-colors ${
              activePage === 'keyword' ? 'text-foreground bg-secondary/60' : ''
            }`}
            onClick={openKeyword}
          >
            <Search className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="text-xs">
          Search
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Subscriptions"
            className={`relative h-10 w-10 shrink-0 transition-colors ${
              activePage === 'subscriptions'
                ? 'text-foreground bg-secondary/60'
                : 'text-muted-foreground hover:text-foreground'
            }`}
            onClick={openSubscriptions}
          >
            <Bell className="h-4 w-4" />
            {subscriptionUnseen > 0 && (
              <span className="absolute -top-0.5 -right-0.5 min-w-4 h-4 px-1 rounded-full bg-primary text-primary-foreground text-[9px] font-bold flex items-center justify-center tabular-nums">
                {subscriptionUnseen > 99 ? '99+' : subscriptionUnseen}
              </span>
            )}
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="text-xs">
          {subscriptions.length > 0
            ? `Subscriptions (${subscriptions.length})`
            : 'Subscriptions'}
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            aria-label={license.isPro ? 'PRO' : 'By Usman'}
            className={`h-10 px-2 shrink-0 transition-colors ${
              license.isPro
                ? 'text-amber-500 hover:text-amber-400 font-bold'
                : 'text-muted-foreground hover:text-foreground'
            }`}
            onClick={() => (license.isPro ? openLicense() : openQr('manual'))}
          >
            <span className="text-[12px] font-semibold tracking-tight whitespace-nowrap">
              {license.isPro ? 'PRO' : 'By Usman'}
            </span>
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="text-xs">
          {license.isPro ? 'PRO' : 'By Usman'}
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Pro key"
            className={`relative h-10 w-10 shrink-0 transition-colors ${
              license.isPro ? 'text-amber-500 hover:text-amber-400' : 'text-muted-foreground hover:text-foreground'
            }`}
            onClick={openLicense}
          >
            <KeyRound className="h-4 w-4" />
            {license.isPro && (
              <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-amber-500" />
            )}
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="text-xs">
          {license.isPro
            ? 'Key'
            : `${license.dailyCount || 0}/${license.dailyLimit || 10}`}
        </TooltipContent>
      </Tooltip>
    </header>
  );
};

export default Header;
