import React, { useCallback, useMemo, useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  ArrowLeft, Search, Loader2, Download, Eye, Calendar, Clock,
  ExternalLink, ListFilter, Music2,
} from 'lucide-react';

const PAGE_CHOICES = [1, 2, 5, 10, 20, 50];
const TIME_CHOICES = [
  { value: 'any', label: 'Any time' },
  { value: 'hour', label: 'Last hour' },
  { value: 'today', label: 'Today' },
  { value: 'week', label: 'This week' },
  { value: 'month', label: 'This month' },
  { value: 'year', label: 'This year' },
];

const clampCount = (raw, total) => {
  const max = Math.max(1, Number(total) || 1);
  const n = Math.floor(Number(raw));
  if (!Number.isFinite(n)) return 1;
  return Math.min(Math.max(1, n), max);
};

const KeywordView = () => {
  const { closeKeyword, showAppNotice } = useAppContext();

  const [query, setQuery] = useState('');
  const [pages, setPages] = useState(1);
  const [timeFilter, setTimeFilter] = useState('any');
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState(null);
  const [topCount, setTopCount] = useState('1');
  const [downloading, setDownloading] = useState(false);

  const selectedCount = useMemo(
    () => clampCount(topCount, result?.items?.length || 1),
    [topCount, result]
  );

  const handleScan = useCallback(async () => {
    const q = String(query || '').trim().replace(/\s+/g, ' ').slice(0, 200);
    if (!q) {
      showAppNotice('error', 'Type a keyword first.');
      return;
    }
    if (/^https?:\/\//i.test(q)) {
      showAppNotice('error', 'Paste links in the top bar.');
      return;
    }
    if (!window.electronAPI?.keywordScan) {
      showAppNotice('error', 'Keyword scan is not available in this build.');
      return;
    }

    setScanning(true);
    setResult(null);
    setTopCount('1');
    try {
      const res = await window.electronAPI.keywordScan({ query: q, pages, timeFilter });
      if (!res?.success) {
        showAppNotice('error', res?.error || 'YouTube scan failed.');
        return;
      }
      setResult(res);
      showAppNotice('success', `${res.kept} videos found.`);
    } catch (err) {
      showAppNotice('error', err?.message || 'YouTube scan failed.');
    } finally {
      setScanning(false);
    }
  }, [query, pages, timeFilter, showAppNotice]);

  const handleDownload = useCallback(async () => {
    if (!result?.items?.length) return;
    const count = clampCount(topCount, result.items.length);
    const chosen = result.items.slice(0, count);
    const api = window.electronAPI;
    if (!api?.queueVideoBatch) {
      showAppNotice('error', 'Download queue is not available.');
      return;
    }

    setDownloading(true);
    try {
      const settings = await api.getVideoSettings().catch(() => ({
        defaultQuality: 'hd720', directSave: true, directSaveDir: '',
      }));
      const targetDir = settings.directSaveDir || await api.getDefaultDownloadDir().catch(() => '');
      if (!targetDir) {
        showAppNotice('error', 'Choose a download folder in Settings → Video.');
        return;
      }

      const preset = settings.defaultQuality || 'hd720';
      const wantsMp3 = preset === 'mp3';
      const quality = (preset === 'ask' || wantsMp3) ? 'hd720' : preset;
      const qualityLabel = wantsMp3
        ? 'MP3'
        : quality === 'hd720' ? '720p HD' : quality === 'hd480' ? '480p HD' : 'Best';
      const defaultType = wantsMp3 ? 'mp3' : 'mp4';

      const items = chosen.map((it) => ({
        videoId: it.id,
        url: it.url,
        title: it.title,
        thumbnailUrl: it.thumbnailUrl || '',
        quality,
        qualityLabel,
        type: defaultType,
        convertToH264: false,
        sizeBytes: 0,
      }));

      const res = await api.queueVideoBatch({ items, targetDir }).catch((err) => ({
        success: false, error: err?.message || 'Could not start downloads.',
      }));
      if (!res?.success) {
        showAppNotice('error', res?.error || 'Could not start downloads.');
        return;
      }
      if (res.partial) {
        showAppNotice('warning', `Daily limit: ${res.queued} queued, ${res.skipped} skipped.`);
      } else {
        showAppNotice('success', `${res.queued || count} downloads started.`);
      }
    } catch (err) {
      showAppNotice('error', err?.message || 'Could not start downloads.');
    } finally {
      setDownloading(false);
    }
  }, [result, topCount, showAppNotice]);

  return (
    <div className="flex flex-col gap-4 p-1">
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          className="h-9 w-9 shrink-0 text-muted-foreground hover:text-foreground"
          onClick={closeKeyword}
          aria-label="Back"
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h2 className="flex items-center gap-2 text-lg font-semibold text-foreground">
          <Search className="h-5 w-5 text-primary" />
          Search
        </h2>
      </div>

      <Card className="border-border/50 bg-card/60">
        <CardContent className="p-4">
          <div className="grid gap-3 md:grid-cols-[minmax(0,1fr)_150px_170px_auto]">
            <div className="min-w-0">
              <label className="mb-1.5 block text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                Keyword
              </label>
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') handleScan(); }}
                className="h-10 bg-background/60 border-border/50 text-sm"
                aria-label="Keyword"
              />
            </div>

            <div>
              <label className="mb-1.5 flex items-center gap-1 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                <ListFilter className="h-3 w-3" /> Pages
              </label>
              <Select value={String(pages)} onValueChange={(v) => setPages(Number(v))}>
                <SelectTrigger className="h-10 bg-background/60 border-border/50 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PAGE_CHOICES.map((n) => (
                    <SelectItem key={n} value={String(n)} className="text-sm">
                      {n} page{n === 1 ? '' : 's'}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="mb-1.5 flex items-center gap-1 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                <Calendar className="h-3 w-3" /> Upload time
              </label>
              <Select value={timeFilter} onValueChange={setTimeFilter}>
                <SelectTrigger className="h-10 bg-background/60 border-border/50 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TIME_CHOICES.map((o) => (
                    <SelectItem key={o.value} value={o.value} className="text-sm">
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button
                onClick={handleScan}
                disabled={scanning || !query.trim()}
                className="h-10 w-full px-5 font-semibold md:w-auto"
              >
                {scanning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                {scanning ? 'Scanning…' : 'SCAN'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {result && (
        <Card className="border-primary/30 bg-primary/[0.035]">
          <CardContent className="p-4">
            <div className="flex flex-wrap items-end gap-3">
              <div className="min-w-0 flex-1">
                <h3 className="text-sm font-semibold text-foreground">
                  Top videos
                </h3>
              </div>
              <div className="w-32 shrink-0">
                <label className="mb-1.5 block text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                  Top count
                </label>
                <Input
                  type="number"
                  min="1"
                  max={Math.max(1, result.items.length)}
                  step="1"
                  inputMode="numeric"
                  value={topCount}
                  onChange={(e) => setTopCount(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') handleDownload(); }}
                  className="h-10 bg-background/70 border-border/50 text-sm tabular-nums"
                  aria-label="Top count"
                />
              </div>
              <Button
                onClick={handleDownload}
                disabled={downloading || !result.items.length || selectedCount < 1}
                className="h-10 px-5 font-semibold"
              >
                {downloading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
                {downloading ? 'Starting…' : `DOWNLOAD TOP ${selectedCount}`}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {result && (
        <Card className="border-border/50 bg-card/50">
          <CardContent className="p-3">
            <div className="mb-2 flex items-center justify-between gap-2 px-1">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-foreground">
                <Music2 className="h-4 w-4 text-primary" />
                Results ({result.items.length})
              </h3>
            </div>

            {!result.items.length ? (
              <div className="rounded-md border border-dashed border-border/50 px-4 py-8 text-center text-sm text-muted-foreground">
                No videos found.
              </div>
            ) : (
              <div className="max-h-[58vh] space-y-2 overflow-y-auto pr-1">
                {result.items.map((item) => {
                  const picked = item.rank <= selectedCount;
                  return (
                    <div
                      key={item.id}
                      className={`rounded-lg border px-3 py-2.5 transition-colors ${
                        picked ? 'border-primary/40 bg-primary/[0.04]' : 'border-border/40 bg-background/30'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <span className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[11px] font-bold tabular-nums ${
                          picked ? 'bg-primary text-primary-foreground' : 'bg-secondary/70 text-muted-foreground'
                        }`}>
                          {item.rank}
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-sm font-medium text-foreground" title={item.title}>
                            {item.title}
                          </div>
                          <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] text-muted-foreground">
                            <span className="inline-flex items-center gap-1 font-medium text-foreground/80">
                              <Eye className="h-3 w-3" /> {item.viewsLabel} views
                            </span>
                            <span className="inline-flex items-center gap-1">
                              <Calendar className="h-3 w-3" /> {item.uploadDate}
                            </span>
                            <span className="inline-flex items-center gap-1">
                              <Clock className="h-3 w-3" /> {item.durationLabel}
                            </span>
                            <span className="truncate">{item.channel}</span>
                          </div>
                          <div className="mt-1 flex items-center gap-1 text-[10px] text-muted-soft">
                            <ExternalLink className="h-3 w-3 shrink-0" />
                            <span className="truncate" title={item.url}>{item.url}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default KeywordView;
