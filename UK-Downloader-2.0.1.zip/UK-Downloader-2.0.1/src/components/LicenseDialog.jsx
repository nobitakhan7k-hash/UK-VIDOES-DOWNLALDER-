import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Logo } from '@/components/ui/logo';
import { KeyRound, CheckCircle2, AlertTriangle, Crown, Loader2 } from 'lucide-react';
import { useAppContext } from '../contexts/AppContext';

const fmt = (iso) => {
  if (!iso) return '';
  try { return new Date(iso).toLocaleString(); } catch { return ''; }
};

/** Separate "Key" window — redeem a Pro key and show the stored license. */
const LicenseDialog = ({ open, onOpenChange }) => {
  const { license, redeemKey, openQr, closeLicense } = useAppContext();
  const [keyInput, setKeyInput] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e?.preventDefault();
    if (!keyInput.trim() || busy) return;
    setBusy(true);
    setError('');
    const res = await redeemKey(keyInput.trim());
    setBusy(false);
    if (res?.success) {
      setKeyInput('');
    } else {
      setError(res?.error || 'This key could not be activated.');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[440px] p-0 overflow-hidden gap-0">
        <DialogHeader className="px-5 pt-5 pb-3 text-left">
          <DialogTitle className="text-base flex items-center gap-2">
            <KeyRound className="h-4 w-4" />
            Pro key
            <Logo className="h-6 w-6 ml-auto rounded-full" />
          </DialogTitle>
        </DialogHeader>

        <div className="px-5 pb-5 space-y-4">
          {license.isPro ? (
            <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-3.5 space-y-2.5">
              <div className="flex items-center gap-2">
                <Crown className="h-4 w-4 text-amber-500" />
                <span className="text-sm font-bold text-amber-600 dark:text-amber-400">PRO ACTIVE</span>
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 ml-auto" />
              </div>
              <p className="text-xs text-foreground">
                {license.type === 'LIFE' ? 'Lifetime Pro' : '6-month Pro'}
              </p>
              <div className="rounded-lg bg-background/60 border border-border/40 px-3 py-2">
                <p className="text-[10px] uppercase tracking-wider text-muted-soft">Stored key</p>
                <p className="text-xs font-mono break-all text-foreground mt-0.5">{license.key || '—'}</p>
              </div>
              <p className="text-[11px] text-muted-foreground">
                Activated {fmt(license.activatedAt)}
                {license.expiresAt ? ` · expires ${fmt(license.expiresAt)}` : ' · never expires'}
              </p>
            </div>
          ) : (
            <>
              <div className="rounded-xl border border-border/40 bg-secondary/25 px-4 py-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-medium text-foreground">Today&apos;s free downloads</span>
                  <span className="text-xs font-semibold tabular-nums">
                    {license.dailyCount || 0} / {license.dailyLimit || 10}
                  </span>
                </div>
                <div className="mt-2 h-1.5 rounded-full bg-background/70 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${license.limitReached ? 'bg-amber-500' : 'bg-primary'}`}
                    style={{ width: `${Math.min(100, ((license.dailyCount || 0) / (license.dailyLimit || 10)) * 100)}%` }}
                  />
                </div>
                <p className="text-[11px] text-muted-foreground mt-2">
                  {license.limitReached
                    ? 'Limit reached.'
                    : `${license.remaining ?? 10} left today`}
                </p>
              </div>

              <form onSubmit={submit} className="space-y-2">
                <label htmlFor="pro-key-input" className="text-xs font-medium text-foreground">
                  Enter Pro key
                </label>
                <Input
                  id="pro-key-input"
                  value={keyInput}
                  onChange={(e) => { setKeyInput(e.target.value); setError(''); }}
                  placeholder="Enter key"
                  autoComplete="off"
                  spellCheck={false}
                  className="h-9 font-mono text-xs"
                />
                {error && (
                  <p className="flex items-start gap-1.5 text-[11px] text-destructive">
                    <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                    {error}
                  </p>
                )}
                <Button type="submit" size="sm" className="w-full h-9 text-xs gap-1.5" disabled={busy || !keyInput.trim()}>
                  {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <KeyRound className="h-3.5 w-3.5" />}
                  Activate Pro
                </Button>
              </form>

              <Button
                variant="ghost"
                size="sm"
                className="w-full h-8 text-[11px] text-muted-foreground hover:text-foreground"
                onClick={() => { closeLicense(); openQr('manual'); }}
              >
                Get a key
              </Button>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default LicenseDialog;
