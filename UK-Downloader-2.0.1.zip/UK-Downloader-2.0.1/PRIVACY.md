# Privacy

*Last updated: 7 November 2026*

**UK Downloader has no telemetry, no analytics, and no accounts.** It does not
report usage, does not count launches, does not send crash reports, and does
not contain any third-party analytics service, SDK, ad network, or tracking
pixel. There is no server operated by this project, so there is nowhere for
your data to go.

Nothing about you or your downloads is ever sent anywhere.

The app does make network requests, because a video downloader has to. All of
them are listed below — the yt-dlp update check at startup, the optional
YouTube sign-in, the Google attestation some YouTube videos require, and
thumbnails — and all of them can be verified by reading the source.

## Requests UK Downloader makes at startup

One: the yt-dlp engine check, to GitHub, not to us.

**1. yt-dlp update check.** UK Downloader runs `yt-dlp -U`, which asks GitHub
whether a newer yt-dlp release exists and updates the bundled binary if so.
YouTube changes constantly and an out-of-date yt-dlp stops working, so this is
what keeps downloads functioning. The check runs on launch, again every six
hours while the app is open, and when you press **Check for updates** in
Settings → yt-dlp engine. If the binary is missing (or you press
**Re-download engine**), the app downloads the standalone build from the public
yt-dlp release page into its own writable `bin` folder. The version, phase and
timestamps are shown in Settings and in a short on-screen toast; nothing about
you is sent.

There is no release/version check against any website, no project-website link
and no GitHub link inside the app. Those promo/support links were removed.

It is subject to
[GitHub's privacy statement](https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement).
Like any HTTP request it reveals your IP address to GitHub, which no app can
avoid. It carries nothing about you and does not reach this project.

## Signing in to YouTube (optional)

UK Downloader can sign in to YouTube, which is needed for age-restricted videos,
private playlists, and content only your account can see. This is entirely
optional and off until you use it. No UK Downloader server is involved at any point —
it is between your computer and Google.

If you do sign in, you should know how it works:

- Sign-in happens in a real Google sign-in window
  ([`src/main.js`](src/main.js)). UK Downloader never sees or stores your password.
- UK Downloader then copies your YouTube session cookies out of that window into a
  plain text file, `youtube_cookies.txt`, in the same folder as your settings,
  and passes it to yt-dlp with `--cookies` so downloads can use your session.
  **That file is not encrypted**, and like any file in your user folder it is
  readable by other software running as you. It never leaves your machine.
- While you are signed in, your downloads are authenticated as your Google
  account, which means YouTube can associate them with you. That is inherent to
  signing in anywhere, not something UK Downloader adds — but it is the practical
  consequence, so it is worth stating plainly.
- **Signing out deletes it.** UK Downloader clears your `youtube.com` and
  `google.com` cookies and deletes `youtube_cookies.txt` from disk.

## YouTube "Proof of Origin" tokens (when a video needs one)

YouTube refuses to serve some videos' streams unless the request carries a
*Proof of Origin* token — most notably age-restricted videos when you are
signed in. A token can only be produced by running Google's **BotGuard**
attestation script, which is what youtube.com does in your browser on every
visit.

UK Downloader does the same thing, only when a video actually needs it: it runs
BotGuard in an invisible window inside the app
([`src/potoken/`](src/potoken/)) and hands the resulting token to yt-dlp.
Videos that don't need one — the large majority — never trigger this.

What that involves, concretely:

- **Two requests to Google**, both to `jnn-pa.googleapis.com` (Google's
  anti-abuse API), made from the app itself, not from a page you can see.
  BotGuard is an obfuscated script that inspects the environment it runs in
  (browser and runtime characteristics) to decide it is not a bot, and sends
  Google an attestation of that. This is the *same* check every YouTube visitor
  passes in a normal browser; UK Downloader adds nothing to it and cannot see what
  the script reports, because the script is Google's and is opaque by design.
- The invisible window is locked down: it can load only UK Downloader's own
  bundled script, has no access to the network on its own (its requests are
  routed through the app and restricted to Google's domains), and is destroyed
  a few minutes after it is last used.
- Your YouTube cookies are **not** sent to `jnn-pa.googleapis.com`; the token
  is tied to the video's ID, not to your account.
- No UK Downloader server is involved, and nothing is stored beyond the token
  itself, which is kept in memory for at most an hour.

Like any request it reveals your IP address to Google, and it is subject to
[Google's privacy policy](https://policies.google.com/privacy).

## Video thumbnails

Thumbnails shown in the app — in search results, playlists and the active
download list — are loaded directly from the video site's own image servers
(for YouTube that is `i.ytimg.com`; other sites use their own CDNs) as normal
images, because UK Downloader stores the thumbnail URL rather than a copy of the
picture.

This means that opening the active downloads list requests those images from
the sites you are downloading from, which reveals your IP address to them and,
through the URLs, which videos are currently in the list. Nothing is uploaded
and nothing reaches this project — but "your list stays on your computer" would
be misleading without this note, so here it is.

## Keyword / song search (v10)

If you type a plain song name or keyword in the top bar instead of a link, UK
Downloader asks YouTube for search results using yt-dlp's `ytsearchN:<query>`.
The words you typed are sent to YouTube, like any normal YouTube search, and
the resulting video URLs/thumbnails come back from YouTube. No UK Downloader
server is involved and the app keeps **no search history**. This only happens
when you actually use keyword search; pasting a normal link uses the existing
URL flow. The number of results (1–50, default 1) is a local setting.

---

## No download history

This build keeps **no download history**. Any `downloadHistory` entries copied
from an older YT-Forge / UK Downloader install are cleared at startup; finished
jobs are removed from the active list automatically and no new history entry is
written. The finished files themselves remain on your disk — the app simply
does not keep a second, persistent list of them.

The instant "preparing" row shown while a dropped link is being read is purely
renderer UI state. It is never written to `electron-store`, never becomes a
download-history entry and vanishes when the real queue appears. Cleaning a
song link (`&list=RD…`, `&start_radio=1`) only removes playlist parameters
locally before yt-dlp is asked for that one video; no extra request, upload,
search history or telemetry is involved.

The crash-safe resume queue stores only local job metadata (URL, title, output
path, hidden scratch-folder path) in `electron-store` so an interrupted download
can continue after relaunch. It is not download history: finished jobs are still
removed from the list and no history entry is written. The hidden scratch folder
is local to the chosen download folder and is deleted on completion or Cancel
All; on quit it is deliberately kept only so `--continue` can reuse its `.part`
files. Auto-subscribe stores the playlist's full video-ID baseline locally (v9
behaviour), never on a server.

The dedicated Playlists page keeps only a small recent list (URL, title,
uploader, video count, thumbnail) in `electron-store` on this machine. It is
not upload history, is never sent anywhere, and is capped at 12 entries. Playlist
file numbering reads yt-dlp's `playlist_index` locally and only changes the
output filename; no extra network request is made.

The separate Browse YouTube window loads youtube.com itself (like any browser)
and has its own minimal, sandboxed preload: it only focuses the search box and
reports the link under a right-click. It does NOT expose app internals,
file-system access, download history, license keys or settings to the remote
page. Non-YouTube navigation is handed to the system browser. The floating
navigation toolbar only calls local Electron navigation-history APIs
(back / forward / home / reload) on that same window (with a local
`history.back()` fallback); it sends nothing off the machine. The right-click
"Download this video" action sends only the cleaned
YouTube URL back to the local app; no telemetry or third-party server is involved.

The optional Chrome/Edge Link Catcher extension stores detected links only in
`chrome.storage.local` on this machine. Its "UK Downloader" mode opens a
`ukdownloader://` custom-protocol URL; there is NO localhost HTTP listener and
NO remote server. The app then fetches the file itself over http(s) and writes
it into the chosen download folder. Browser mode uses Chrome's own download
manager. No analytics, telemetry or third-party service is contacted.

Subscriptions are different: they store the video IDs of a followed playlist
locally so the app can tell which uploads are new. That is subscription state,
not a download history, and it never leaves your machine. v9 stores the full
playlist ID list rather than a truncated slice.

## Everything else stays on your computer

Settings, theme, subscriptions, Pro keys, the daily counter and downloaded
files are stored locally and never leave your machine. UK Downloader has no
account system, no login, and no server-side storage of anything you do in the
app.

**Pro keys and the daily limit are entirely local too.** The 10-videos-per-day
counter, the activated key, its type and its expiry are kept in the same local
`config.json`. Keys are validated offline with an HMAC — no licence server, no
network request and no telemetry when a key is entered. The key itself is shown
in the app's Pro window after activation.

**Subscription export/import is local too.** Export writes a `.json` / `.jsn`
file to a folder you choose; import only reads a file you select. Both use the
normal OS file dialog and neither makes a network request.

Those settings live in a single file, if you ever want to inspect or delete it:

- **macOS** `~/Library/Application Support/UK Downloader/config.json`
- **Windows** `%APPDATA%\UK Downloader\config.json`
- **Linux** `~/.config/UK Downloader/config.json`

(Some **development** builds — never a released version — stored this file in an
`electron-store-nodejs` folder instead, because of a bug in how the upstream build loaded
its settings library. If you ever ran one, the app merges that file back into
the correct location on launch and renames the old one to
`config.json.migrated`, leaving its contents intact. Nothing is deleted.)

If you used the original YT-Forge build before this rename, its `config.json`,
cookies and bundled yt-dlp binary are copied once into the new UK Downloader
folder on first launch. The old folder is left in place as a backup — nothing is
deleted and nothing is uploaded during the migration.

## Questions

Changes to this document are visible in its
[file history](https://github.com/YT-Forge-Official/YT-Forge/commits/main/PRIVACY.md).
For anything else, open a discussion at
<https://github.com/YT-Forge-Official/YT-Forge/discussions>.
