@echo off
rem ===========================================================================
rem  UK Downloader - Windows EXE builder  (v2.0.1 + drag fix + bundled yt-dlp.exe)
rem
rem  Double-click this file, or run it from cmd:
rem
rem      builder.bat                 build the 64-bit Windows installer (.exe)
rem      builder.bat arm64           build the Windows ARM64 installer
rem      builder.bat clean           delete dist/ release/ first, then build
rem      builder.bat --no-install    skip "npm ci" (dependencies already there)
rem      builder.bat --no-open       do not open the release folder at the end
rem      builder.bat --no-pause      do not wait for a key (for CI / scripting)
rem      builder.bat --no-download   never auto-download yt-dlp.exe
rem
rem  Put this file in the UK Downloader project root, next to package.json.
rem  Output: release\UK Downloader Setup <version>.exe
rem ===========================================================================

setlocal EnableExtensions EnableDelayedExpansion
title UK Downloader - EXE builder
cd /d "%~dp0"

set "ROOT=%CD%"
set "ARCH=x64"
set "DO_CLEAN="
set "SKIP_INSTALL="
set "OPEN_AFTER=1"
set "DO_PAUSE=1"
set "ALLOW_DOWNLOAD=1"
rem SHA256 of the bundled official yt-dlp.exe 2026.10.26 (x64).
set "YTDLP_SHA256=f5389d3698ecde4ef06f4e6b1ce0294fe9ac1396228c8990b8d3416d6d177a7d"
set "STEP=banner"

rem ---------------------------- arguments ------------------------------------
:parse
if "%~1"=="" goto parsed
if /i "%~1"=="x64"           ( set "ARCH=x64"   & shift & goto parse )
if /i "%~1"=="arm64"         ( set "ARCH=arm64" & shift & goto parse )
if /i "%~1"=="clean"         ( set "DO_CLEAN=1" & shift & goto parse )
if /i "%~1"=="--no-install"  ( set "SKIP_INSTALL=1" & shift & goto parse )
if /i "%~1"=="--no-open"     ( set "OPEN_AFTER="   & shift & goto parse )
if /i "%~1"=="--no-pause"    ( set "DO_PAUSE="     & shift & goto parse )
if /i "%~1"=="--no-download" ( set "ALLOW_DOWNLOAD=" & shift & goto parse )
if /i "%~1"=="--help"        goto usage
if /i "%~1"=="-h"            goto usage
if /i "%~1"=="/?"            goto usage
echo [ERROR] Unknown option: %~1
echo.
goto usage

:parsed

rem --------------------------- what folder is this? ---------------------------
rem Three things this script refuses to guess about: whether it is in the real
rem project, whether the Subscriptions patch is applied, and whether yt-dlp.exe
rem is there. Each gets its own message instead of a cryptic failure later.
set "STEP=project check"
if not exist "package.json" goto err_no_project
if not exist "src\main.js" goto err_no_project

rem ---------------------------- toolchain ------------------------------------
set "STEP=node check"
where node >nul 2>nul
if errorlevel 1 goto err_no_node
where npm  >nul 2>nul
if errorlevel 1 goto err_no_node

set "APPVER=unknown"
rem 2^>nul keeps Node's error box out of the console if anything goes wrong here;
rem the "unknown" fallback below covers it.
for /f "delims=" %%v in ('node -p "require('./package.json').version" 2^>nul') do set "APPVER=%%v"
rem keep only the first token, so a stray space or warning cannot leak in
for /f "tokens=1" %%v in ("%APPVER%") do set "APPVER=%%v"

echo.
echo  ===============================================================
echo    UK Downloader  -  Windows EXE builder
echo    project : %ROOT%
echo    version : %APPVER%
echo    target  : win-%ARCH%  (NSIS installer)
echo  ===============================================================
echo.

if not exist "electron-builder.yml" goto err_no_config
if not exist "src\components\SubscriptionsView.jsx" goto err_no_patch
if not exist "build\icon.png" (
  echo [WARN] build\icon.png is missing - the installer will use the default icon.
)

echo [1/5] Node.js found.
for /f "delims=" %%v in ('node -v') do echo       node %%v
for /f "delims=" %%v in ('npm -v')  do echo       npm  %%v
echo.

rem ---------------------------- yt-dlp.exe -----------------------------------
set "STEP=yt-dlp.exe"
if exist "bin\yt-dlp.exe" goto ytdlp_ready
rem The user may have downloaded yt-dlp.exe manually next to builder.bat.
if exist "yt-dlp.exe" (
  echo [..] Found yt-dlp.exe in the project root - copying to bin\...
  if not exist "bin" mkdir "bin"
  copy /y "yt-dlp.exe" "bin\yt-dlp.exe" >nul
  goto ytdlp_ready
)
if not defined ALLOW_DOWNLOAD goto err_no_ytdlp

echo [..] bin\yt-dlp.exe is missing - trying official + mirror URLs ^(about 23 MB^)...
call :download_ytdlp
if errorlevel 1 goto err_no_ytdlp
:ytdlp_ready
rem The Full zip ships a verified binary. If it was edited/corrupted, re-fetch.
certutil -hashfile "bin\yt-dlp.exe" SHA256 | findstr /i /c:"%YTDLP_SHA256%" >nul
if errorlevel 1 (
  echo [WARN] bin\yt-dlp.exe failed its SHA256 check - fetching a fresh copy...
  del /q "bin\yt-dlp.exe" >nul 2>nul
  if not defined ALLOW_DOWNLOAD goto err_no_ytdlp
  call :download_ytdlp
  if errorlevel 1 goto err_no_ytdlp
)
echo.

rem ---------------------------- clean ----------------------------------------
if defined DO_CLEAN (
  echo [clean] Removing dist, dist-electron and release...
  if exist "dist"           rmdir /s /q "dist"
  if exist "dist-electron" rmdir /s /q "dist-electron"
  if exist "release"        rmdir /s /q "release"
  echo.
)

rem ---------------------------- dependencies ---------------------------------
set "STEP=npm ci"
if defined SKIP_INSTALL goto skip_deps
if not exist "node_modules\electron\package.json" goto install_deps
if not exist "node_modules\electron-builder\package.json" goto install_deps
echo [2/5] Dependencies already installed - skipping npm ci.
echo       Run "builder.bat clean" if the build misbehaves.
echo.
goto after_install

:skip_deps
echo [2/5] Skipping dependency install (--no-install).
echo.
goto after_install

:install_deps
echo [2/5] Installing dependencies - first run can take a few minutes...
if exist "package-lock.json" (
  call npm ci
) else (
  call npm install
)
if errorlevel 1 goto err_install
echo.

:after_install

rem ---------------------------- compile --------------------------------------
set "STEP=npm run build"
echo [3/5] Compiling renderer + main + preload + potoken...
call npm run build
if errorlevel 1 goto err_build
echo.

rem ---------------------------- package --------------------------------------
set "STEP=electron-builder"
echo [4/5] Packaging the Windows installer (win-%ARCH%)...
rem No code-signing certificate in this project - skipping the lookup avoids a
rem slow "signtool not found" pass and keeps the build offline-friendly.
set "CSC_IDENTITY_AUTO_DISCOVERY=false"
if exist "node_modules\.bin\electron-builder.cmd" (
  call "node_modules\.bin\electron-builder.cmd" --win --%ARCH% --publish never
) else (
  call npx --yes electron-builder --win --%ARCH% --publish never
)
if errorlevel 1 goto err_package
echo.

rem ---------------------------- verify ---------------------------------------
set "STEP=verify output"
echo [5/5] Checking the output...
if not exist "release" goto err_no_output
dir /b "release\*.exe" >nul 2>nul
if errorlevel 1 goto err_no_output

echo.
echo  ===============================================================
echo    BUILD OK  -  UK Downloader %APPVER%  (win-%ARCH%)
echo  ===============================================================
echo.
for /f "delims=" %%f in ('dir /b "release\*.exe"') do echo    %%f
echo.
echo    Folder: %ROOT%\release
echo.
echo    Note: the installer is not code-signed, so Windows SmartScreen may
echo          warn on first run - click "More info", then "Run anyway".
echo    Pro keys: PRO-KEYS.txt  ^(project root + resources\PRO-KEYS.txt^)
echo.
if defined OPEN_AFTER start "" explorer "%ROOT%\release"
goto done

rem ===========================================================================
rem  :download_ytdlp - grab the official yt-dlp.exe without user involvement.
rem  curl.exe ships with Windows 10 1803+; PowerShell is the fallback. Four
rem  official/mirror URLs are tried. Each result is written to a .part file,
rem  then checked for size AND the pinned official SHA256 so a 504 HTML page or
rem  a bad mirror can never be passed off as the binary. Returns 1 on failure.
rem ===========================================================================
:download_ytdlp
if not exist "bin" mkdir "bin"
set "YTDLP_PART=bin\yt-dlp.exe.part"
if exist "%YTDLP_PART%" del /q "%YTDLP_PART%" >nul 2>nul

rem GitHub's release CDN sometimes answers 504 from Pakistan / some ISPs.
rem Try the official "latest" URL, a pinned release, then two GitHub mirrors.
rem Every URL gets curl.exe AND a PowerShell fallback; each result is checked
rem for size and the official SHA256 before it is accepted.
call :try_ytdlp_url "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe"
if not errorlevel 1 exit /b 0
call :try_ytdlp_url "https://github.com/yt-dlp/yt-dlp/releases/download/2026.10.26/yt-dlp.exe"
if not errorlevel 1 exit /b 0
call :try_ytdlp_url "https://gh-proxy.com/https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe"
if not errorlevel 1 exit /b 0
call :try_ytdlp_url "https://gh-proxy.com/https://github.com/yt-dlp/yt-dlp/releases/download/2026.10.26/yt-dlp.exe"
if not errorlevel 1 exit /b 0
exit /b 1

:try_ytdlp_url
set "YTDLP_URL=%~1"
echo      trying %YTDLP_URL%
if exist "%YTDLP_PART%" del /q "%YTDLP_PART%" >nul 2>nul
set "YTDLP_SIZE="
where curl.exe >nul 2>nul
if errorlevel 1 goto ytdlp_ps_try
call curl.exe -L --fail --retry 5 --retry-all-errors --retry-delay 2 --connect-timeout 30 --max-time 300 --ssl-no-revoke -o "%YTDLP_PART%" "%YTDLP_URL%"
if not errorlevel 1 goto ytdlp_check_part

:ytdlp_ps_try
where powershell.exe >nul 2>nul
if errorlevel 1 exit /b 1
call powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri '%YTDLP_URL%' -OutFile '%YTDLP_PART%' -TimeoutSec 300 } catch { exit 1 }"
if errorlevel 1 exit /b 1

:ytdlp_check_part
if not exist "%YTDLP_PART%" exit /b 1
for %%f in ("%YTDLP_PART%") do set "YTDLP_SIZE=%%~zf"
if not defined YTDLP_SIZE exit /b 1
if %YTDLP_SIZE% LSS 1000000 (
  del /q "%YTDLP_PART%" >nul 2>nul
  exit /b 1
)
certutil -hashfile "%YTDLP_PART%" SHA256 | findstr /i /c:"%YTDLP_SHA256%" >nul
if errorlevel 1 (
  echo      checksum mismatch - rejecting this download
  del /q "%YTDLP_PART%" >nul 2>nul
  exit /b 1
)
move /y "%YTDLP_PART%" "bin\yt-dlp.exe" >nul
echo      saved bin\yt-dlp.exe ^(%YTDLP_SIZE% bytes^), SHA256 verified
exit /b 0

rem ---------------------------- errors ---------------------------------------
:err_no_project
echo.
echo  ---------------------------------------------------------------
echo   This is not the UK Downloader project folder.
echo  ---------------------------------------------------------------
echo.
echo   builder.bat is running in:
echo     %ROOT%
echo.
echo   That folder has no package.json / src\main.js, so there is
echo   nothing to compile.
if exist "CHANGES.diff" (
  echo   It looks like a PATCH PACKAGE ^(it has CHANGES.diff^), not the app.
) else (
  if exist "src\components\SubscriptionsView.jsx" (
    echo   It looks like a source-only patch folder, not the app.
  )
)
echo.
echo   FIX - use the complete project instead:
echo     1. Extract "UK-Downloader-2.0.1-Full.zip" to a normal
echo        folder such as  C:\UK-Downloader   ^(not inside Downloads\Compressed^)
echo     2. Open that folder - it contains package.json, src, bin, build
echo     3. Double-click builder.bat there
echo.
echo   Already have an upstream YT-Forge v2.0.1 checkout? Copy the patched src\
echo   folder over it, put builder.bat next to package.json, run it there.
goto fail

:err_no_patch
echo [ERROR] This project does not contain the Subscriptions patch.
echo         Expected file: src\components\SubscriptionsView.jsx
echo.
echo         Use the complete "UK-Downloader-2.0.1-Full.zip" project,
echo         or copy the patched src\ folder from "uk-downloader-src"
echo         over this project's src\ folder first.
goto fail

:err_no_config
echo [ERROR] electron-builder.yml is missing - it defines the NSIS target and
echo         the yt-dlp.exe extra resource, so packaging cannot run without it.
goto fail

:err_no_ytdlp
echo.
echo [ERROR] bin\yt-dlp.exe is missing and all download URLs failed.
echo         The Full zip already contains bin\yt-dlp.exe - re-extract it,
echo         or copy a manually downloaded yt-dlp.exe into this folder and
echo         run builder.bat again (it will be copied to bin\ automatically).
echo.
echo         Official binary (or use a GitHub mirror such as gh-proxy.com):
echo           https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe
echo         Expected SHA256: %YTDLP_SHA256%
echo.
echo         Once installed, UK Downloader can also repair a missing yt-dlp
echo         from Settings -> yt-dlp engine.
goto fail

:err_no_node
echo [ERROR] Node.js / npm was not found on PATH.
echo         Install the LTS build from https://nodejs.org, then close this
echo         window and double-click builder.bat again.
goto fail

:err_install
echo.
echo [ERROR] "npm ci" / "npm install" failed.
echo         Common fixes:
echo           - check the internet connection (it downloads Electron + ffmpeg)
echo           - delete node_modules and run builder.bat again
echo           - behind a proxy, set HTTP_PROXY / HTTPS_PROXY first
echo           - building inside Downloads\Compressed or OneDrive can block
echo             writes - copy the project to C:\UK-Downloader and retry
goto fail

:err_build
echo.
echo [ERROR] "npm run build" failed (the vite compile step).
echo         The first error above is the real one - usually a missing file or
echo         a syntax error from a manual edit.
goto fail

:err_package
echo.
echo [ERROR] electron-builder failed.
echo         Common fixes:
echo           - close any running UK Downloader window (it can lock files in release)
echo           - delete the release folder and run builder.bat again
echo           - antivirus / OneDrive sync can block writes in the project folder
goto fail

:err_no_output
echo.
echo [ERROR] electron-builder finished but no .exe appeared in release.
echo         Look above for a skipped target or a "cannot create" line.
goto fail

rem ---------------------------- helpers --------------------------------------
:usage
echo.
echo  UK Downloader Windows builder
echo.
echo    builder.bat                 build win-x64 installer (default)
echo    builder.bat arm64           build win-arm64 installer
echo    builder.bat clean           remove dist/ dist-electron/ release/ first
echo    builder.bat --no-install    do not run npm ci
echo    builder.bat --no-open       keep the release folder closed
echo    builder.bat --no-pause      exit without waiting for a key
echo    builder.bat --no-download   never auto-download yt-dlp.exe
echo.
echo    bin\yt-dlp.exe is bundled in the Full zip (official 2026.10.26 x64,
echo    SHA256-verified). If missing, 4 official/mirror URLs are tried, and a
echo    yt-dlp.exe placed in the project root is copied into bin\ automatically.
echo.
if defined DO_PAUSE pause
endlocal
exit /b 1

:done
echo    Done. You can close this window.
if defined DO_PAUSE pause
endlocal
exit /b 0

:fail
echo.
echo  ---------------------------------------------------------------
echo   BUILD FAILED at step: %STEP%
echo  ---------------------------------------------------------------
if defined DO_PAUSE pause
endlocal
exit /b 1
