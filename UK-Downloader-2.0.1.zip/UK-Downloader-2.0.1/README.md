<div align="center">
  <img src="assets/icon.png" alt="UK Downloader icon" width="120" />

  <h1>UK Downloader</h1>

  <p>A fast, modern desktop universal video downloader powered by yt-dlp.</p>

  <p>Windows • macOS • Linux</p>
</div>

---

## Overview

**UK Downloader** is a renamed, non-commercial build of the upstream
[YT-Forge v2.0.1](https://github.com/YT-Forge-Official/YT-Forge) source. It is
a lightweight desktop **yt-dlp GUI** with editor-friendly H.264 + AAC (MP4)
output, plus the additions in this build: playlist/channel **Subscriptions**,
**720 HD / 480 HD / MP3** presets, **2 / 4 / 8 / 16 / 32 (custom 1–64) parallel downloads**, direct
drag-and-drop downloads, per-playlist folders and **no download history**.

The upstream project's licence, copyright and third-party notices are retained
in `LICENSE` and `NOTICE.md`. "YT-Forge" and its original logo are trademarks
of the original author; this build uses a different name and a new icon, as a
permitted fork must.

---

## Build the Windows installer

1. Extract **`UK-Downloader-2.0.1-Full.zip`** to a normal folder, e.g. `C:\UK-Downloader`.
2. Double-click **`builder.bat`**. It checks Node.js, installs dependencies,
   runs `npm run build` and packages with electron-builder. The official
   `bin\yt-dlp.exe` (**2026.10.26 x64, SHA256-verified**) is already bundled,
   so no download is needed. If it is missing, the builder tries 4 official /
   mirror URLs and also accepts an `yt-dlp.exe` placed in the project root.
3. Install from **`release\UK Downloader Setup 2.0.1.exe`**.

`builder.bat clean`, `builder.bat arm64`, `--no-install`, `--no-open`,
`--no-pause` and `--no-download` are supported. See `START-HERE.txt` for the
full guide and troubleshooting.

If you previously had YT-Forge installed, its settings, subscriptions and
cookies are copied once into the new UK Downloader data folder on first launch;
the old folder is left untouched as a backup. Any old download history is
cleared on launch — this build keeps no history.

---

## What's in this build

- **Subscriptions** — follow a YouTube playlist or channel; new videos are
  detected and auto-downloaded into the folder and quality you chose. Every
  playlist video ID is stored locally (no 15/18/25-entry cap), so old videos
  are never mistaken for new uploads and downloaded again. Finished videos
  leave the "detected videos" list, with an "N downloaded" counter.
- **720 HD / 480 HD presets** — H.264/AVC1 only, max 1280px / 854px, MP4,
  video stream-copy. First audio track only: AAC-LC stereo copied, otherwise
  AAC-LC 128 kbps / 44.1 kHz / 2 ch. Track named `English`, language `eng`.
- **Video tab in Settings** — 720p HD / 480p HD / **MP3 audio** default,
  **2 / 4 / 8 / 16 / 32 connections (custom 1–64, default 8)**, **keyword result
  limit 1–50**, one-click direct save and folder. The same number controls BOTH
  simultaneous video jobs and per-video DASH/HLS fragment connections.
- **Keyword / song search** — type a song name in the top bar instead of a
  link and press Enter; the first YouTube result downloads directly. Default
  1 result; set 1–50 in Settings (e.g. 20). YouTube only, and it uses the
  selected global format / parallel queue / 10-day free limit rules.
  Top-bar input is string-only now: a button/Enter event object can no longer
  become the fake `[object Object]` keyword after a second search.
- **Dedicated Keyword Search page** — scan 1 / 2 / 5 / 10 / 20 / 50 YouTube
  result pages (20 results per page), filter by upload time (Any / Last hour /
  Today / Week / Month / Year), grab the video links, skip `/shorts/` links and
  show them sorted by MOST VIEWS FIRST. AFTER the scan, enter "top how many to
  download?" and the first N go through the usual global format, 2 / 4 / 8 / 16 / 32 (custom 1–64) queue
  and free 10/day + Pro rules. No search history and no telemetry.
- **Per-playlist location** — each playlist remembers its own folder.
- **Per-subscription folder + FOLDER.JPG** — following a playlist/channel
  immediately creates a Windows-safe subfolder named after it inside the chosen
  location. New videos download there, and the NEWEST new video's thumbnail
  replaces one exact `FOLDER.JPG` file (the old picture is deleted). Multiple
  new uploads still produce only one folder picture. Playlists-hub manual
  downloads are unchanged.
- **Direct drag & drop** — drop one or more links anywhere in the window and
  downloading starts immediately. No details page, no Save dialog. Playlists
  are expanded into separate jobs so the parallel limit applies.
- **Song links are never mistaken for playlists** — a dropped YouTube watch
  link carrying `&list=RD…`, `&start_radio=1`, `&index=…` or `&pp=…` (a radio /
  mix copy of one song) is cleaned to a bare `watch?v=…` URL and downloaded as
  ONE video. Real `/playlist?list=…` links still expand into separate jobs.
- **Instant preparing row** — the moment a link is dropped, Downloads shows an
  animated "Getting your song ready…" row with spinner + easing fake progress
  while yt-dlp reads metadata (~5 s). It is a local UI placeholder only: not a
  job, not persisted, and it disappears as soon as the real queue rows arrive.
- **Auto-subscribe dropped playlists** — a switch on the Playlist page (default
  ON). While that page is open, dragging a playlist link also follows it. Only
  FUTURE videos auto-download; the full ID baseline is stored so old videos are
  never queued again. Song links with `&list=RD…` stay single videos.
- **Crash-safe resume** — close / quit the app mid-download and reopen: the
  queue is restored and yt-dlp `--continue` resumes each file from the same
  byte using the preserved hidden `.part` folder.
- **Hidden temp folder** — intermediates stay in a dot-prefixed folder with the
  Windows Hidden attribute next to the destination. Only the finished file
  appears in the download folder.
- **Cancel All** — one button stops every queued / running download at once;
  partial files are removed, already-finished files are kept.
- **Direct unsubscribe** — the trash button removes a subscription immediately,
  with no confirmation dialog. Downloaded files stay on disk.
- **Sequential "Check all"** — clicking Check all checks playlists ONE BY ONE,
  not all at once. A progress banner shows `Checking 2 of 5: <playlist>…` and
  only the current card spins. The background scheduler stays silent.
- **Browse YouTube (second GUI)** — header `Browse` button opens YouTube in a
  separate Electron window with a Chrome user agent and the search box focused.
  A floating **Back / Forward / Home / Reload** toolbar sits in the window
  (Back is the prominent button); state updates on every navigation, with a
  `history.back()` fallback for in-page SPA moves and Alt+Left / Alt+Right
  shortcuts. Right-click
  a YouTube video / thumbnail / playlist link → native menu item
  **"Download this video"**; it flows straight into the same direct-download
  queue (720/480/MP3, 10/day + Pro). Only YouTube links are offered.
- **"DOWNLOAD" button** — the old `Get / Search` button is renamed exactly to
  `DOWNLOAD`. Typing a song name still runs keyword search; pasting a link still
  opens its details/playlist view.
- **Cleaner header** — the `/` shortcut badge inside the paste-link field is
  gone. The Downloads list no longer shows an "In Progress" heading; active /
  preparing cards simply appear at the top (the "History" divider stays).
- **Browser extension (Link Catcher)** — Chrome/Edge Manifest V3 extension in
  `uk-downloader-extension.zip`. Detects ANY direct file link (`.zip`, `.pdf`,
  `.exe`, media, docs, `download` attributes, `Content-Disposition`) and either
  downloads it in the browser or sends it to the app via the
  `ukdownloader://download?u=…` custom protocol. No local HTTP server is used.
  Generic files enter the same 2 / 4 / 8 / 16 / 32 (custom 1–64) queue with hidden temp, resume, Cancel All,
  10/day + Pro and no-history rules.
- **Dedicated Playlists page** — a header `Playlists` button opens a separate
  hub. Paste a playlist link, keep a small local recent list, open the existing
  selection view, or click **Download whole playlist** to queue every video in
  one go. It reuses global 720/480/MP3, 2 / 4 / 8 / 16 / 32 (custom 1–64) parallel and free 10/day + Pro.
- **Playlist file numbering** — Settings → Video switch (OFF by default). When
  ON, playlist-origin files get yt-dlp's REAL 1-based `playlist_index` as a
  zero-padded prefix: `01 - Song.mp4`, `02 - Song.mp4` (private/deleted gaps
  preserved, e.g. 1, 2, 4). Only filenames are numbered — the GUI list is not.
- **No history / auto-clear** — finished jobs leave the list automatically and
  no `downloadHistory` entry is written. Existing local history is cleared at
  startup; downloaded files remain on disk.
- **"By Usman" contact button** — header button with no logo; opens Usman's
  WhatsApp QR card in a modal (embedded offline, no network request).
- **Pro keys + 10/day limit** — free tier allows 10 downloaded videos per local
  day; on the 10th the WhatsApp QR opens automatically and further downloads
  are blocked. A **separate Key button** opens the Pro window. `PRO-KEYS.txt`
  ships **20 offline keys** (10 × 6-month Pro, 10 × Lifetime Pro); activating
  one removes the limit and turns the "By Usman" button into a gold **PRO**
  button. Keys are validated offline — no server, no account, no telemetry.
- **No promo/support links** — Ko-fi, GitHub, releases, discussions, website,
  privacy-policy and update links were removed (video/playlist content links
  still work). The Settings About/upstream-attribution line is gone too.
- **Real app icon** — Usman's "UK Vidoes Downloader" badge, converted from the
  checkerboard preview into a proper transparent PNG (`build/icon.png`,
  `assets/icon.png`) and embedded for the in-app Pro window.
- **Big playlists** — free users get the first videos that fit the 10/day quota
  with a clear "N skipped" toast; Pro users queue the entire playlist.
- **Subscriptions backup** — Export / Import buttons write and read a local
  `.json` **or `.jsn`** file (merge by id, no server).
- **yt-dlp engine** — downloads the binary itself if it is missing, self-updates
  on launch and every 6 hours, and shows the version, live phase and a
  `2026.10.26 → 2026.11.07` toast in the GUI. Settings → yt-dlp engine also
  has **Check for updates** and **Re-download engine** buttons.
- **Everything from v2.0.1** — 1,000+ sites via yt-dlp, H.264 conversion,
  download queue with pause/cancel, themes, optional YouTube sign-in.

Full feature notes: **[README-SUBSCRIPTIONS.md](README-SUBSCRIPTIONS.md)**.

---

## Security notice

The installer is not code-signed. On Windows choose **More info → Run anyway**.
On macOS use **System Settings → Privacy & Security → Open Anyway**, or clear
quarantine with `xattr -dr com.apple.quarantine /Applications/UK\ Downloader.app`.

---

## Legal

UK Downloader is a graphical interface for the open-source
[yt-dlp](https://github.com/yt-dlp/yt-dlp) project. It does not modify or
circumvent the original software. Download only content you have permission to
access or distribute.

## Licence

UK Downloader is **source-available**, not open source. It is distributed under
the [PolyForm Noncommercial License 1.0.0](LICENSE) inherited from upstream:

- **Allowed** — personal use, hobby projects, study, research, charities,
  schools, public research bodies and government institutions. You may read,
  modify, fork and redistribute the source for those purposes.
- **Not allowed** — any commercial purpose. You may not sell this build, ship it
  inside a paid product, or rebrand it and monetise it.

The original "YT-Forge" name and logo are trademarks of the author and are not
licensed here; this fork is distributed under a different name and branding.
For a commercial licence, contact the original author.

Credits, third-party licences and full texts: **[NOTICE.md](NOTICE.md)**.

---

## Privacy

No telemetry, analytics, accounts or download history. Downloads, settings and
the local Pro/daily-limit counters stay on your machine. Network requests
(yt-dlp update check, optional YouTube sign-in, PO tokens, thumbnails) are
documented in **[PRIVACY.md](PRIVACY.md)**.

---

<div align="center">Built with Electron, React and Vite.</div>
