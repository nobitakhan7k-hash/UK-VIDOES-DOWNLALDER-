# UK Downloader — Smart Playlist Subscriptions

Automatic downloads for a **YouTube playlist** or a **channel's uploads feed**, using
yt-dlp only. No account, no cookies file, no server, no telemetry.

The whole feature is built on **one saved value per playlist: `last_video_id`**.
There is no downloaded-video history and no id arrays anywhere.

---

## 1. The rule

```
subscriptions.json
{
  "subscriptions": [
    {
      "name": "Nashtar",
      "url": "https://www.youtube.com/playlist?list=PL...",
      "last_video_id": "q6fgVVmdpgY",
      "enabled": true
    }
  ]
}
```

* `last_video_id` = the id of the **last video that actually finished downloading**
  (or, right after you add the playlist, the **newest** video at that moment).
* Each playlist keeps its own id. Nothing is shared between subscriptions.
* Extra keys (`quality`, `type`, `intervalMinutes`, and the short list of videos
  detected but not yet finished) live next to those four, but the four documented
  keys are always present and are the only ones the algorithm depends on.

File location: `<userData>/subscriptions.json`
(Windows: `%APPDATA%\uk-downloader\subscriptions.json`), written **atomically**
(temp file → `fsync` → rename, previous copy kept as `subscriptions.json.bak`).

## 2. What happens on each scan

1. yt-dlp reads the playlist flat: `--flat-playlist --ignore-errors --playlist-end 50`
   into `-J`. Only ids, titles, thumbnails and positions — **no video files, no
   per-video metadata requests for old videos.**
2. The newest id in that window is compared with `last_video_id`.
   * **Equal** → nothing is new, the scan ends. No download, no file touched.
   * **Different** → every entry *above* the saved id (i.e. newer than it) is new.
3. New ids are queued **oldest first** — a playlist is always caught up in the
   order the episodes were published.
4. One download at a time per playlist (the app-wide parallel setting still
   controls fragments, not subscription concurrency), so a playlist can never
   race itself and download the same video twice.
5. When a video finishes **and** passes verification (file exists, > 1 KB,
   ffprobe reports a real stream and > 0.5 s duration) → `last_video_id` moves
   to that video's id. Only then. A failed or cancelled download leaves the
   saved id exactly where it was, so the next scan finds the video again.
6. A video that fails 3 times is marked failed and skipped, so it can never
   block the rest of the batch forever.

### Private / deleted / unavailable videos

Entries whose title is `[Private video]`, `[Deleted video]`, `[Unavailable video]`
etc. (or whose id resolves to nothing) are detected, counted in the card as
`N unavailable`, and **never queued**. They still do not stop the chain — the
saved id simply walks past them when the videos around them download.

### The saved id vanished from the playlist

If the video carrying `last_video_id` was deleted from the playlist, the scan
cannot cut the window in the right place. Instead of re-downloading the whole
playlist, the app falls back to a **bounded batch of at most 10 videos**
(`ANCHOR_MISSING_MAX`), oldest of those first, and re-anchors after the first
success. Whole-playlist re-download is impossible by construction.

## 3. Scans: start, stop, interval

* **Start Scan / Stop Scan** — the header button. Stopping halts *scheduled*
  scans; a download already running is not killed.
* **Scan Interval** — `Every 5 / 15 / 30 / 60 / 180 minutes` (default 15). The
  same list is also available per playlist; a playlist is scanned when its own
  interval has elapsed, so a busy 5-minute playlist does not drag the others.
* **Scan all now** — one-shot sweep of every enabled playlist, respecting the
  same per-playlist interval and the same one-at-a-time guard.
* The engine ticks every 15 s and only scans what is due. It survives sleep /
  restart: state is persisted in electron-store (`subscriptionScanV1`).

## 4. What the GUI shows

* A green **SCANNING / PAUSED** badge in the page header.
* Per playlist: `checked 4m ago`, `every 15m`, `3 found`, a mono badge with the
  current **last video ID**, and counters `N waiting · N downloaded · N unavailable`.
* Detected videos with a live status per row: `queued`, `downloading (x%)`,
  `failed`, `skipped`. Finished videos disappear from the list
  (the saved id is the receipt — no history is kept).
* **Re-baseline** (database icon) — for when you *want* to jump forward: it sets
  `last_video_id` to the newest video and clears the pending rows, without
  downloading anything.
* Export / Import use the documented JSON shape above, `.json` and `.jsn`,
  through local dialogs only.

## 5. Restart & resume

On launch the app:

1. migrates any older record shape (drops `knownIds`, `knownIdsComplete`,
   `knownCount`, `pendingCount`, deletes the legacy store key),
2. prunes videos that already finished,
3. re-creates each subscription's folder + thumbnail,
4. re-queues whatever was detected but not finished,
5. starts the scheduler.

Because the saved id only advances on a verified success, a crash mid-batch
resumes with the same anchor and the same remaining videos — no duplicates,
no gaps.

## 6. Files

| File | Role |
| --- | --- |
| `src/lib/playlistSubscription.cjs` | Pure logic: `findNewVideos`, `advanceAnchor`, `isScanDue`, `mergeDetected`, `normalizeRecord`, `toStorageDocument`, `writeJsonAtomic`, `readSubscriptionsFile`, `saveSubscriptionsFile` |
| `src/main.js` — subscription block | Feed fetching (flat), folder sync, queue pump, ffprobe verify, job result handling, scan engine, IPC |
| `src/preload.js` | Bridge: `getSubscriptionScanState`, `startSubscriptionScan`, `stopSubscriptionScan`, `setSubscriptionScanInterval`, `onSubscriptionScanState`, `rebaselineSubscription` |
| `src/components/SubscriptionsView.jsx` | Page: scan controls, cards, detected rows |
| `scripts/verify-playlist-subscription.mjs` | `npm run verify:playlist-subscription` — 36 checks |
