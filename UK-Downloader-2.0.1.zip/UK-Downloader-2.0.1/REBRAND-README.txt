=========================================================
 UK Downloader - rebrand + v10 patch (for an upstream checkout)
=========================================================

The Full zip already contains all of these changes. Use this folder only if
you are applying the src/ patch to your own copy of upstream v2.0.1.

HOW TO USE
----------
1. Copy src/ over your checkout's src/ (or apply CHANGES.diff).
2. Copy the rebrand/ folder contents over the project root, keeping paths:
      cp -R rebrand/.  /path/to/UK-Downloader/
   On Windows: copy the contents of rebrand\ into the project folder.
3. Run npm install, then builder.bat (or npm run dist:win).

WHAT EACH FILE DOES
-------------------
package.json                 name/productName -> uk-downloader / UK Downloader
package-lock.json            same package name
electron-builder.yml         appId + productName; PRO-KEYS.txt in files AND
                             mac/win/linux extraResources (ships in installer)
index.html                   window title + meta description
.github/workflows/build.yml  CI workflow name
build/icon.png               REAL UK Vidoes Downloader badge (transparent PNG)
assets/icon.png              same icon for the README
assets/uk-logo-*.jpg/png     original + solid preview of the new badge
assets/by-usman-qr*.jpg      original + optimised WhatsApp contact card
PRO-KEYS.txt                 20 offline keys: 10 x 6-month Pro + 10 x Lifetime
builder.bat                  builder titles, messages, zip/exe names, key note;
                             bundled bin/yt-dlp.exe + 4-URL download fallback
                             with SHA256 verification (fixes GitHub 504)
START-HERE.txt               quick-start guide (all features in Hinglish)
README.md                    UK Downloader overview + licence/attribution
README-SUBSCRIPTIONS.md      feature notes + 0b/0c/0d/0e tables
NOTICE.md / PRIVACY.md       upstream attribution + local-only notes

src/ (CHANGES.diff) also changes — v10 + drag song fix + queue + Playlists hub
+ Browse window:
  - src/browse-preload.js + vite.browse-preload.config.mjs build a separate
    sandboxed preload for the YouTube window.
  - src/main.js adds createBrowseWindow(), cleanBrowseVideoUrl(), native
    "Download this video" context menu, browse:open / browse-download-url and
    the floating Back/Forward/Home/Reload nav IPC (navigationHistory based).
  - src/browse-preload.js mounts #uk-browse-nav in the YouTube window.
  - Header.jsx adds the Browse button and renames Get / Search -> DOWNLOAD.
  - package.json adds build:browse-preload to start/build (5 build sections).
  - Header.jsx removes the "/" Kbd shortcut badge (and its focus state);
    HistoryView.jsx removes the "In Progress" header row + unused Info icon.
  - src/lib/subscriptionFolder.cjs: Windows-safe playlist folder names,
    duplicate-title suffixes, hidden temp + backup, exact FOLDER.JPG replace,
    stale FOLDER.* cleanup and JPEG validation. scripts/copy-subscription-folder.mjs
    copies it into dist-electron/lib because Vite leaves local require() alone;
    package.json runs that copy immediately after build:main (5 Vite builds stay).
  - main.js: subscriptions:add creates the named subfolder immediately and
    stores folderName/folderPath; enqueueSubscriptionDownload and open-folder
    use it; checkSubscription recreates it; new-video batches queue ONE newest
    thumbnail refresh; targetDir changes, imports and app launch all backfill
    folders. SubscriptionsView shows the subfolder and explains FOLDER.JPG.
  - src/lib/searchInput.mjs: string-only top-bar helpers. Header.jsx wraps the
    DOWNLOAD click so no event object reaches handleFetchDetails; AppContext
    uses resolveFetchDetailsInput + safeKeywordQuery + one setUrlInput writer;
    preload.js and main.js reject non-string / "[object …]" queries before any
    ytsearchN call. Fixes the "[object Object]" second-keyword bug. 10/10
    checks in scripts/verify-keyword-input.mjs.
  - src/components/KeywordView.jsx + src/lib/keywordScan.cjs: dedicated
    Keyword Search page. Header Search button + AppContext open/closeKeyword +
    App.jsx route + Escape/shortcut guard. main.js keyword-page:scan builds a
    YouTube results URL with upload-date `sp`, uses --playlist-end (20 results
    x pages), --flat-playlist, --yes-playlist and approximate_date, applies a
    strict local date cutoff, skips /shorts/, refuses channels/duplicates and
    sorts by view_count descending. Count is asked AFTER the scan; downloads
    reuse queueVideoBatch. scripts/copy-main-helpers.mjs copies BOTH .cjs
    helpers into dist-electron/lib; 13/13 checks in verify-keyword-page.mjs.
  - Extension support: main.js registers ukdownloader:// (second-instance /
    open-url / cold argv), enqueues kind:'file' jobs, streams http(s) files with
    hidden .part + Range resume; HistoryView shows FILE badge. Extension ships
    separately as uk-downloader-extension.zip (no local server).
  - src/components/PlaylistsView.jsx: new dedicated page (paste / recent /
    Download whole playlist / Open selection view / auto-subscribe switch).
  - src/main.js: playlistHubV1 IPC, playlistNumbering setting (OFF by default),
    REAL playlist_index on playlist/feed entries, numberedPlaylistTitle() used
    by queue-video, queue-video-batch, runPlaylistJob and subscriptions.
  - AppContext.jsx / App.jsx / Header.jsx / SettingsDialog.jsx / preload.js:
    page routing, header button, Settings switch and IPC bridges.
  - src/main.js runs manual "Check all" sweeps strictly sequentially and emits
    subscription-check-progress (i/total/title) for the GUI banner; AppContext
    tracks subsCheckProgress and SubscriptionsView spins only the current card.
  - src/main.js persists a resumeQueueV1 snapshot on quit, restores it on
    launch, reuses hidden .part folders with --continue, hides the scratch dir
    on Windows, and adds cancel-all-jobs + auto-subscribe IPC.
  - AppContext.jsx adds the Playlist-page auto-subscribe switch, cancelAllJobs
    and the isPlaylistPageOpen gate; HistoryView.jsx adds Cancel All +
    "Resuming…"; PlaylistView.jsx adds the switch; SubscriptionsView.jsx makes
    unsubscribe one-click.
  - preload.js exposes the three new IPC bridges.
  - src/lib/dragUrls.js strips playlist/radio params from dropped YouTube watch
    links so one song is queued as a single video, never as a playlist.
  - AppContext.jsx shows an optimistic animated "preparing" row in Downloads
    during the metadata fetch; HistoryView.jsx renders it. No history/state is
    persisted for the placeholder.
  - App.jsx overlay copy updated to mention the instant preparing row.
  - Plain text in the top bar (song name / keyword) runs YouTube ytsearchN and
    direct-downloads the first result on Enter. No details page / Save dialog.
  - Settings -> Video adds keywordLimit 1-50 (default 1). Set 20 for 20 hits.
  - Output respects the global HD/MP3 default; YouTube only as chosen.
  - queue-keyword-search IPC dedupes results, reserves daily quota, uses the
    2 / 4 / 8 / 16 / 32 (custom 1–64) parallel queue and no-history/auto-clear rules.
  - Header placeholder / button updated; PRIVACY documents the query sent to
    YouTube and states no search history is kept.

Earlier src/ (CHANGES.diff) changes still present — v9:
  - Subscriptions read the FULL feed (no --playlist-end) and store EVERY video
    id in knownIds (no SUB_FEED_LIMIT / SUB_KNOWN_IDS_MAX). Old videos can no
    longer be re-detected as new and downloaded twice.
  - Legacy subscriptions get a safe one-time full-feed backfill on the next
    check: all ids merged, zero downloads. Imported .json/.jsn backups too.
  - subscriptions:rebuild-ids + "Rebuild IDs" card button refresh the list.
  - maxPerCheck removed from checks; quota-blocked new ids stay unknown and
    retry later instead of being silently forgotten. pendingCount is shown.
  - GUI shows "N IDs tracked" and "N waiting"; finished tooltip says files
    stay on disk (no history).

Earlier src/ (CHANGES.diff) changes still present — v8:
  - Drag & drop starts a DIRECT download: no details page, no Save dialog.
    Multiple links / playlists go through queue-video-batch as separate jobs.
  - Connections: src/lib/parallel.cjs / parallel.mjs define presets 2/4/8/16/32,
    custom 1–64 and default 8. main.js clampParallel() feeds BOTH processQueue()
    (parallel jobs) and downloadSpeedArgs() (--concurrent-fragments per video);
    the hard-coded 4 is gone. SettingsDialog has presets + a custom input.
    Previous line retained: Settings -> Video chooses 2 / 4 / 8 / 16 / 32 (custom 1–64). main.js uses an
    activeJobs map + per-job control map instead of one global activeJob /
    activeCtl. Raising the limit re-kicks the queue immediately.
  - MP3 option: Settings -> Video adds a global "MP3 audio" default; it seeds
    DetailsView, PlaylistView, SubscriptionsView and direct drag-downloads.
  - No history: downloadHistory is cleared at startup, get-history returns [],
    history IPC is inert, and finished jobResults clear after 4.5 s. Finished
    jobs already leave downloadQueue; the GUI empty state says so explicitly.
  - Daily-limit reservations: queued/running jobs count against 10/day before
    they finish, so six parallel drops cannot overrun the free quota.

Earlier src/ (CHANGES.diff) changes still present:
  - Settings About box removed (no YT-Forge attribution line in UI).
  - Big playlists: free users queue up to the remaining 10/day quota with
    a GUI toast; Pro users queue the entire playlist (app-notice event).
  - Real icon: src/assets/uk-logo.js (PNG data URI) + ui/logo.jsx renders
    Usman's badge; visible in the Pro key window.
  - Subscriptions Export / Import buttons (.json AND .jsn), merge by id,
    local file dialogs only: subscriptions:export / subscriptions:import.
  - Header: 'By Usman' -> gold 'PRO' after key; separate Key button.
  - QR popup auto-opens on the 10th daily video with Enter Pro key button.
  - main.js: offline HMAC keys, dailyUsageV1 counter, yt-dlp auto-download
    + auto-update, one-time YT-Forge data migration.
  - All app-owned promo/support links removed; content URLs still work.

IMPORTANT
---------
Keys and subscription backups are entirely local: no licence server, no
telemetry, no network request when entering a key or importing a .jsn file.
The daily counter resets at local midnight. Pro has no daily limit.
No download history is stored in this build; files stay on disk. Subscription
knownIds are local subscription state, not a download history. Keyword search
keeps no search history either.
LICENSE is unchanged. Non-commercial use only (PolyForm Noncommercial 1.0.0).
