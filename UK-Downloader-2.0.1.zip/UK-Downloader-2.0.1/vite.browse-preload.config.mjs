import { defineConfig } from 'vite';
import { builtinModules } from 'module';

// Separate preload for the YouTube Browse window. Never bundle the app's
// privileged preload into a remote page.
export default defineConfig({
  build: {
    outDir: 'dist-electron',
    emptyOutDir: false,
    minify: false,
    lib: {
      entry: 'src/browse-preload.js',
      formats: ['cjs'],
      fileName: () => 'browse-preload.js',
    },
    rollupOptions: {
      external: [
        'electron',
        ...builtinModules,
        ...builtinModules.map((m) => `node:${m}`),
      ],
    },
  },
});
